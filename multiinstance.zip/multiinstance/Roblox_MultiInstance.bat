@echo off
setlocal EnableDelayedExpansion
title Roblox Multi-Instance (singleton killer)

:: --- self-elevate (handle64 needs admin to close handles) ---
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:: --- find handle64.exe (same folder as this file, or on PATH); download it if missing ---
set "H=%~dp0handle64.exe"
if not exist "%H%" (
    where handle64.exe >nul 2>&1 && (set "H=handle64.exe") || (
        echo handle64.exe not found - downloading from Microsoft Sysinternals...
        powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -UseBasicParsing -Uri 'https://live.sysinternals.com/handle64.exe' -OutFile '%~dp0handle64.exe' } catch { exit 1 }"
        if not exist "%~dp0handle64.exe" (
            echo.
            echo Download failed. Check your internet connection, or download handle64.exe manually from
            echo   https://learn.microsoft.com/sysinternals/downloads/handle
            echo and put it next to this file.
            pause
            exit /b 1
        )
        echo Downloaded handle64.exe.
    )
)

echo Running. Launch as many Roblox clients as you want - leave this window open.
echo Close this window to stop.
echo.

:loop
set "PID="
for /f "tokens=1-3" %%a in ('"%H%" -accepteula -nobanner -a -p RobloxPlayerBeta.exe ROBLOX_singletonEvent 2^>nul') do (
    if /i "%%b"=="pid:" set "PID=%%c"
    if /i "%%b"=="Event" if defined PID (
        set "HND=%%a"
        set "HND=!HND::=!"
        "%H%" -accepteula -nobanner -p !PID! -c !HND! -y >nul 2>&1
        echo [%time:~0,8%] Closed singleton event ^(handle !HND!^) in PID !PID!
    )
)
timeout /t 2 /nobreak >nul
goto loop
