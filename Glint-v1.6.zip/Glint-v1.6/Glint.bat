@goto :pr_start
r"""
:pr_start
@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Glint

rem ===========================================================================
rem  GLINT - one file: launcher + program. Local-only Roblox account manager.
rem  Double-click it. It finds or installs Python, installs pywebview (used for
rem  the Roblox sign-in window), then runs the Python code stored further down
rem  in this same file. Nothing is ever sent anywhere except to Roblox.
rem ===========================================================================

set "PY_WINGET_ID=Python.Python.3.12"
set "PY_URL=https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe"
set "PY_PACKAGES=pywebview"

rem --- 1. look for a Python that really works (the Microsoft Store stub does not count)
set "PYEXE="
call :try_python py -3
call :try_python python
if not defined PYEXE call :find_installed
if defined PYEXE goto :have_python

rem --- 2. none found: install one
echo.
echo [INFO] No usable Python 3.9 or newer with tkinter was found. Installing Python...
where winget >nul 2>&1
if not errorlevel 1 (
    echo [INFO] Installing %PY_WINGET_ID% with winget - this can take a minute...
    winget install --id %PY_WINGET_ID% --exact --source winget --silent --accept-source-agreements --accept-package-agreements
)
call :find_installed
if not defined PYEXE call :try_python py -3
if defined PYEXE goto :have_python

echo [INFO] Downloading the Python installer from python.org...
set "PY_SETUP=%TEMP%\pr_python_setup.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $ProgressPreference = 'SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri '%PY_URL%' -OutFile '%PY_SETUP%'"
if exist "%PY_SETUP%" (
    echo [INFO] Installing Python - please wait...
    start /wait "" "%PY_SETUP%" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_tcltk=1 Include_test=0 Shortcuts=0
    del "%PY_SETUP%" >nul 2>&1
)
call :find_installed
if not defined PYEXE call :try_python py -3
if defined PYEXE goto :have_python

echo.
echo [ERROR] Python could not be installed automatically.
echo         Install Python 3.12 from https://www.python.org/downloads/windows/
echo         and tick "Add python.exe to PATH", then run this file again.
pause
exit /b 1

rem --- 3. install the sign-in window library, then start the program
:have_python
echo [INFO] Using Python: %PYEXE%
echo [INFO] Checking libraries - a few seconds...
%PYEXE% -c "import webview" >nul 2>&1
if errorlevel 1 %PYEXE% -m pip install --disable-pip-version-check --quiet --retries 1 --timeout 15 %PY_PACKAGES%
%PYEXE% -c "import webview" >nul 2>&1
if errorlevel 1 (
    echo.
    echo [WARNING] pywebview could not be installed, so the Roblox sign-in window is unavailable.
    echo           You can still add accounts with the "Add by cookie" button.
    timeout /t 5 >nul
)

rem --- start without a console window (pythonw); -x makes Python skip line 1 of this file
set "PYWEXE=%PYEXE:python.exe=pythonw.exe%"
if "%PYEXE%"=="py -3" set "PYWEXE=pyw -3"
if /i "%PYEXE%"=="python" set "PYWEXE=pythonw"
start "" %PYWEXE% -x "%~f0" %*
exit /b 0

rem ---------------------------------------------------------------------------
rem  subroutine: test one way of starting Python. Keeps it only if it runs, is
rem  version 3.9 or newer, and has tkinter for the window.
rem ---------------------------------------------------------------------------
:try_python
if defined PYEXE exit /b 0
%* -c "import sys, tkinter; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
if not errorlevel 1 set "PYEXE=%*"
exit /b 0

rem --- subroutine: look in the usual install folders (a just-installed Python is not on PATH yet)
:find_installed
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do call :try_python "%%D\python.exe"
for /d %%D in ("%ProgramFiles%\Python3*") do call :try_python "%%D\python.exe"
for /d %%D in ("%LOCALAPPDATA%\Python\pythoncore-3*") do call :try_python "%%D\python.exe"
exit /b 0
"""
# ============================================================================
#  Everything below is the program itself (Python). The batch launcher above is
#  wrapped in a string so Python ignores it, and Python's -x flag skips line 1.
# ============================================================================
"""
Glint - a local-only multi-account Roblox launcher. Made by Diamond.

PRIVACY DESIGN (read the code, it is short):
  * No server, no analytics, no telemetry. The only extra request is the optional update check
    (api.github.com, once per launch, can be switched off in Settings): it only READS the latest
    release of the repo named in UPDATE_REPO and sends nothing about you.
  * Network requests go ONLY to Roblox (roblox.com / apis) to sign in and launch,
    plus one-time optional downloads of Microsoft's handle64.exe (multi-instance) and Intel's
    PresentMon from github.com (FPS tracker).
  * Accounts are stored encrypted with Windows DPAPI in %APPDATA%\\DiamondLauncher\\accounts.dat.
    Only the same Windows user on the same PC can decrypt that file.
  * "Open Roblox links with Glint" is OFF by default. When you switch it on it writes the roblox-player and
    roblox protocol handlers under HKEY_CURRENT_USER (no admin needed) and keeps a copy of Roblox's own
    handler so it can be put back (untick the box, or run Glint.bat --restore-links).
  * The FPS boost only edits Roblox's own ClientSettings\\ClientAppSettings.json on this PC.
  * Passwords are never typed into this program: you sign in on Roblox's own page.
  * Multiple Roblox instances is OFF unless you tick it (launch screen or Settings).
"""
import sys, os, re, json, time, random, threading, subprocess, ctypes, base64, queue, hashlib, zipfile, shutil, uuid
from collections import deque
import urllib.request, urllib.error, urllib.parse
from ctypes import wintypes

APP_DIR = os.path.join(os.environ.get("APPDATA", "."), "DiamondLauncher")  # old name kept on purpose: saved accounts carry over
_OLD_DIR = os.path.join(os.environ.get("APPDATA", "."), "PrivateRAM")
if os.path.isdir(_OLD_DIR) and not os.path.exists(APP_DIR):  # keep accounts saved by earlier builds
    try:
        os.rename(_OLD_DIR, APP_DIR)
    except OSError:
        pass
APP_NAME, APP_VERSION = "Glint", "1.6"
# Auto-update + bug reports use this GitHub repo. To release an update, publish a Release there
# (tag like v1.2) and attach Glint.bat (and Glint.exe if you build one).
UPDATE_REPO = "D14M0ND-RBX/roblox-multi-instance"
GITHUB_PAGE = "https://github.com/D14M0ND-RBX/roblox-multi-instance"
GITHUB_ISSUES = GITHUB_PAGE + "/issues"
GITHUB_NEW_ISSUE = GITHUB_ISSUES + "/new"
DATA_FILE = os.path.join(APP_DIR, "accounts.dat")
HANDLE_EXE = os.path.join(APP_DIR, "handle64.exe")
HANDLE_URL = "https://live.sysinternals.com/handle64.exe"
PM_EXE = os.path.join(APP_DIR, "PresentMon.exe")
PM_URL = "https://github.com/GameTechDev/PresentMon/releases/download/v2.3.1/PresentMon-2.3.1-x64.exe"
FPS_CSV = os.path.join(APP_DIR, "fps_capture.csv")
FPS_STOP = os.path.join(APP_DIR, "fps_capture.stop")
LOCAL = os.environ.get("LOCALAPPDATA", "")
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
NO_WINDOW = 0x08000000


# ----------------------------------------------------------------------------
# Sign-in window (runs in its own process so the main app never touches passwords)
# ----------------------------------------------------------------------------
def login_window(out_path):
    import webview  # pip install pywebview
    win = webview.create_window("Sign in to Roblox (closes automatically)",
                                "https://www.roblox.com/login", width=520, height=760)
    state = {"cookie": None, "done": False}

    def watch():
        while not state["done"]:
            time.sleep(1.0)
            try:
                for jar in (win.get_cookies() or []):
                    for key, morsel in jar.items():
                        if key == ".ROBLOSECURITY" and morsel.value:
                            state["cookie"] = morsel.value
                            win.destroy()
                            return
            except Exception:
                continue

    webview.start(watch, private_mode=True)  # private_mode = fresh session every time
    state["done"] = True
    if state["cookie"]:
        with open(out_path, "w") as f:
            f.write(state["cookie"])


# ----------------------------------------------------------------------------
# Encrypted local storage (Windows DPAPI)
# ----------------------------------------------------------------------------
class _BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _to_blob(data):
    buf = ctypes.create_string_buffer(data, len(data))
    return _BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf


def _dpapi(data, encrypt):
    blob_in, _keep = _to_blob(data)
    blob_out = _BLOB()
    fn = ctypes.windll.crypt32.CryptProtectData if encrypt else ctypes.windll.crypt32.CryptUnprotectData
    if not fn(ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)):
        raise OSError("DPAPI failed")
    out = ctypes.string_at(blob_out.pbData, blob_out.cbData)
    ctypes.windll.kernel32.LocalFree(blob_out.pbData)
    return out


def load_data():
    try:
        with open(DATA_FILE, "rb") as f:
            return json.loads(_dpapi(f.read(), False).decode("utf-8"))
    except Exception:
        return {"accounts": [], "last_target": "", "multi": False}


def save_data(data):
    os.makedirs(APP_DIR, exist_ok=True)
    with open(DATA_FILE, "wb") as f:
        f.write(_dpapi(json.dumps(data).encode("utf-8"), True))


# ----------------------------------------------------------------------------
# Roblox web helpers (urllib only, nothing else is contacted)
# ----------------------------------------------------------------------------
def http(method, url, headers=None, body=None):
    req = urllib.request.Request(url, data=body, method=method, headers=headers or {})
    try:
        resp = urllib.request.urlopen(req, timeout=20)
        return resp.status, resp.headers, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.headers, e.read()


def auth_headers(cookie, json_body=False):
    h = {"Cookie": ".ROBLOSECURITY=" + cookie, "User-Agent": UA,
         "Referer": "https://www.roblox.com/", "Origin": "https://www.roblox.com"}
    if json_body:
        h["Content-Type"] = "application/json"
    return h


def post_with_csrf(url, cookie, payload=b"{}"):
    h = auth_headers(cookie, True)
    st, hd, body = http("POST", url, h, payload)
    if st == 403 and hd.get("x-csrf-token"):
        h["X-CSRF-TOKEN"] = hd.get("x-csrf-token")
        st, hd, body = http("POST", url, h, payload)
    return st, hd, body


def whoami(cookie):
    st, _, body = http("GET", "https://users.roblox.com/v1/users/authenticated", auth_headers(cookie))
    if st != 200:
        return None
    j = json.loads(body)
    return {"id": j["id"], "name": j["name"], "display": j.get("displayName", j["name"])}


def get_ticket(cookie):
    st, hd, _ = post_with_csrf("https://auth.roblox.com/v1/authentication-ticket", cookie)
    ticket = hd.get("rbx-authentication-ticket")
    if not ticket:
        raise RuntimeError("no auth ticket (HTTP %s) - cookie expired? sign in again" % st)
    return ticket


def parse_target(text):
    t = (text or "").strip()
    if not t:
        return None
    if t.isdigit():
        return {"kind": "place", "place": int(t)}
    if "/share" in t and "type=Server" in t:
        m = re.search(r"code=([0-9A-Za-z]+)", t)
        if m:
            return {"kind": "share", "code": m.group(1)}
    place = re.search(r"/games/(\d+)", t) or re.search(r"placeId=(\d+)", t, re.I)
    link = re.search(r"privateServerLinkCode=([\w-]+)", t)
    job = re.search(r"gameInstanceId=([0-9a-fA-F-]{36})", t)
    if place and link:
        return {"kind": "private", "place": int(place.group(1)), "link": link.group(1)}
    if place and job:
        return {"kind": "job", "place": int(place.group(1)), "job": job.group(1)}
    if place:
        return {"kind": "place", "place": int(place.group(1))}
    return None


# ----------------------------------------------------------------------------
# Find a game by name (no link needed). Uses the same public search the Roblox website uses, plus a
# short list of games you launched recently. Nothing here needs an account.
# ----------------------------------------------------------------------------
def search_games(query):
    """[{place, name, players, up, down}] for a search word. Raises RuntimeError if Roblox can't be reached."""
    url = ("https://apis.roblox.com/search-api/omni-search?searchQuery=%s&sessionId=%s&pageType=all"
           % (urllib.parse.quote(query.strip()), uuid.uuid4()))
    try:
        st, _, body = http("GET", url, {"User-Agent": UA, "Accept": "application/json"})
    except Exception as e:
        raise RuntimeError("could not reach Roblox (%s)" % e)
    if st != 200:
        raise RuntimeError("Roblox search failed (HTTP %d)" % st)
    try:
        d = json.loads(body.decode("utf-8", "ignore"))
    except ValueError:
        raise RuntimeError("Roblox gave an answer Glint doesn't understand")
    out, seen = [], set()
    for grp in d.get("searchResults") or []:
        for g in (grp.get("contents") or []) if isinstance(grp, dict) else []:
            pid = g.get("rootPlaceId") if isinstance(g, dict) else None  # only games have a place id
            if not pid or pid in seen:
                continue
            seen.add(pid)
            out.append({"place": int(pid), "name": str(g.get("name") or "Game %s" % pid),
                        "players": int(g.get("playerCount") or 0),
                        "up": int(g.get("totalUpVotes") or 0), "down": int(g.get("totalDownVotes") or 0)})
    return out


def game_name(place):
    """Name of the game with this place id, or None."""
    st, _, body = http("GET", "https://apis.roblox.com/universes/v1/places/%d/universe" % place, {"User-Agent": UA})
    uid = json.loads(body.decode("utf-8", "ignore")).get("universeId") if st == 200 else None
    if not uid:
        return None
    st, _, body = http("GET", "https://games.roblox.com/v1/games?universeIds=%d" % int(uid), {"User-Agent": UA})
    rows = (json.loads(body.decode("utf-8", "ignore")).get("data") or []) if st == 200 else []
    return rows[0].get("name") if rows and isinstance(rows[0], dict) else None


def remember_game(data, place, name=None):
    """Puts a game at the top of the recent list (newest first, 15 kept). A known name is never lost."""
    recent = data.setdefault("recent_games", [])
    old = next((g for g in recent if g.get("place") == place), None)
    if old:
        recent.remove(old)
    recent.insert(0, {"place": int(place), "name": name or (old or {}).get("name")})
    del recent[15:]


def set_game_name(data, place, name):
    for g in data.get("recent_games", []):
        if g.get("place") == place and name:
            g["name"] = name


def known_game_name(data, place):
    return next((g.get("name") for g in data.get("recent_games", []) if g.get("place") == place and g.get("name")), None)


def resolve_share(cookie, code):
    payload = json.dumps({"linkId": code, "linkType": "Server"}).encode()
    st, _, body = post_with_csrf("https://apis.roblox.com/sharelinks/v1/resolve-link", cookie, payload)
    if st != 200:
        raise RuntimeError("could not resolve share link (HTTP %s)" % st)
    d = json.loads(body).get("privateServerInviteData") or {}
    if not d.get("placeId") or not d.get("linkCode"):
        raise RuntimeError("share link invalid or expired")
    return int(d["placeId"]), d["linkCode"]


def fetch_access_code(cookie, place, link):
    url = "https://www.roblox.com/games/%d/?privateServerLinkCode=%s" % (place, link)
    st, _, body = http("GET", url, auth_headers(cookie))
    m = re.search(r"joinPrivateGame\(\s*\d+\s*,\s*['\"]([\w-]+)['\"]", body.decode("utf-8", "ignore"))
    return m.group(1) if (st == 200 and m) else None


def launch_account(acc, target, log):
    if OWN_CLIENT:
        own_ensure(log)  # first: installing can take minutes and the join ticket below expires fast
    cookie = acc["cookie"]
    place, req, extra = target.get("place"), "RequestGame", ""
    if target["kind"] == "share":
        place, link = resolve_share(cookie, target["code"])
        target = {"kind": "private", "place": place, "link": link}
    if target["kind"] == "private":
        link = target["link"]
        access = fetch_access_code(cookie, place, link)
        req = "RequestPrivateGame"
        extra = "&linkCode=" + link + ("&accessCode=" + access if access else "")
        log("  private server: access code %s" % ("found" if access else "not found, trying link code only"))
    elif target["kind"] == "job":
        req, extra = "RequestGameJob", "&gameId=" + target["job"]

    ticket = get_ticket(cookie)  # fetched last: tickets expire quickly
    tracker = str(random.randint(10**10, 10**11 - 1))
    pl = ("https://assetgame.roblox.com/game/PlaceLauncher.ashx?request=%s&browserTrackerId=%s"
          "&placeId=%d&isPlayTogetherGame=false%s" % (req, tracker, place, extra))
    uri = ("roblox-player:1+launchmode:play+gameinfo:%s+launchtime:%d+placelauncherurl:%s"
           "+browsertrackerid:%s+robloxLocale:en_us+gameLocale:en_us+channel:+LaunchExp:InApp"
           % (ticket, int(time.time() * 1000), urllib.parse.quote(pl, safe=""), tracker))
    launch_uri(uri)


# ----------------------------------------------------------------------------
# Multi-instance (same trick as closing ROBLOX_singletonEvent in Process Explorer)
# ----------------------------------------------------------------------------
_mutex_handle = None


def set_singleton_mutex(enable):
    """Multi-instance ON: hold Roblox's singleton mutex so extra clients may start. OFF: release it."""
    global _mutex_handle
    try:
        k = ctypes.windll.kernel32
        k.CreateMutexW.restype = ctypes.c_void_p
        k.CloseHandle.argtypes = [ctypes.c_void_p]
        if enable and not _mutex_handle:
            _mutex_handle = k.CreateMutexW(None, False, "ROBLOX_singletonMutex")
        elif not enable and _mutex_handle:
            k.CloseHandle(_mutex_handle)
            _mutex_handle = None
    except Exception:
        pass


def close_singleton_events():
    """Closes ROBLOX_singletonEvent inside running Roblox clients. Returns number closed."""
    if not os.path.exists(HANDLE_EXE):
        return 0
    out = subprocess.run([HANDLE_EXE, "-accepteula", "-nobanner", "-a", "-p", "RobloxPlayerBeta.exe",
                          "ROBLOX_singletonEvent"], capture_output=True, text=True,
                         creationflags=NO_WINDOW, stdin=subprocess.DEVNULL).stdout
    pid, closed = None, 0
    for line in out.splitlines():
        m = re.search(r"pid:\s*(\d+)", line)
        if m:
            pid = m.group(1)
            continue
        m = re.match(r"\s*([0-9A-Fa-f]+):\s+Event\s", line)
        if m and pid:
            subprocess.run([HANDLE_EXE, "-accepteula", "-nobanner", "-p", pid, "-c", m.group(1), "-y"],
                           capture_output=True, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL)
            closed += 1
    return closed


# ----------------------------------------------------------------------------
# FPS boost: Roblox "fast flags" written to ClientSettings\\ClientAppSettings.json
# (Roblox ignores flags it does not allow, so a flag that does nothing is harmless.)
# ----------------------------------------------------------------------------
FPS_FLAGS = {
    "DFFlagDebugPauseVoxelizer": True,
    "DFIntCSGLevelOfDetailSwitchingDistance": 0,
    "DFIntCSGLevelOfDetailSwitchingDistanceL12": 0,
    "DFIntCSGLevelOfDetailSwitchingDistanceL23": 0,
    "DFIntCSGLevelOfDetailSwitchingDistanceL34": 0,
    "DFIntDebugFRMQualityLevelOverride": 1,
    "FFlagDebugGraphicsPreferOpenGL": False,
    "FFlagDebugGraphicsPreferVulkan": False,
    "FFlagDebugSkyGray": True,
    "FIntFRMMaxGrassDistance": 0,
    "FIntFRMMinGrassDistance": 0,
    "FIntGrassMovementReducedMotionFactor": 0,
}


IXP_B64 = (
    "eNrVXFlz2zgSft9fkcrzhkWC9+hJku1YO5Kt0ZXskwsiYYlriuAQoG3N1v737SYp6wLpKz5mqiZxSABfA2g0vj7o//7jy5evZ2cx"
    "XQwzvuKSjfg8v+8lE54Oo+BGXPV+Dmc0ztnX377KLGcto3Ua8ISv1toJux3whK21XnJ6n7IsYknAxkueitaQrlcskeL4ldbhSS60"
    "md4yPMt0Ld/07NY1wM9pcvP1nw/SnGGfUAzpgk0Fy/qRkKcJnccsvLolCqHGPIhorHV5krBARjwR5/m8dcaozDOYUxzzXLYM2/cc"
    "3fN0qxWy2yuYh8zgFQvVwLOI3XVk8iMK5fItIdthWKF+9FQ3uG8Iuj9Cn65ZBirCBQzzVrBjmUXJYsyEgAH6pB0veHfJgpsCaxc0"
    "zTisuQG4Q55JwH3oAy2ikKIAExazFZPZ2vxmuK7nuo5HnFZjw0JAyzZdpaYruqp2/WMl6vI8kSMmmDyL7j9Oul4i2z87NLhZZCBQ"
    "KLoUUPliQudDLiIcZVc2GKjVvoUm2dYIadO2NqDZDZNpTINC7zcG7cvO8y9EJ86Xc/LlnMch6phnuoXB8hs0OxeSryaRjFmHZgPj"
    "R5SE/E78YPNbQDmJUNKD1bumsdhZvsMRSrHRksLaeS5xTIN4LTgMIl+xrJ2COR3GVF7zbCXAHIsbydOGQWakRXTLg2mYOlFt/FHX"
    "0hz4fyORq9WeLDNGwzG9ZnL9iaWvVGR/BNCRQZREq+gv9rdZ+IfDq7hBPrvG7B1TsHGw7rAFxieewoAGpdTA2SQPeNylwZKVjwaw"
    "C1EgPqn0YMBrFAdOLJfw7BzsesaAcYkhywIYb3cm+ufZgxN+wWWx7l2a4s3TyaWEP4t76RPrDqjMdRSzzZgX7K56cg4Gk2VXt1Y9"
    "Ddv0ZeymuDgPeRjRPcdwbdJA/w7gS3PRXUZpCTHid1e3zsslMIkNUhjm0yWABWjPoe+45JdXt/6boiPDn8AY4AzddWi4YOI9lxs8"
    "jW6eZaAn8RqerYEWX83edcOLte4w+JG1iwXvxtHBIX9rEbqTthixaxpInl3NzBdDO55FdEC3n3DMSj2fJjEPbrpLKq9m5OVTthwL"
    "UM1nKPkwA+qOLjhMmQ2iRUZLXTdeLAQxwHEHNu+b9UKUI2259794lHyMJKD3p7cYkJjwLl+t8iSS62rYJqdzv6USXCemZbgmMWru"
    "6WkSXa9/Z+suD9mApimeuFr3Sd3+G6q37fugb4fwvmM7pufZSvR+TuH6AG3LpIAfwPKc89vS+qgmzWgWLE8iEWAjbfMDBge06c9D"
    "YBuVn8DM69e8hC9s3AmTNIpFxQ1V5h2NUXHbabsdtE1k4BDeJa7u6WYDOvTEczZiK5jFALxNmIc4y/gKlwQ60CiBy04R3HrQVuyu"
    "AQfB80Ph34cyeK5nmobuO6q1nybAYfL7PhWyl6S5nKxTHDBZKIMrTwe1AVD3iPpqr+Y82JlxccwmvAdq/CpcgxBDN3zbNRqAQcNm"
    "PArYEDQuCqKUwoErBCCvxLYtAtzIaZoz7HMniuM5p1n4PY9UBOzpiER3bN8kDnEbIEvV6uTzgsBQWR6xbLvyVLJXzftJUuxtNK5C"
    "tu7GjCZ5+pb7XRzkPqO37DtdsWkqWByfwilcp2Di5esW39cNw/AMq1nR2iHPElZeI0oG83RA4NyG7VuW2Yy4t9L+m69usblRgKN0"
    "wLFT3xvPgHQt3bBAm5qUqUQGRtwBV4yv+kBWWDgO0Lji5fc6ASydeBZwF++p2tyhMli+vdXaw4R9htv+fv3m21t5cnh8kBZ1wWxd"
    "3dr1ZATXv4zXj4Er9BLsWMXvD+FN1zGQmjr1t2MHeejpyRDId3AjwfPOF0vVqX0T8M182wtWhOFL89HIxH+tACUrKq6rIuITrIOY"
    "ZcAKgO+Igo9iDkbFUuBiW2t9WhxHZEataqjDvhv3Ao4dseDOdlz9KeKcYfCgirdvB0Sf+J1l2R2jOBcfuxhFtONo2PdfltN7CSqn"
    "EOQkuo1CePYBy1RdDnWa/AGr9BwX7/mCOHDALdcyvGcszu5gZxQIqtoFetNVGTF6pDnoj4yjRQLW9n1P2QVNf49CAXANuVdks2UG"
    "RbvgSG8z4Lth6RDCq97J4y00REF3C3xvcNQ9kE33G3YOmx+MNMnAvmNkk3y4iCdF/jEPIz5OGQuWEz5h93ITY5mmwA8w7ySWPA5P"
    "5rvifrO8rZcPLj7uXEkjgGwVDmKHZhj/NXTT9h1yxCh8F9x/33qBWH1+9zFilcpfJ9ZJJJAG7b6atU8a4ubvK15J0mY8zlclSakP"
    "2rzvds5oiCnpwd5VAx6y/t4ClT9vA4x8TudRHMn1g67dG7qu74rp6/ob72e1baMuX4FUcsykBLMpesm0rdjATZJlm1+ZjSpIoWEB"
    "wLEP43q+bTi+riL22zIeNC/n0WIZw/9ymgjGkhH7M2dCiqvbBpq7P8IROgB7vuMT7ymlRDjCWfu0JNcvx7Qd09dNpynQtx2h28ON"
    "hEZX7D59KaQFOwzOuNVA4MF74DnMCyw4AG5SKj8iudxwj0KIWgFqXAfQL8PTzZqIftl3Az1e0oz9MXoo1LKfj2bruuvDjaPX17+h"
    "t8PCzvqBUpVkobdKMWuayIpZkWeDE98yXMe2SUPt3WaqVfj7LAOn69ECsTo88ImJBwusDLKgDbhMZVHygFF3YDsAGmCNkDLsge3L"
    "bHdj/MzzfN0x1XPEUBmiFcwshWUGpAFL8hejGT5sqEkM03kErjB0QERejmQT3/csz1YqDpwGPBDVphW00no5lGfAnjmubygS+UWs"
    "9webZzK4YJL9OaD3QxrcMLl3N5HC6J8miyhhWtHlIaqvGUehON/VTdO1lME/gBrJYFv9dcEjwb6zhJUOxvgmAgamDK//AvD6yZZH"
    "Qhnz/AW45RjFEAXrL7KlI3aXRZL17tP68/hEcB/+8wxiKLV2uF7dbK2A2qtrymP+e/D7UdbEB+fNNk3zkRsUum4QnwdgeL4Hvo9p"
    "+SqEc75iKVw6e+OTt0IoUm5Z9Bfmm+JNbe/VzH0enmuZYMrA71Uv2X9yIY9RxljFxLMBnzfmOJ+Dd1IAIvervOtNrqNXOE8jCscx"
    "7IMRl/VauSF/0HmTXw0KRdLOozBkySYYq42oZMVYWDVq6+CW6fbRRjiWT2AvajNDVU0M1lrAkaFZyMJ2eJn0sUoKMyXtZH1HlfWB"
    "7RBEeOgitPLcaThSOzx6i1zxD7N6WyVh0GlogfHzPdsywX4+kifdC3j1Oa0J+E97pwEXayHZqlzEh5N4vDiO7VrEVt9H014n5vd7"
    "oOMbFjOppE3PQDVcE5AxGf801LJqqozokldBW7qLZU/ErM+F70cVcYfm/P6V8zUt4vkusZ81X/t1oJ4FXgjsrtIilKl0tAFwsQv4"
    "axaJqHTNGrMaGtKfI1vg2sCiTF95N/VOBxsP6ztcEqlwdf/5EDARj9iWYyjN6SasNWQcOC/6Cy+AsInpmcS3m/Ix64SuoqDkgjMC"
    "pnOHRZVPhdKLKmNL7TnckWWzstC79sXeJzFTH6t5HNsgnnqJ2z/hloKBguVOcfpkma/mCRZIgDgqcqcqem9ieaZLLKDKXoOVelSQ"
    "DcV4L4HGf+YUeIKaldTFUYs/+3w+Xys9T103gA35DYHTAS++a5qmcJrZdj5lKVufzlmM92P9fVv117qTdmvz8xljobZfJVWOh0PB"
    "9efrwDh0IOImaQFTM+A0NgZBxncRbNMllvrwHfXDgzFr+rKkVNjSFGNjuOJCJsDj3K0uxfAMITYh5hGVNE3ds2y9hqd8GkF+nuQZ"
    "nnhxxrlkGalV1x1F1yaAGl6mamvsujpsSJPaHIIWoQqGyq+uffzlAmwvhW7MgaZd8BHQ7FKQCUtQKoUYu6aq6bw6rmmBV+o6zfcR"
    "bGMegBJkBbSySPqXIJYWHbUnxWgpvwFr3gX7IIIsSuX3mM9pfHp9zQIpXjFpOI+eB0RHTTjK6qA+X4AXtmiWgbyZEHW7/hpAw9Z9"
    "ojvq66pP/1pjZyx+EjVFZ09Fsm3PBZajZlYIhONHe2a4T5NFDoa9tICvmiccKWLajqdc13GYR2W95IiJPJZFHLPB6XkobjzqpA0x"
    "PVM+bg0N80K7XCXgR+G/NdTgHtBBcZmcrtIlxS9TMNCJoUNi2XALkMfcClDAcnD8nheFrE/3faCU4Amm1fd7JYgyD/QR8u19bdhL"
    "8BsJseRyS3xqjbd2yHmO0hk23F+uVaPgVXFSlyboVVZRkQmdj7rG47VJ2+YtdLIF+qfVh4y774BKGAZ+Nus/mr3e9toGnd5blKou"
    "DvPBPBvnc4mfv1zQ22jREIraag3qQVVXXOhMXW2xYZuGT8CokhqTWqZVi69linLTR2Piij6iZDcPpBm/gu3y5DpaXCbx+ihIZ+q6"
    "DX6m1XjBH2JU7l9BjS8TvJDyxg8tPkbKPg9g2L9YOE2aAkfvK2R1a07uOCgnGI4+W9Bg/enWDgs4LvjuAzQWyUEp3UEx36tlhfNh"
    "2Z5tPqHkBTnQjh9dfLCm5Dule/Zo9bvjOTYxmqJp07PRJn2FuZanFrjs9IF7Bb+gLIKSx0UkjQ3xUxUKD2DSZXabxpsZbNtOe+i6"
    "YFYF/vI8H/O6xLFt239CyWL9sKod/xtNUPm91GkYYaYM7nHUhpr0XKXWYxZf736oAxdEybXxl0YcvtV2c5plivzbDH/vgK27GI3y"
    "H2MsVaX0/WDEw/weHmAGkSfqoC2GiKe947SP7wDD1JUuDO53TIWIgsmSrdj3jLEqdNjlMVf7TturbkR0rR1g/vQ0wQmgx9zaxiC1"
    "Cb9hsCjFUFoZa6iokdBmxrfDrt/acfxQI9GyLAMMleMo5T5h83zxPaPpMgrEpsZnSfED66+/fcH12JaUlL5I+XZAU9AgHucoC7TU"
    "1c26VARgtYrfRvHQagtcAQ65kJVvtQta+WU42kVRwgKbcSRU9XzDSHnWoTcMkynQ0tg2G9D7qiW+Ozl7eLsVBhy+gMHKtYUY0AQ/"
    "/aPhkTjoEn7PI/w8aNdPBrtJ46rxP/73f3eCFN4="
)


def ixp_text():
    import zlib
    return zlib.decompress(base64.b64decode(IXP_B64)).decode("utf-8")


def flag_targets():
    """(key, folder) for every place a Roblox client reads ClientAppSettings.json from."""
    out = []
    base = os.path.join(LOCAL, "Roblox", "Versions")
    if os.path.isdir(base):
        for d in os.listdir(base):
            p = os.path.join(base, d)
            if os.path.exists(os.path.join(p, "RobloxPlayerBeta.exe")):
                out.append((d, os.path.join(p, "ClientSettings")))
    if os.path.isdir(OWN_ROOT):
        for d in os.listdir(OWN_ROOT):
            p = os.path.join(OWN_ROOT, d)
            if os.path.exists(os.path.join(p, "RobloxPlayerBeta.exe")):
                out.append((d, os.path.join(p, "ClientSettings")))
    bs = os.path.join(LOCAL, "Bloxstrap")  # Bloxstrap copies this folder into its own install on launch
    if os.path.isdir(bs):
        out.append(("bloxstrap", os.path.join(bs, "Modifications", "ClientSettings")))
    return out


FPS_LOCK = threading.RLock()
FPS_STATE = {"writes": 0}  # how many files apply_fps had to change (the watcher uses this to know Roblox changed something)


def _write_if_different(path, text):
    """Write text to path only if the file differs. Returns True when it wrote."""
    try:
        with open(path, "r", encoding="utf-8", newline="") as f:
            if f.read() == text:
                return False
    except OSError:
        pass
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(text)
    FPS_STATE["writes"] += 1
    return True


def apply_fps(enable, data):
    """Turn the FPS flags + IxpSettings.json on/off. Returns number of locations checked.
    Only changes a file when it is not already right. Your own existing flags are kept; values we
    override are backed up and restored on disable."""
    with FPS_LOCK:
        data["fps"] = bool(enable)  # the watcher reads this, so it can never switch things back on
        targets = flag_targets()
        backup = data.setdefault("fps_backup", {})
        ixp_bk = data.setdefault("ixp_backup", {})
        for key, folder in targets:
            try:  # IxpSettings.json: replaced only while FPS optimization is ON, original restored when OFF
                ipath = os.path.join(folder, "IxpSettings.json")
                if enable:
                    if key not in ixp_bk:
                        try:
                            with open(ipath, "r", encoding="utf-8", newline="") as f:
                                ixp_bk[key] = f.read()
                        except OSError:
                            ixp_bk[key] = None
                    _write_if_different(ipath, ixp_text())
                elif key in ixp_bk:
                    if ixp_bk[key] is None:
                        if os.path.exists(ipath):
                            os.remove(ipath)
                    else:
                        _write_if_different(ipath, ixp_bk[key])
            except Exception:
                pass
            path = os.path.join(folder, "ClientAppSettings.json")
            try:
                with open(path, "r", encoding="utf-8") as f:
                    cur = json.load(f)
                if not isinstance(cur, dict):
                    cur = {}
            except Exception:
                cur = {}
            before = json.dumps(cur, sort_keys=True)
            bk = backup.setdefault(key, {})  # originals are remembered per location
            for k, v in FPS_FLAGS.items():
                if enable:
                    if k not in bk:
                        bk[k] = cur.get(k)
                    cur[k] = v
                elif bk.get(k) is not None:
                    cur[k] = bk[k]
                else:
                    cur.pop(k, None)
            if json.dumps(cur, sort_keys=True) != before or (cur and not os.path.exists(path)):
                if cur:
                    os.makedirs(folder, exist_ok=True)
                    with open(path, "w", encoding="utf-8") as f:
                        json.dump(cur, f, indent=2)
                    FPS_STATE["writes"] += 1
                elif os.path.exists(path):
                    os.remove(path)
                    FPS_STATE["writes"] += 1
        if not enable:
            backup.clear()
            ixp_bk.clear()
        else:  # forget backups of Roblox versions that no longer exist
            live = {k for k, _ in targets}
            for k in [k for k in ixp_bk if k not in live]:
                ixp_bk.pop(k, None)
        return len(targets)


# ----------------------------------------------------------------------------
# FPS unlocker: Roblox now has an official "Maximum Frame Rate" setting. It lives in
# GlobalBasicSettings_13.xml as FramerateCap. (The old DFIntTaskSchedulerTargetFps flag is
# NOT on Roblox's allowlist any more, so it does nothing.) Roblox rewrites this file when it
# closes, so it can only be changed while no Roblox client is running.
# ----------------------------------------------------------------------------
SETTINGS_XML = os.path.join(LOCAL, "Roblox", "GlobalBasicSettings_13.xml")
FPS_BOOST_CAP = 1000  # max FPS set while the FPS optimization is ON


def find_settings_xml():
    """Look for GlobalBasicSettings_13.xml in %LOCALAPPDATA%\\Roblox, then %APPDATA%\\Roblox;
    if _13 does not exist, use the highest-numbered GlobalBasicSettings_*.xml."""
    folders = [os.path.join(LOCAL, "Roblox"), os.path.join(os.environ.get("APPDATA", "."), "Roblox")]
    for fo in folders:
        p = os.path.join(fo, "GlobalBasicSettings_13.xml")
        if os.path.exists(p):
            return p
    best = None
    for fo in folders:
        try:
            for n in os.listdir(fo):
                m = re.fullmatch(r"GlobalBasicSettings_(\d+)\.xml", n)
                if m and (best is None or int(m.group(1)) > best[0]):
                    best = (int(m.group(1)), os.path.join(fo, n))
        except OSError:
            pass
    return best[1] if best else SETTINGS_XML
_CAP_RE = re.compile(r'(<int name="FramerateCap">)(-?\d+)(</int>)')


def roblox_running():
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq RobloxPlayerBeta.exe", "/NH"],
                             capture_output=True, text=True, creationflags=NO_WINDOW,
                             stdin=subprocess.DEVNULL).stdout
        return "RobloxPlayerBeta.exe" in out
    except Exception:
        return False


def set_framerate_cap(value, data):
    """value=int sets the cap; value=None restores what the user had. Returns a status string."""
    xml_path = find_settings_xml()
    try:
        with open(xml_path, "r", encoding="utf-8", newline="") as f:
            txt = f.read()
    except OSError:
        return "missing"
    m = _CAP_RE.search(txt)
    if value is not None:
        if "cap_backup" not in data:
            data["cap_backup"] = int(m.group(2)) if m else "absent"
        if m and int(m.group(2)) == value:
            return "same"  # already correct, leave the file alone
        if m:
            txt = txt[:m.start(2)] + str(value) + txt[m.end(2):]
        else:
            h = re.search(r'<Item class="UserGameSettings"[^>]*>\s*<Properties>', txt)
            if not h:
                return "error"
            txt = txt[:h.end()] + '<int name="FramerateCap">%d</int>' % value + txt[h.end():]
    else:
        orig = data.get("cap_backup")
        if orig is None:
            return "nothing"
        if orig == "absent":
            txt = _CAP_RE.sub("", txt, count=1)
        elif m:
            txt = txt[:m.start(2)] + str(orig) + txt[m.end(2):]
        data.pop("cap_backup", None)
    with open(xml_path, "w", encoding="utf-8", newline="") as f:
        f.write(txt)
    return "ok"


# ----------------------------------------------------------------------------
# FPS tracker: a small draggable overlay showing real FPS of each Roblox client.
# Uses Intel's PresentMon (ETW needs admin, so it runs elevated -> one UAC prompt).
# ----------------------------------------------------------------------------
class FpsTracker:
    def __init__(self, root, log):
        self.root, self.log = root, log
        self.frames, self.seen = {}, {}
        self.lock = threading.Lock()
        self.running = False
        self.win = self.label = None
        self.t0, self.warned = 0.0, False

    def start(self):
        import tkinter as tk
        if self.running:
            return True
        for p in (FPS_CSV, FPS_STOP):
            try:
                os.remove(p)
            except OSError:
                pass
        q = lambda x: x.replace("'", "''")
        ps = ("$pm='%s';$csv='%s';$stop='%s';"
              "$p=Start-Process -FilePath $pm -ArgumentList '--process_name','RobloxPlayerBeta.exe',"
              "'--output_file',('\"'+$csv+'\"'),'--no_console_stats','--session_name','DiamondLauncher_FPS',"
              "'--stop_existing_session' -WindowStyle Hidden -PassThru;"
              "while(-not (Test-Path $stop) -and -not $p.HasExited){Start-Sleep -Milliseconds 500};"
              "if(-not $p.HasExited){Stop-Process -Id $p.Id -Force};"
              "Remove-Item $stop -ErrorAction SilentlyContinue") % (q(PM_EXE), q(FPS_CSV), q(FPS_STOP))
        enc = base64.b64encode(ps.encode("utf-16-le")).decode()
        shell = ctypes.windll.shell32.ShellExecuteW
        shell.restype = ctypes.c_void_p
        rc = shell(None, "runas", "powershell.exe",
                   "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -EncodedCommand " + enc, None, 0)
        if (rc or 0) <= 32:
            self.log("FPS tracker: administrator permission was declined.")
            return False
        self.win = tk.Toplevel(self.root)
        self.win.overrideredirect(True)
        self.win.attributes("-topmost", True)
        self.win.attributes("-alpha", 0.85)
        self.win.configure(bg="black")
        self.win.geometry("+20+20")
        self.label = tk.Label(self.win, text="FPS: waiting for Roblox...", font=("Consolas", 13, "bold"),
                              fg="#39ff14", bg="black", justify="left", padx=8, pady=4)
        self.label.pack()
        drag = {}
        self.label.bind("<ButtonPress-1>", lambda e: drag.update(x=e.x, y=e.y))
        self.label.bind("<B1-Motion>", lambda e: self.win.geometry(
            "+%d+%d" % (self.win.winfo_x() + e.x - drag["x"], self.win.winfo_y() + e.y - drag["y"])))
        self.running = True
        self.t0, self.warned = time.time(), False
        threading.Thread(target=self._reader, daemon=True).start()
        self.root.after(500, self._tick)
        return True

    def stop(self):
        self.running = False
        try:
            open(FPS_STOP, "w").close()  # tells the elevated helper to close PresentMon
        except OSError:
            pass
        if self.win is not None:
            self.win.destroy()
            self.win = self.label = None
        with self.lock:
            self.frames.clear()
            self.seen.clear()

    def _add(self, pid, ms):
        with self.lock:
            d = self.frames.setdefault(pid, [deque(), 0.0])
            d[0].append(ms)
            d[1] += ms
            while len(d[0]) > 1 and d[1] - d[0][0] >= 1000:
                d[1] -= d[0].popleft()
            self.seen[pid] = time.time()

    def _reader(self):
        f, buf, header, i_ms, i_pid = None, "", None, None, None
        while self.running:
            if f is None:
                if os.path.exists(FPS_CSV):
                    try:
                        f = open(FPS_CSV, "r", encoding="utf-8", errors="ignore", newline="")
                    except OSError:
                        f = None
                if f is None:
                    time.sleep(0.5)
                    continue
            chunk = f.read()
            if not chunk:
                time.sleep(0.1)
                continue
            buf += chunk
            lines = buf.split("\n")
            buf = lines.pop()
            for line in lines:
                cols = line.strip("\r").lstrip("\ufeff").split(",")
                if header is None:
                    header = [c.strip().lower() for c in cols]
                    i_ms = next((header.index(n) for n in ("msbetweenpresents", "frametime") if n in header), None)
                    i_pid = header.index("processid") if "processid" in header else None
                    if i_ms is None:
                        self.log("FPS tracker: unexpected PresentMon output format.")
                    continue
                if i_ms is None or i_ms >= len(cols):
                    continue
                try:
                    ms = float(cols[i_ms])
                except ValueError:
                    continue
                if ms > 0:
                    self._add(cols[i_pid] if (i_pid is not None and i_pid < len(cols)) else "0", ms)

    def _tick(self):
        if not self.running or self.label is None:
            return
        now, rows = time.time(), []
        with self.lock:
            for pid in [p for p, t in self.seen.items() if now - t >= 3]:
                self.seen.pop(pid, None)
                self.frames.pop(pid, None)
            for pid in sorted(self.frames, key=lambda x: int(x) if x.isdigit() else 0):
                d = self.frames[pid]
                rows.append(len(d[0]) / d[1] * 1000.0 if d[1] > 0 else 0.0)
        if not rows:
            text = "FPS: waiting for Roblox..."
            if not self.warned and now - self.t0 > 20 and not os.path.exists(FPS_CSV):
                self.warned = True
                self.log("FPS tracker: PresentMon has not started. Accept the administrator prompt, "
                         "and allow PresentMon.exe in your antivirus (folder: %s)." % APP_DIR)
        elif len(rows) == 1:
            text = "FPS %d" % round(rows[0])
        else:
            text = "\n".join("Client %d: %d" % (i + 1, round(v)) for i, v in enumerate(rows))
        self.label.config(text=text)
        self.root.after(500, self._tick)


# ----------------------------------------------------------------------------
# Diamond icon. ICON_B64 is a 256px PNG used for the window icon and the logo. The full
# multi-size diamond.ico (desktop shortcut, .exe builds) is embedded at the bottom of this
# file as ICO_B64 and written out on demand, so no separate .ico file is needed.
# ----------------------------------------------------------------------------
ICON_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAMAAABrrFhUAAAB/lBMVEWo0fzj5Omm2P+Woa7k5OXHqfCtuvpYWV2ga+XHp/B6j6Yp"
    "SWQ+YYaur6+FqvoGMWDe1PLWyvYfKihCWXlMao4pNkNzX/8eePt1eoRupfW8v8UAAAGMS+EtfPAOGScDFRV0YfBTbfUbNU/7/f5w"
    "1v+o6P94sP+99P8VJjru/P7+/v4VK0YQIjEjRGUhPFooSm8vU3nu9/7m6PuHePJZc/Xy9vgVRHXC+f80W4MOOWfR2u+NpsCbZOVK"
    "jvJzrPtuhPYmQluSVuI2g/CSprsJGjKLufvW5fXT9f8AG0uqucnP9P/n6+9JaIvn6vwAAA7Syfi57P+xyfgPNWIiPWEABixEivGs"
    "mPK3w9BUlPLH0dvS5vzX8//k1fdWlfJ1qPWFm7KXpviyietnfZeVh/KNt/andujKuvXG3Pxie/Vzi6acZeWzqfbPtvI1Ojumdeep"
    "yfgBLF6I3f9IVmp9fX59lK6CcvGG2/+xh+q7lu27x9XS6PRrmfSPl/bEydBUVlaTlZUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdpjigAAAAgHRSTlPgZrVTH6CgDd3fWTdNFNRAiNkLQ1Aa//800lQB/v4WDf7+L8r+"
    "/v7+IvVwKhw7NUJGhYTc9bJI+k1CkHLc3PfZNPL0aibpkK44c9OoTc8kkNSXPjgt8bJ68ojPltLRuGOwuE/IqO6Y2Oda9KjbC8nb"
    "QPI1BWDk2OnkgazFvGwHCP4CGQcAABeISURBVHja7Z2Nf9zEmcfl2m24OCElQNu7vVu3WuOsR6uX3bDr7LbQTbIkDk43sDYJSaDt"
    "AYWjxVdfHA4TGvOvVzMjzYykmdG8SDI0Ox/gQwJZ7/PV8/zmeZ55JDmtF3w5SwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsA"
    "SwBLAEsASwBLAEsASwBLAD+mdXy89IAXGcDx2tpK6+ILDOD7Vr9z8fjFBXB4vNbZXosxvKgAvm+B7e2heQz82AEcnsYOsL29tnb8"
    "AwOwUf3i/pzT1kps/3bfOAacH77hUg7njocQQGft+PDMAZR+9bbyUqZw2FrbRmvF1AWcOqxvt1vxX5Uu9JFFCIetPgbQ+f70DAFk"
    "TK8hHrIkGA7ty0gCsQucOyMABdt1/V0nKggF/MtTuAfiNTwjAKn15FftmhfBEP/b5d73qQPEO+HxueYBsNe+AeMZCngLuLhC7I93"
    "wotNA2AuPt/4XlWLx6B3GP/kIQXQie0/vdwgAGp+znr2m3e73VnXcmVI9NKf8Xr8g1cY+2MVWIl3wtNzTQHgmk+srmfNUn84jLOe"
    "46z5yAnAWqt1+dxhAwCo+chuYnzm+3qVrSyHoNtqXRx0tnmrvwa14bBuAOmWtMFeeuTrHmO3C/+2X8knJSSCYJb3/exCkaC+IzgW"
    "l581n7no+Eu7VdhOIaC/IIdW68lKZ1u6UCTUCCB3+YnnY+Mrtbu4gtVBifk4ElbWTusCwFz+HjU/cfn8140X/qfZSj+B+cTnKvZD"
    "Jzg8rAdA1v2p+az16bf34XcPpuvr+/v7vuaCf2R9ij7ATz7Rhb+az1f3yswfrpzWFQKp+5PLj81nPD/+orHdfg0rJgE/3D+YfzKR"
    "uEEHbQSn9QDIX/7EfI+58MylDqtZ8ecwGCBcbz59PpQIYPvcRj0eQO3vpfZ7dKsLpm61lhdRJNERe8N8xouE4Uq8/a3Xlghl7Kfe"
    "Tzw/Y3sE/65ooY/KQvCnhUjAvn+uJ2ofWgNI7GfcP/X+IJgmxpPvfK3yRXFECYU4ElgCcTHUe72Nv2cdALj246sfuz7O1dxL43SN"
    "xqMKV/xh6QdfStLCmMD6/Dnj/q3p5dgzNzQJOHr2b7Dql15+eDHO38yv31a60CeyH78KBce9S13gP1qvo9jUJOBo2N9i7U8uP4r9"
    "8OBBp/E18Ra+P58QBWh1YZ2oTcAxtt9LvT++EA87Z7AGry4ib3WbNEWDbtI50SLg6Nmfyn96+adQ+rxJ/HWGQxMjhkPTPwf/EbnR"
    "QbIZdp7AQpQSaKsScIyuf5dGfzRC9r/xGNzeuaK9+gCAN7TXlfcA+Dsk8NrCu4MBTOZTD7ePNAk4Rv7vUvvHd/eg/Zv/D8C7ugR2"
    "3gWgD55d0SbQBz/ZegcSOO+FWAbPzwLcONEl4Ojb71H7w2h8DTqjs7m5eQv0tQHcBsMO6Gs7wDPQ39p6GxLo/Ong59D+vbmPugWo"
    "baZFwNGzf0blz0f234X2/19sv4EL7Oz0QWcbgPd0CYDYASCBP0ACEQSwOvNxH0abgKNlP5H/ANvvPe2k9m9u/kTXBWAEbG/3wW1N"
    "B7gNbm3B9fYWJPDbh7EEej5qG8SpCYwCnKypEXC07cfZX9H+zU1dF4gdYAjrN6DtAM5WQuARTAi2t7/dDU0JOCb2o/CP/f9m/OPf"
    "3SRL0wV2dgCACtYH72nJ4OPEASCBt79Au2IEi6SkdaRJwDH0/9h+707W/s3NvtZWGEsgOtsegsc69sdb4MtbZCECe0cRLJD2g1QH"
    "NAg4Bva7yP7dgv2aLoAjQDsGHoNJ7PuUgAOjYIxLRA6BspzQMbv+UTSG6e97m9mlkw3BCEhauODRFR0HeGeLXYjAswsjLoHyrNjR"
    "sB9Vf7DnBe2fcOyHW+HOjmYEwBjo6+VAW0UCw5RAkNWBUgKO0fUPkf1vbBaWhgugJAAvjRgoOAAhcHdMfMDTIOCU1v+9jP3o+o9Q"
    "+usU7dfIhnASkMbA7SvGDrCVJIXDp0eUgHoUOHr24/T3wlBgv0ZCTCNAIwZwEiwg0Hnq0SjI1AVtCQFH0X6XsZ+mv+YusMNEwLZ6"
    "Ogx4DkDTYuoDyjogBoD6f0n9z9qfS//yS3ErZCNAOR0mSTCHAEqLH3gCHRD7gCO1v61tv2pCjJKAHXqcAfSSYB4BmBY/2C3uBb2U"
    "gDoAjIupf6n9RzcL6Y+JC6RpMHUBlXT4sdABSFr87TjMKGHSJxSnhI58A2Tsd9H1v1Nmv1pCzEqgcjqcTYI5CL5ASSH0gXUSBUmX"
    "TCgDjigANrL9H2z/7oNy+5VcIE2DtWIglwRzCKC0+GgUE5hmfEAihI5cAGCbzU36H2HITX9NsiGaBtMYKE2HeTkQj8DehXEk2gxV"
    "ALACkG6AuP7hp7/crbAkIc5HgFIq0BdsgcWk8Bok4OaSYoEMcAGwAoA3gNj+0UKQ/hq4QCYJUEyHFRyAEnAhgWw6IAgCRy4AiQD6"
    "frQQpr/62VA2CVBMh1UcgKTF572EACOEG8nFlQNIA4BkgOjgP7b/2lDZ/tKEuBgBpTEgSoJFaTEikAihlxDgBoEjd4CkARZ6svRX"
    "1wV2OBFQmg4DNQegaXFMgBFCoQs4IgWM7fdSAYx2z3d07C/ZCnkRUJIOS5JgUVp8ZzfCQsjuhUUXcIQOQALAX9e2X54QZ9NgtVRA"
    "kgQL0+IDNiOEUc1zAYezBWSOgOIA8G4qpD/qLpBPg1XS4ccaDkDS4gde2iOTuIAjdgC8A/j+wQN9+2UJMU8CS9LhsiRYlBZ7yVYA"
    "dVDgAg4vB+hRBZwa2i9xgXwarBADpUmwKC3edf2MC5QAKDpAEHhq6a96NlRMg0vTYbUciEdg8KrnpzrIjwEeAJwDYAGY3TK0X5gQ"
    "iyJAkgr0lbfAYlL4BBNIXKAYA45MAqcesv+NTaMlcAFuEiBNh40cgBKYTZlcoBwAEwHT7pM9jfRPLRviJwHSdNjMAUhavHowxS7A"
    "jQFHKAFuMHsytLBfkBCLI0AQA+pJsCgtXp1PPRoDKgBQBAQH54a66U+5C+xIIkCQDgNTByBp8eo8EMaAwyuEIYBgvmppP3crlEUA"
    "Nx3WSoJFafFzREANQBIBQWu1Y2s/LyEWJQHiVEArCRalxc9bLhEBOYBUApD9725aLugCOyppsDgdfmzlAGi9EpuyMmdVsBxAbwVe"
    "/03rlU+IZRKIATy2TYI5C6bFgzZfBbMA0k0gaA3i/aNvvwAAJb9R/v8PrL/FYIijQB3A7EkMAP7wf5HVh0HQCni5IB9AdwqZ/ftb"
    "H79lu94HP/u9bA3Ap1cl6z4Y/K6CFe8Ew1+1u+oAvAOYA31x47+s1x/Bvd/I1gB8/Wvx+sV98NP/tF//BnOB2AE0PADvgn+3B/AW"
    "AP8jsf/NAbgqAfDrCfhve/tPcAB0FQDQbTCYP4//2DvWAG7cAr+3AADA76zt/wvcA+ZBV2UXYGqhYA4LwQ+tCbwP/mwO4FMwuG5r"
    "/3UoANOuywIozwRhM6QLhfADexGYmAP4WwUS8FFsxSezwFNMhFpMMfhJ/Ecf1SsCJQDu2UsAFMA78ylTDysWQ543nVchhDcGMhEo"
    "AWAvAd+gNJhpCJQUQ0w57LnTAyiEb9cpAnIAVwGwlIC/QgGcTQPSEtpQAkBagrMKhPCP4H1TAPfB5xUI4BMvcNUaIlkRwKdiUAjt"
    "8qGPAXjTEIC1BMA68MvZFPeFy1tieRFwXX/3y/gjvrATASARATkAAF6yF8ADn56OKTRFszHg+gd3rPMhmQhIAVwFK9dtM6DJATwd"
    "8xTb4pkYwEGwfvDQVghlIiAFYCkBUAD3PHo6qHAwkosBfDTm7VkKoUwEpADsJOD6R3CE3PVdaQRID0fx4bj7aiyEf7hRjwhIAQys"
    "JOArWAJmHKBXfjrMOx73PTgd4Fi4wAT8wwSAXRZwggZn0YgEOyOiACDvAu76zFIIPwM/MwFwH9yzFMDd3HyAwoBEzgVwEES7Eysh"
    "/BgM3jQA8Dm4by4A8ExsgYeGPcnZsHRIKo0B1/fHVoWhRARkAAbgf+1KQJdOjaMnEaoMSXFdYN9fwCGxRzWIgASAjQRAAbwJ7yYt"
    "nZGSDkqmQxJTP/T+ZFMYikVAAuAf5hLwDb5zgI7JCUekhKOybXZMJoAy8MBCBsQiIAFgLgEvwRLQC/MTUoqjstxRST/2AYvCUCwC"
    "EgDGEoAEMErvmujKFFA4Lt9iZgW99FkRFkI4Ad/pAvjaWAKgAH7phbkAEN0y4chumOkxO0HofmJeGApFQAzgU/BzixIwFQDX079f"
    "QBQEEZqXNMsIvwOTNzUBmPZDoQA+3CWT0tI5YdlNU8WB2VgIjQvDD0SdUTGAiZkEoBJwQe+ZSVIAvXuGsjeNkFsG4igYGArhjQl4"
    "WQ+AoQSgHtjdMSsA0gCQ3je4kZ8ZDtEjY4wKQ5EICAEYSsBX7K0CroL90jtHN8iDY4gMfGkoAyIREAIwk4CTRAAzO2BP+hwFR3bv"
    "fHrjiNdNb5zxDAtDkQgIARhJACoBveSGKY9Ngdq69w4z986RW6fgrfOmhaHojFQIwORIBAngKPTVBaDk+QF5GUAZ4WLPKB8SdEZF"
    "AIxORT9KBHCqLABlT5AoZANxWTRChaG2EArOSEUATCTgq+ROodxtIm2zByjkb6Ck98+ZFYaCM1IRAIN+6ElSAvq5IrjkUTryh6i0"
    "8ynxFBJ4YCCEAhEQAdCXACiAtxYh8/AAlQAofYxOO3cPKbqHFj1A8MNKREAAQF8CUAYUxQq4nxeAlvFjdPgysO+H4cigMOSLgACA"
    "vgSgHthCUALYAMhXxngnOK8/OsEXAQEAbQlAJWBWAHvlAqj6LDHSHqJCeFNbCPmDEgIAuhJAS0CNDED1aXKFosCFBL7Vzoe4IsAH"
    "oNsPRWMQl0K/2ANoWT5NTnQvcRwF2h0y7hkpH4DmqSgSwAujUF8A9B6oyPYGwlGkOzrBPSPlA9CUgFeSHpheBqT3SM1CPhS6uqMT"
    "3M4oH4DeYAQRQNfVFQDVh6oWigIoA7u6hSFPBLgA9AYj8Clg5Ks2AY0eq8vpjuh3yHgiwAWgJQGoBEQPDwo4T8yo7MHKnO5IGI71"
    "Rid4IsAFoCMB19MSMCOAPfXni+s8WTp5rEaXPFblrlaHjCcCXAA6gxGoBHTDwgNDqnyydLEsIkL4VKtDxjkj5QHQyQJO8BPUTDIg"
    "3afL87ojmh0yTmeUB0BjMCLpgWn2QAzfL8Dpjmh2yDhnpDwA6qei6BRwRAVQLwMweMFCMRsIQ40OGUcEeADUT0VRCTgOdXsgpq/Y"
    "4HVHwvFdjcKwKAIcAOoSgMYgSAloFAB6L1nhdUciV6NDVhQBDgDlwQhYAn4L7d/XL4EMX7PD6Y5oFYZFEeAAUJUANAaBHiJqUAKZ"
    "vmeI1x2JxsqFYVEEOAAUJQAJ4GthaNADMQQg6o6EofroRGFQoghA9VQUjUG4NhmANgBhd2SsPDpREIEiAMVTUdoDsxGAlv7b5njd"
    "EfXRicIZaRGAWj8U9cA8awEwAMDtjkSeYmFYOCMtAlA6FcUlYGTYAzEHIMyHovEzJSEsDEoUAChJAB6DGIWGPRALAKLuSDhSHJ3I"
    "i0ABgJIEwAzo6cK4B2IDQNgdWajN1OdFoABARQJOUgE07IFYARB0R1QLw7wIFAAoSAAqAd3IvAdiDYDbHYk8lcIwf0ZaAFB+JPJX"
    "UgKa9kDsAAi7I9FYpTDMdUbzABRORWEGdFd3DqRKAMLZkVBldCJ3RpoHUC4BqAd2KfIteiC2AITdkYVCYZg7I80DKO2HnuAS0KoH"
    "UgUAfjagMDqRE4E8gDIJQGMQzNtULAXAEICwOxIpjE5kRSAHoEwC8BhEGNr1QOwBCGdHFEYnsiKQA1AmAbgHZtsDqQCAsDsyLn3q"
    "RFYEcgBKJCApASsogaoAwO+OlI5OZAclcgDkEpAvAU17IFUAEHZHyjtkGRHIApD3Q2EG9AyXgJVkAHYARN2R8g5Z5ow0C0B6KsqM"
    "QVQmADYAhLMjYcnoROaMNAtAKgFoDGLMDkLaC4AtAH53ZCwfnch0RrMAZIMReQG0zoCsAUjyIXlhyIpABoBsMIKcAlbQA6kKgLA7"
    "UtIhY0UgA0AiAUwPrJoSoBIAou5IUhh+qCACGQBiCcBjEKOwmh5IdQCEsyOhbHSCFYEMAPFgBCoBx1X1QKoFwO+OjGWjE8wZKQtA"
    "nAWckBfJVdIDqRCAuDsiE0KmM8oCEA5GIAE8qjoDqgaAsDsi65AxZ6QsANGpKB6DiMLKeiCVAhB1R8JIPDrBiAALQHQqmpSA1fVA"
    "KgfAzwZG4qdOUBFgAIgkAI1BLKrsgVQLQNwdGQs7ZFQEGACCwYhvMj0wr+IAqAKAsDsiLgypCDAA+BLwEikB96ssgSoFIOqOiAtD"
    "KgIMAK4EIAG8FoZhxSVQ5QC43RHx6AQZlKAA+KeiH+ESsNoeSOUAxN0R0egEEQEKgHsqypSA1WcAFQIQd0eO+KMT5IyUAuD1Q5ke"
    "WD0CUBkAYXdEUBiSM1IKgHMqmpaA9QlApQC43RHB6AQZlCAAOBKAxyDC6nsgdQAQ50PhBV5hmIoAAcCRADQGMa6hB1ILAHF3ZMx7"
    "6kQqAgRAUQJOsgLo1mN/dQDE3ZEjTmGYigABUJCAv5C3SFfeA6kJgLA7wisM0zNSAiB/JJKOQdTRA6kRALc7wh2dSDqjKYDCqSjM"
    "gF4b1dMDqQuAuDvCGZ1IzkhTAHkJYHpgQX0CWDUAcXekWBgmZ6QpgFw/FI1BHNXVA6kPgLg7cik/OpGIQAogKwGpANbUA6kXAP/O"
    "muhSfnQCi0ACICsBKAO6FtbWA6kRgLg7UhidwCKQAMhKABJAIgBenQFQOQBud4SeGD7Ki0ACICMBqAQ8qrcEqg+AuCy6lB2dwIMS"
    "CQBWAtISsNYSqF4A/O5IdJTtkCERwADYfmg6BlFjD6ReAJI7a8YZIURnpBgAcyqKxyCQALo1ZwB1AShkA17aIsyOTqAzUgyAkYBX"
    "aA+sAQGoBwBPBjijE6gzigHQwQjaA+OWQD8eAMXuSPHEEIoAAkAHI9IxiFwPpF2XANQEIJcPJQTW8x0yKAIQwC+IBOR7YG7dAlAX"
    "AJ4M4MeysqMTUASQB6QScD2ZhIcB0JT9NQEQ5UOZp04gEYAAVhIJQCXggmwA0P5ZrQJYI4BCdyT1gWhBRyfgGekAfJ32Q+kYBN4A"
    "ut36SqBGADBPZaWFIfv4HdgZjQF8ik9F6RxYQDeAukqg+gEwZVGb9gZcnz514kYsArdiDfj6b+hUFJ0C4sfh0Ay4bgGoEwBfCKfs"
    "TD0UgQm4ivuh+IGAxP5GBLBeAGIC5IUdE/DnCbiPJAC/FIPeC0kyoFoFoHYAJB+iBNDLGpI3OX4G7t0Cn0MJ+Cb7RNT0+vdqFoB6"
    "AWSEkCEQ+Osz2CF7+Zff4fdC/zR5KYbP+n9y/WsOgHoBECEkWwGRQvzCjhsYwEtIAF9dxNs/Y3+vEfvrBcDIAG0O4BeYoTc5fjBB"
    "AK7DEvD8bhL+bPxv1CwATQDIE0gODT04OuF8Bu2/l7wXMWN/ryH7awaQF0LiA65/AIVwCAHAtzY8PEiOgFn7axfABgBwtoL04Hi+"
    "EhveB6APS8Dd5AAEhX+T9tcOgM0Is04wnQ0QgU7yYlji/rMm7a8fQCYnJgQgBO9JLIRDKIarB6j/j+1Prz/eAP4FABR9ACPwpkgG"
    "4vV8PvUY8xu1vyEALIEEQRzu0zl8s3VnMA+SF4JQ92/M/iYAMAR6xAkggu60FQvhECZI+OqTy99uNbABNgcgJbCRcQIIIWitrAT4"
    "2mPzcf7foP3NAMgRgAhmCYJWq0vNb6fu35T/NwYgTwAiwH4QBMzFPwP7mwKACECTNhIlSBiQhX+refsbA5AhwF8Z85uyvzkAmACW"
    "NyEDaHaz9jcIgEXAXnUa+9T85uxvFAAmgBAUIiExuuHL3zSAhABGkDgEY3K78cvfOACKoJ3/D6n1Gw1/oaYBEARIClPb2+Q3G/86"
    "zQNgEBTWGXyZswAgQnAmX+VsABQhnNnXODsAP5C1BLAEsASwBLAEsASwBPDirn8CkjNLkiJQcG8AAAAASUVORK5CYII="
)


def icon_png():
    return base64.b64decode("".join(ICON_B64))


def ensure_ico(path=None, force=False):
    """Writes diamond.ico (the full multi-size icon) and returns its path."""
    path = path or os.path.join(APP_DIR, "diamond.ico")
    blob = base64.b64decode("".join(ICO_B64))
    if force or not os.path.exists(path) or os.path.getsize(path) != len(blob):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "wb") as f:
            f.write(blob)
    return path


def create_desktop_shortcut():
    bat = sys.executable if getattr(sys, "frozen", False) else os.path.abspath(__file__)
    q = lambda x: x.replace("'", "''")
    ps = ("$d=[Environment]::GetFolderPath('Desktop');$s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\\Glint.lnk');"
          "$s.TargetPath='%s';$s.WorkingDirectory='%s';$s.IconLocation='%s';$s.WindowStyle=7;"
          "$s.Description='Glint';$s.Save()") % (q(bat), q(os.path.dirname(bat)), q(ensure_ico()))
    subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                   creationflags=NO_WINDOW, stdin=subprocess.DEVNULL, capture_output=True)


def shift_held():
    try:
        return bool(ctypes.windll.user32.GetKeyState(0x10) & 0x8000)
    except Exception:
        return False


_tracker_mutex = None


def claim_tracker_slot():
    """Only one running copy may own the FPS tracker (one PresentMon session)."""
    global _tracker_mutex
    try:
        k = ctypes.windll.kernel32
        k.CreateMutexW.restype = ctypes.c_void_p
        _tracker_mutex = k.CreateMutexW(None, False, "DiamondLauncher_FpsTracker")
        return k.GetLastError() != 183  # 183 = ERROR_ALREADY_EXISTS
    except Exception:
        return True


# ----------------------------------------------------------------------------
# GUI: one dark theme shared by the launch screen and the settings window.
# ----------------------------------------------------------------------------
BG, PANEL, CARD, CARD_HOVER = "#0d0f1f", "#141831", "#171a33", "#20244a"
LINE, SEL = "#2a2f5e", "#283278"
FG, MUTED, CYAN, VIOLET = "#f2f5ff", "#8a92bd", "#4fd8ff", "#9b6bff"
GREEN, RED, INK = "#6bff9e", "#ff7a8a", "#06101f"
UI, UIB = "Segoe UI", "Segoe UI Semibold"
DEFAULT_GAP = 7  # seconds between two launches (a new Roblox client needs a moment to start)


# ----------------------------------------------------------------------------
# Glint's own Roblox (like Bloxstrap). Glint downloads Roblox itself into %LOCALAPPDATA%\Glint\Versions
# and starts that copy; the normal Roblox install is never touched. It is the same method Roblox's own
# bootstrapper uses: latest version id -> package manifest -> download + check each package -> unzip each
# one into its folder. Off unless switched on (asked once on first run).
# ----------------------------------------------------------------------------
OWN_ROOT = os.path.join(LOCAL, "Glint", "Versions")
OWN_VERSION_API = "https://clientsettingscdn.roblox.com/v2/client-version/WindowsPlayer"
OWN_MIRRORS = ("https://setup.rbxcdn.com/", "https://setup-cf.rbxcdn.com/", "https://setup-ak.rbxcdn.com/",
               "https://s3.amazonaws.com/setup.roblox.com/")
OWN_PACKAGES = {  # package -> folder it unzips into (same table Roblox's bootstrapper uses)
    "RobloxApp.zip": "", "Libraries.zip": "", "WebView2.zip": "",
    "shaders.zip": "shaders\\", "ssl.zip": "ssl\\",
    "content-avatar.zip": "content\\avatar\\", "content-configs.zip": "content\\configs\\",
    "content-fonts.zip": "content\\fonts\\", "content-sky.zip": "content\\sky\\",
    "content-sounds.zip": "content\\sounds\\", "content-textures2.zip": "content\\textures\\",
    "content-models.zip": "content\\models\\",
    "content-textures3.zip": "PlatformContent\\pc\\textures\\", "content-terrain.zip": "PlatformContent\\pc\\terrain\\",
    "content-platform-fonts.zip": "PlatformContent\\pc\\fonts\\",
    "content-platform-dictionaries.zip": "PlatformContent\\pc\\shared_compression_dictionaries\\",
    "extracontent-luapackages.zip": "ExtraContent\\LuaPackages\\",
    "extracontent-translations.zip": "ExtraContent\\translations\\",
    "extracontent-models.zip": "ExtraContent\\models\\", "extracontent-textures.zip": "ExtraContent\\textures\\",
    "extracontent-places.zip": "ExtraContent\\places\\",
}
OWN_SKIP = ("WebView2RuntimeInstaller.zip",)  # Windows 10/11 already has WebView2 (Glint's sign-in needs it too)
APP_SETTINGS_XML = ('<?xml version="1.0" encoding="UTF-8"?>\r\n<Settings>\r\n\t<ContentFolder>content</ContentFolder>\r\n'
                    '\t<BaseUrl>http://www.roblox.com</BaseUrl>\r\n</Settings>\r\n')
OWN_CLIENT = False  # True = launch from Glint's own copy
_own_lock = threading.Lock()
_own_hook = None  # called after an install/update (Glint uses it to re-apply the FPS flags)


def set_own_client(on):
    global OWN_CLIENT
    OWN_CLIENT = bool(on)


def set_own_hook(fn):
    global _own_hook
    _own_hook = fn


def own_latest_version():
    st, _, body = http("GET", OWN_VERSION_API, {"User-Agent": UA})
    if st != 200:
        raise RuntimeError("Roblox version check failed (HTTP %d)" % st)
    v = json.loads(body.decode("utf-8", "ignore")).get("clientVersionUpload")
    if not v or not re.match(r"^version-[0-9a-f]+$", v):
        raise RuntimeError("Roblox gave an unexpected version answer")
    return v


def own_installed():
    """(version, folder) of the newest complete copy Glint installed, or (None, None)."""
    best, best_t = (None, None), -1
    try:
        for d in os.listdir(OWN_ROOT):
            p = os.path.join(OWN_ROOT, d)
            mark = os.path.join(p, ".glint_ok")
            if re.match(r"^version-[0-9a-f]+$", d) and os.path.exists(mark) \
                    and os.path.exists(os.path.join(p, "RobloxPlayerBeta.exe")):
                if os.path.getmtime(mark) >= best_t:
                    best, best_t = (d, p), os.path.getmtime(mark)
    except OSError:
        pass
    return best


def _own_manifest(version):
    last = None
    for base in OWN_MIRRORS:
        try:
            req = urllib.request.Request("%s%s-rbxPkgManifest.txt" % (base, version), headers={"User-Agent": UA})
            text = urllib.request.urlopen(req, timeout=30).read().decode("utf-8", "ignore")
            lines = [l.strip() for l in text.splitlines() if l.strip()]
            if lines and lines[0].lower() == "v0":
                lines = lines[1:]
            out = [(lines[i], lines[i + 1]) for i in range(0, len(lines) - 3, 4) if lines[i].lower().endswith(".zip")]
            if out:
                return out  # (package name, md5)
        except Exception as e:
            last = e
    raise RuntimeError("could not read Roblox's package list (%s)" % last)


def _own_md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest().lower()


def _own_download(version, name, md5, dest):
    last = None
    for attempt in range(2):
        for base in OWN_MIRRORS:
            try:
                req = urllib.request.Request("%s%s-%s" % (base, version, name), headers={"User-Agent": UA})
                with urllib.request.urlopen(req, timeout=30) as r, open(dest, "wb") as f:
                    shutil.copyfileobj(r, f, 1 << 20)
                if not md5 or _own_md5(dest) == md5.lower():
                    return
                last = "checksum mismatch"
            except Exception as e:
                last = e
    raise RuntimeError("could not download %s (%s)" % (name, last))


def _own_subdir(name):
    if name in OWN_PACKAGES:
        return OWN_PACKAGES[name]
    base = name[:-4] if name.lower().endswith(".zip") else name  # a package Roblox added after this was written: guess
    if base.startswith("extracontent-"):
        return "ExtraContent\\" + base[len("extracontent-"):] + "\\"
    if base.startswith("content-platform-"):
        return "PlatformContent\\pc\\" + base[len("content-platform-"):] + "\\"
    if base.startswith("content-"):
        return "content\\" + base[len("content-"):] + "\\"
    return ""


def _own_extract(zpath, root, sub):
    target = os.path.realpath(os.path.join(root, *[p for p in sub.split("\\") if p]))
    with zipfile.ZipFile(zpath) as z:
        for info in z.infolist():
            name = info.filename.replace("\\", "/")
            if not name or name.endswith("/"):
                continue
            out = os.path.realpath(os.path.join(target, *[p for p in name.split("/") if p]))
            if not out.startswith(target + os.sep):  # a file may never land outside its own package folder
                raise RuntimeError("unsafe path inside a package: %s" % name)
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with z.open(info) as src, open(out, "wb") as dst:
                shutil.copyfileobj(src, dst, 1 << 20)


def own_install(version, log):
    from concurrent.futures import ThreadPoolExecutor
    os.makedirs(OWN_ROOT, exist_ok=True)
    tmp, dl = os.path.join(OWN_ROOT, version + ".partial"), os.path.join(OWN_ROOT, version + ".dl")
    for d in (tmp, dl):
        shutil.rmtree(d, ignore_errors=True)
        os.makedirs(d)
    try:
        pk = [p for p in _own_manifest(version) if p[0] not in OWN_SKIP]
        if not any(n == "RobloxApp.zip" for n, _ in pk):
            raise RuntimeError("Roblox's package list has no RobloxApp.zip")
        log("Downloading Roblox %s (%d packages). The first time takes a few minutes ..." % (version, len(pk)))

        def job(p):
            _own_download(version, p[0], p[1], os.path.join(dl, p[0]))
            return p[0]
        with ThreadPoolExecutor(max_workers=4) as ex:
            for i, n in enumerate(ex.map(job, pk), 1):
                log("  downloaded %d/%d  %s" % (i, len(pk), n))
        log("Unpacking ...")
        for n, _ in pk:
            if n not in OWN_PACKAGES:
                log("  (new package %s - guessing its folder: %s)" % (n, _own_subdir(n) or "root"))
            _own_extract(os.path.join(dl, n), tmp, _own_subdir(n))
        with open(os.path.join(tmp, "AppSettings.xml"), "w", encoding="utf-8", newline="") as f:
            f.write(APP_SETTINGS_XML)
        final = os.path.join(OWN_ROOT, version)
        shutil.rmtree(final, ignore_errors=True)
        os.replace(tmp, final)
        with open(os.path.join(final, ".glint_ok"), "w") as f:  # written last: a half-finished install is never used
            f.write(version)
    finally:
        shutil.rmtree(dl, ignore_errors=True)
        shutil.rmtree(tmp, ignore_errors=True)


def own_cleanup(keep):
    if roblox_running():  # an older client may still be reading its files
        return
    try:
        for d in os.listdir(OWN_ROOT):
            if d.startswith("version-") and not (d == keep):
                shutil.rmtree(os.path.join(OWN_ROOT, d), ignore_errors=True)
    except OSError:
        pass


def own_ensure(log):
    """Installs / updates Glint's own Roblox if needed. Returns the path to its RobloxPlayerBeta.exe."""
    with _own_lock:
        have, folder = own_installed()
        try:
            latest = own_latest_version()
        except Exception as e:
            if not have:
                raise RuntimeError("could not reach Roblox to download it (%s)" % e)
            log("Could not check for a Roblox update (%s) - using the installed copy." % e)
            return os.path.join(folder, "RobloxPlayerBeta.exe")
        if latest != have:
            try:
                own_install(latest, log)
            except Exception as e:
                if not have:
                    raise
                log("Roblox update failed (%s) - using the installed copy." % e)
                return os.path.join(folder, "RobloxPlayerBeta.exe")
            have, folder = latest, os.path.join(OWN_ROOT, latest)
            log("Glint's Roblox is up to date (%s)." % latest)
            own_cleanup(latest)
            if _own_hook:
                try:
                    _own_hook()
                except Exception:
                    pass
        return os.path.join(folder, "RobloxPlayerBeta.exe")


def own_launch(uri):
    """Starts Glint's own Roblox with a roblox-player: / roblox: link (passed as the first argument, like Bloxstrap)."""
    if not LINK_OK.match(uri):
        raise ValueError("link looks unsafe, not opened")
    have, folder = own_installed()
    if not have:
        folder = os.path.dirname(own_ensure(lambda m: None))
    subprocess.Popen([os.path.join(folder, "RobloxPlayerBeta.exe"), uri], cwd=folder, close_fds=True)


# ----------------------------------------------------------------------------
# Roblox links (the Play button on roblox.com) -> Glint, like Bloxstrap. OFF unless switched on.
# Windows decides which program opens roblox-player: / roblox: links from per-user registry keys.
# We point them at Glint, remember Roblox's own handler, and pass launches on to it (so it never loops).
# ----------------------------------------------------------------------------
PROTOCOLS = ("roblox-player", "roblox")
HANDLER_FILE = os.path.join(APP_DIR, "handlers.json")  # copy of Roblox's own handlers (to chain to / restore)
LINK_DIR = os.path.join(APP_DIR, "links")  # a second Glint drops links here for the running one
LINK_OK = re.compile(r'^(?:roblox-player|roblox):[^\s"\x00-\x1f]{1,8000}$', re.I)  # no quotes/spaces: safe to pass on


def _our_command():
    exe = sys.executable
    if getattr(sys, "frozen", False):
        return '"%s" "%%1"' % exe
    if exe.lower().endswith("python.exe") and os.path.exists(exe[:-10] + "pythonw.exe"):
        exe = exe[:-10] + "pythonw.exe"  # no console window
    return '"%s" -x "%s" "%%1"' % (exe, os.path.abspath(__file__))


def _is_ours(cmd):
    return bool(cmd) and bool(re.search(r"glint[\w .\-]*\.(?:exe|bat)", cmd, re.I))


def _reg_path(hive, proto, sub=""):
    import winreg
    base = r"Software\Classes\%s" % proto if hive == winreg.HKEY_CURRENT_USER else proto
    return base + sub


def _read_cmd(hive, proto):
    import winreg
    try:
        with winreg.OpenKey(hive, _reg_path(hive, proto, r"\shell\open\command")) as k:
            return winreg.QueryValueEx(k, "")[0]
    except OSError:
        return None


def _key_exists(hive, path):
    import winreg
    try:
        winreg.CloseKey(winreg.OpenKey(hive, path))
        return True
    except OSError:
        return False


def _del_tree(hive, path):
    import winreg
    try:
        with winreg.OpenKey(hive, path, 0, winreg.KEY_ALL_ACCESS) as k:
            while True:
                try:
                    sub = winreg.EnumKey(k, 0)
                except OSError:
                    break
                _del_tree(hive, path + "\\" + sub)
        winreg.DeleteKey(hive, path)
    except OSError:
        pass


def _load_handlers():
    try:
        with open(HANDLER_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def find_roblox_launcher():
    """Newest RobloxPlayerLauncher.exe on this PC (used if the saved handler is missing)."""
    best, best_t = None, 0
    for root_dir in (os.path.join(os.environ.get("LOCALAPPDATA", ""), "Roblox", "Versions"),
                     os.path.join(os.environ.get("ProgramFiles(x86)", ""), "Roblox", "Versions"),
                     os.path.join(os.environ.get("ProgramFiles", ""), "Roblox", "Versions")):
        try:
            for d in os.listdir(root_dir):
                exe = os.path.join(root_dir, d, "RobloxPlayerLauncher.exe")
                if os.path.exists(exe) and os.path.getmtime(exe) >= best_t:
                    best, best_t = exe, os.path.getmtime(exe)
        except OSError:
            pass
    return best


def enable_protocol():
    """Makes Windows send roblox-player: and roblox: links to Glint. Returns an error text, or None if it worked."""
    try:
        import winreg
    except ImportError:
        return "This only works on Windows."
    try:
        hkcu, ours = winreg.HKEY_CURRENT_USER, _our_command()
        saved = _load_handlers()
        for proto in PROTOCOLS:  # 1. remember what Roblox had (before touching anything)
            cur = _read_cmd(hkcu, proto)
            if not _is_ours(cur):
                eff = _read_cmd(winreg.HKEY_CLASSES_ROOT, proto)  # what Windows really uses right now
                saved[proto] = {"orig": None if _is_ours(eff) else eff, "hkcu": cur,
                                "existed": _key_exists(hkcu, _reg_path(hkcu, proto))}
            elif proto not in saved:
                saved[proto] = {"orig": None, "hkcu": None, "existed": False}
        os.makedirs(APP_DIR, exist_ok=True)
        with open(HANDLER_FILE, "w", encoding="utf-8") as f:
            json.dump(saved, f)
        for proto in PROTOCOLS:  # 2. point the links at Glint
            base = _reg_path(hkcu, proto)
            fresh = not _key_exists(hkcu, base)
            with winreg.CreateKey(hkcu, base) as k:
                if fresh:
                    winreg.SetValueEx(k, "", 0, winreg.REG_SZ, "URL:%s Protocol" % proto)
                try:
                    winreg.QueryValueEx(k, "URL Protocol")
                except OSError:
                    winreg.SetValueEx(k, "URL Protocol", 0, winreg.REG_SZ, "")
            with winreg.CreateKey(hkcu, base + r"\shell\open\command") as k:
                winreg.SetValueEx(k, "", 0, winreg.REG_SZ, ours)
        return None
    except Exception as e:
        return str(e)


def disable_protocol():
    """Gives the links back to Roblox (puts the saved handlers back)."""
    try:
        import winreg
    except ImportError:
        return
    hkcu, saved = winreg.HKEY_CURRENT_USER, _load_handlers()
    for proto in PROTOCOLS:
        cur = _read_cmd(hkcu, proto)
        if cur is not None and not _is_ours(cur):
            continue  # something else (a Roblox update) already took it back - leave it
        info = saved.get(proto)
        base = _reg_path(hkcu, proto)
        try:
            if info is None:  # no backup (data lost): use the Roblox launcher we can find, else just remove ours
                exe = find_roblox_launcher()
                if exe:
                    with winreg.CreateKey(hkcu, base + r"\shell\open\command") as k:
                        winreg.SetValueEx(k, "", 0, winreg.REG_SZ, '"%s" %%1' % exe)
                else:
                    _del_tree(hkcu, base)
            elif info.get("hkcu"):  # Roblox had a per-user handler: put it back
                with winreg.CreateKey(hkcu, base + r"\shell\open\command") as k:
                    winreg.SetValueEx(k, "", 0, winreg.REG_SZ, info["hkcu"])
            elif info.get("existed"):
                _del_tree(hkcu, base + r"\shell")
            else:
                _del_tree(hkcu, base)
        except OSError:
            pass
    try:
        os.remove(HANDLER_FILE)
    except OSError:
        pass


def refresh_protocol():
    """Called at startup when the option is on: re-apply if a Roblox update replaced ours or Glint was moved."""
    try:
        import winreg
        if any(_read_cmd(winreg.HKEY_CURRENT_USER, p) != _our_command() for p in PROTOCOLS):
            return enable_protocol()
    except Exception as e:
        return str(e)
    return None


def chain_to_roblox(uri, proto="roblox-player"):
    """Hands a link to Roblox's own handler (the one Glint replaced). Never runs Glint again, so no loop."""
    if not LINK_OK.match(uri):
        raise ValueError("link looks unsafe, not opened")
    if OWN_CLIENT:
        own_launch(uri)  # Glint's own Roblox
        return
    tmpl = (_load_handlers().get(proto) or {}).get("orig")
    if not tmpl or _is_ours(tmpl):
        exe = find_roblox_launcher()
        if not exe:
            raise RuntimeError("Roblox does not seem to be installed")
        tmpl = '"%s" %%1' % exe
    q = '"%s"' % uri
    if "%1" in tmpl:
        cmd = re.sub(r'"?%1"?', lambda m: q, tmpl)  # one pass: the link itself is never re-scanned
    else:
        cmd = tmpl + " " + q
    subprocess.Popen(cmd, close_fds=True)


def launch_uri(uri):
    """Starts Roblox from a roblox-player: link."""
    if OWN_CLIENT:
        own_launch(uri)
        return
    try:
        import winreg
        mine = _is_ours(_read_cmd(winreg.HKEY_CURRENT_USER, "roblox-player"))
    except Exception:
        mine = False
    if mine:
        chain_to_roblox(uri)  # Glint owns the links: go straight to Roblox, not back to ourselves
    else:
        os.startfile(uri)


def target_from_protocol(uri):
    """Turns a roblox-player: / roblox: link into a Glint target, or None if it is something else
    (for example join-a-friend) - those are handed to Roblox untouched."""
    if uri.lower().startswith("roblox-player:"):
        mode = re.search(r"launchmode:(\w+)", uri, re.I)
        if mode and mode.group(1).lower() != "play":
            return None
        m = re.search(r"placelauncherurl:([^+]+)", uri, re.I)
        if not m:
            return None
        pl = urllib.parse.unquote(m.group(1))
        req, place = re.search(r"request=(\w+)", pl, re.I), re.search(r"placeId=(\d+)", pl, re.I)
        if not (req and place):
            return None
        req, pid = req.group(1), int(place.group(1))
        if req == "RequestGame":
            return {"kind": "place", "place": pid}
        if req == "RequestGameJob":
            j = re.search(r"gameId=([0-9a-fA-F-]{36})", pl)
            return {"kind": "job", "place": pid, "job": j.group(1)} if j else None
        if req == "RequestPrivateGame":
            l = re.search(r"linkCode=([\w-]+)", pl)
            return {"kind": "private", "place": pid, "link": l.group(1)} if l else None
        return None
    u = urllib.parse.unquote(uri)  # roblox://...
    place = re.search(r"placeId=(\d+)", u, re.I)
    link = re.search(r"(?:privateServerLinkCode|linkCode)=([\w-]+)", u, re.I)
    if place and link:
        return {"kind": "private", "place": int(place.group(1)), "link": link.group(1)}
    return parse_target(u)


_gui_mutex = None


def gui_running():
    try:
        k = ctypes.windll.kernel32
        k.OpenMutexW.restype = ctypes.c_void_p
        k.OpenMutexW.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_wchar_p]
        k.CloseHandle.argtypes = [ctypes.c_void_p]
        h = k.OpenMutexW(0x00100000, False, "Glint_GUI_Running")  # SYNCHRONIZE
        if h:
            k.CloseHandle(h)
            return True
    except Exception:
        pass
    return False


def claim_gui():
    global _gui_mutex
    try:
        k = ctypes.windll.kernel32
        k.CreateMutexW.restype = ctypes.c_void_p
        k.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
        _gui_mutex = k.CreateMutexW(None, False, "Glint_GUI_Running")
    except Exception:
        pass


def forward_link(uri):
    """Glint is already open: hand it the link (it checks this folder twice a second)."""
    os.makedirs(LINK_DIR, exist_ok=True)
    name = "%d_%d" % (int(time.time() * 1000), random.randint(1000, 9999))
    tmp = os.path.join(LINK_DIR, name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(uri)
    os.replace(tmp, os.path.join(LINK_DIR, name + ".link"))


# ----------------------------------------------------------------------------
# Log file: everything shown in the log box is also written to %APPDATA%\\DiamondLauncher\\glint.log.
# When it reaches 1 MB it is cleared and starts again, so it can never grow big.
# ----------------------------------------------------------------------------
LOG_FILE = os.path.join(APP_DIR, "glint.log")
LOG_MAX = 1024 * 1024  # 1 MB
_log_lock = threading.Lock()


def _log_header():
    try:
        import getpass
        user = os.environ.get("USERNAME") or getpass.getuser()
    except Exception:
        user = "unknown"
    return "=== Glint v%s | user: %s ===\n" % (APP_VERSION, user)


def write_log_file(line):
    try:
        with _log_lock:
            os.makedirs(APP_DIR, exist_ok=True)
            try:
                size = os.path.getsize(LOG_FILE)
            except OSError:
                size = 0  # no file yet
            cleared = size >= LOG_MAX
            if cleared:
                open(LOG_FILE, "w").close()  # clear it
                size = 0
            head = ""
            if size == 0:  # every new log starts with the version and username
                head = _log_header()
                if cleared:
                    head += time.strftime("[%Y-%m-%d %H:%M:%S] ") + "previous log reached 1 MB and was cleared\n"
            with open(LOG_FILE, "a", encoding="utf-8", errors="replace") as f:
                f.write(head + line + "\n")
    except Exception:
        pass  # logging must never crash the app


# ----------------------------------------------------------------------------
# Bug reporter: builds a copy-paste report for GitHub issues. Nothing is sent anywhere by the app.
# ----------------------------------------------------------------------------
def open_url(url):
    try:
        import webbrowser
        webbrowser.open(url)
    except Exception:
        try:
            os.startfile(url)
        except Exception:
            pass


def redact(text, names=()):
    """Removes anything private (login cookies, private-server codes, account and Windows user names)."""
    for i, n in enumerate(names, 1):
        text = re.sub(re.escape(n), "account#%d" % i, text, flags=re.I)
    text = re.sub(r"_\|WARNING[^\s\"']+", "<cookie removed>", text)
    text = re.sub(r"(?i)(ROBLOSECURITY=)[^\s;\"']+", r"\1<removed>", text)
    text = re.sub(r"(?i)((?:linkCode|accessCode|privateServerLinkCode|code)=)[^&\s\"']+", r"\1<removed>", text)
    text = re.sub(r"(?i)((?:auth)?ticket[=:]\s*)[^\s\"']+", r"\1<removed>", text)
    user = os.environ.get("USERNAME", "")
    if len(user) >= 3:
        text = re.sub(re.escape(user), "<user>", text, flags=re.I)
    return text


def build_bug_report(data, log_text="", detailed=False):
    """Default report has no personal/technical details at all - just the version. detailed=True adds them."""
    import platform
    names = []
    for a in data.get("accounts", []):
        names += [str(a.get("name", "")), str(a.get("display", ""))]
    names = sorted({n for n in names if len(n) >= 3}, key=len, reverse=True)
    try:
        win = platform.platform()
    except Exception:
        win = "Windows"
    mode = "exe" if getattr(sys, "frozen", False) else ".bat"
    lines = [
        "## What went wrong", "(describe it here)", "",
        "## Steps to reproduce", "1. ", "2. ", "",
        "## Details", "- Glint: v%s (%s)" % (APP_VERSION, mode),
    ]
    if detailed:
        lines += [
            "- Windows: %s" % win,
            "- Python: %s" % platform.python_version(),
            "- Saved accounts: %d" % len(data.get("accounts", [])),
            "- Settings: multi=%s, fps_boost=%s, fps_unlock=%s, tracker=%s, gap=%ss, advance=%s, close_after=%s, skip_screen=%s"
            % (data.get("multi"), data.get("fps"), data.get("unlock"), data.get("tracker"), data.get("gap"),
               data.get("advance"), data.get("close_after"), data.get("auto")),
            "",
        ]
        tail = [l for l in log_text.splitlines() if l.strip()][-30:]
        if tail:
            lines += ["## Recent log", "```"] + tail + ["```", ""]
        try:
            with open(os.path.join(APP_DIR, "crash.log"), "r", errors="replace") as f:
                crash = f.read()[-2000:].strip()
            if crash:
                lines += ["## Last crash", "```", crash, "```", ""]
        except OSError:
            pass
    return redact("\n".join(lines), names)


# ----------------------------------------------------------------------------
# Auto-update (reads the latest GitHub Release of UPDATE_REPO; asks before installing anything)
# ----------------------------------------------------------------------------
def _ver(text):
    return tuple(int(x) for x in re.findall(r"\d+", str(text or ""))[:4]) or (0,)


def _github_host(url):
    u = urllib.parse.urlparse(url)
    host = (u.hostname or "").lower()
    return u.scheme == "https" and any(host == d or host.endswith("." + d)
                                       for d in ("github.com", "githubusercontent.com"))


def check_for_update():
    """Returns info about a newer release, or None (also None on any error - never bothers the user)."""
    if "/" not in UPDATE_REPO or "YOUR-" in UPDATE_REPO:
        return None
    try:
        st, _, body = http("GET", "https://api.github.com/repos/%s/releases/latest" % UPDATE_REPO,
                           {"User-Agent": "Glint-updater", "Accept": "application/vnd.github+json"})
        if st != 200:
            return None
        rel = json.loads(body.decode("utf-8"))
        tag = str(rel.get("tag_name", ""))
        if _ver(tag) <= _ver(APP_VERSION):
            return None
        want = ".exe" if getattr(sys, "frozen", False) else ".bat"
        assets = rel.get("assets") or []
        pick = next((a for a in assets if str(a.get("name", "")).lower().startswith("glint")
                     and str(a.get("name", "")).lower().endswith(want)), None)
        sha = None
        if pick:
            sha = next((a for a in assets if a.get("name") == pick["name"] + ".sha256"), None)
        return {"tag": tag, "notes": str(rel.get("body") or "").strip(), "page": rel.get("html_url", ""),
                "url": pick.get("browser_download_url") if pick else None,
                "sha_url": sha.get("browser_download_url") if sha else None}
    except Exception:
        return None


def _download(url, limit=80 * 1024 * 1024):
    if not _github_host(url):
        raise ValueError("download blocked: not a GitHub address")
    req = urllib.request.Request(url, headers={"User-Agent": "Glint-updater"})
    with urllib.request.urlopen(req, timeout=60) as r:
        if not _github_host(r.geturl()):
            raise ValueError("download blocked: redirected away from GitHub")
        blob = r.read(limit + 1)
    if len(blob) > limit:
        raise ValueError("download is too large")
    return blob


def _validate_update(blob, frozen):
    if frozen:
        if blob[:2] != b"MZ" or len(blob) < 1000000:
            raise ValueError("the downloaded file is not a valid Glint.exe")
    else:
        text = blob.decode("utf-8").replace("\r\n", "\n")
        m = re.search(r'\n"""\n(# =+\n)', text)
        if not m or "APP_VERSION" not in text:
            raise ValueError("the downloaded file is not a valid Glint.bat")
        compile(text[m.start(1):], "Glint.bat", "exec")  # refuse a file that would not even start


def install_update(info, log):
    """Downloads, checks and swaps in the new file. Returns the path to start again."""
    import hashlib
    frozen = bool(getattr(sys, "frozen", False))
    log("Downloading Glint %s ..." % info["tag"])
    blob = _download(info["url"])
    if info.get("sha_url"):
        want = _download(info["sha_url"], 4096).decode("utf-8", "ignore").split()[0].lower()
        if hashlib.sha256(blob).hexdigest() != want:
            raise ValueError("checksum does not match - update cancelled")
    _validate_update(blob, frozen)
    cur = sys.executable if frozen else os.path.abspath(__file__)
    tmp = cur + ".new"
    with open(tmp, "wb") as f:
        f.write(blob)
    if frozen:  # a running exe can be renamed but not overwritten
        old = cur + ".old"
        try:
            os.remove(old)
        except OSError:
            pass
        os.replace(cur, old)
        try:
            os.replace(tmp, cur)
        except Exception:
            os.replace(old, cur)
            raise
    else:
        os.replace(tmp, cur)
    return cur


def cleanup_old_update():
    if getattr(sys, "frozen", False):
        try:
            os.remove(sys.executable + ".old")
        except OSError:
            pass


def relaunch(path):
    if getattr(sys, "frozen", False):
        env = {k: v for k, v in os.environ.items() if not k.startswith("_PYI") and k != "_MEIPASS2"}
        subprocess.Popen([path], env=env, cwd=os.path.dirname(path), close_fds=True,
                         creationflags=0x00000008 | 0x00000200)
    else:
        os.startfile(path)


def run_gui(pending_link=None):
    import tkinter as tk
    from tkinter import ttk, messagebox, simpledialog

    try:  # own taskbar identity, so the taskbar shows the diamond (not the Python icon)
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Diamond.Glint")
    except Exception:
        pass
    claim_gui()  # tells later Roblox links that a Glint window is already open
    data = load_data()
    data.setdefault("accounts", [])
    data.setdefault("multi", False)  # multi-instance is opt-in

    root = tk.Tk()
    root.title("Glint - Settings")
    root.geometry("880x640")
    root.minsize(800, 560)
    root.configure(bg=BG)
    logo = tk.PhotoImage(data=icon_png())  # 256px
    logo64, logo128 = logo.subsample(4, 4), logo.subsample(2, 2)  # keep references or Tk drops them
    root.iconphoto(True, logo64, logo128)
    try:
        ico_path = ensure_ico()
    except Exception:
        ico_path = None
    root.withdraw()  # the launch screen shows first; Configure reveals this window

    # ---- every setting lives in one variable, shared by both screens ----
    target_var = tk.StringVar(value=data.get("last_target", ""))
    multi_var = tk.BooleanVar(value=bool(data.get("multi", False)))
    advance_var = tk.BooleanVar(value=data.get("advance", True))
    close_var = tk.BooleanVar(value=data.get("close_after", False))
    skip_var = tk.BooleanVar(value=data.get("auto", False))
    gap_var = tk.StringVar(value=str(data.get("gap", DEFAULT_GAP)))
    fps_var = tk.BooleanVar(value=data.get("fps", False))
    unlock_var = tk.BooleanVar(value=data.get("unlock", False))
    cap_var = tk.StringVar(value=str(data.get("cap", "9999")))
    tracker_var = tk.BooleanVar(value=data.get("tracker", False))
    update_var = tk.BooleanVar(value=data.get("update_check", True))
    takeover_var = tk.BooleanVar(value=data.get("takeover", False))  # Roblox links open with Glint
    linkask_var = tk.BooleanVar(value=data.get("link_ask", True))
    own_var = tk.BooleanVar(value=data.get("own_client", False))  # launch from Glint's own Roblox copy
    set_own_client(own_var.get())

    # ---- theme ----
    st = ttk.Style(root)
    try:
        st.theme_use("clam")
    except tk.TclError:
        pass
    st.configure(".", background=BG, foreground=FG, font=(UI, 10), bordercolor=LINE,
                 lightcolor=LINE, darkcolor=LINE, troughcolor=PANEL, focuscolor=BG)
    for nm, bgc in (("D", BG), ("C", CARD)):
        st.configure(nm + ".TCheckbutton", background=bgc, foreground=FG, font=(UI, 10),
                     indicatorbackground=PANEL, indicatorforeground=INK, focuscolor=bgc, padding=(2, 3))
        st.map(nm + ".TCheckbutton", background=[("active", bgc)], foreground=[("active", "#ffffff")],
               indicatorbackground=[("selected", CYAN), ("active", CARD_HOVER)],
               indicatorforeground=[("selected", INK)])
    st.configure("TEntry", fieldbackground=PANEL, foreground=FG, insertcolor=FG, padding=6,
                 bordercolor=LINE, lightcolor=PANEL, darkcolor=PANEL)
    st.map("TEntry", bordercolor=[("focus", CYAN)], lightcolor=[("focus", CYAN)], darkcolor=[("focus", CYAN)])
    st.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=FG, borderwidth=0,
                 rowheight=30, font=(UI, 10))
    st.map("Treeview", background=[("selected", SEL)], foreground=[("selected", FG)])
    st.configure("Treeview.Heading", background=CARD, foreground=MUTED, relief="flat", borderwidth=0,
                 font=(UIB, 9), padding=(8, 6))
    st.map("Treeview.Heading", background=[("active", CARD_HOVER)])
    st.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])
    st.configure("Pick.Treeview", rowheight=38, font=(UI, 12))
    st.configure("Vertical.TScrollbar", background=CARD_HOVER, troughcolor=PANEL, bordercolor=PANEL,
                 arrowcolor=MUTED, lightcolor=CARD_HOVER, darkcolor=CARD_HOVER, gripcount=0)
    st.map("Vertical.TScrollbar", background=[("active", LINE)])

    def button(parent, text, command, kind="secondary", font=None, padx=14, pady=7):
        """Flat button (a Label) with a hover colour. kind: primary / secondary / danger."""
        bgc, hover, fgc = {"primary": (CYAN, "#86e6ff", INK),
                           "secondary": (CARD, CARD_HOVER, FG),
                           "danger": (CARD, "#3a1f33", RED)}[kind]
        b = tk.Label(parent, text=text, bg=bgc, fg=fgc, font=font or (UIB, 10), padx=padx, pady=pady,
                     cursor="hand2")
        b.bind("<Enter>", lambda e: b.configure(bg=hover))
        b.bind("<Leave>", lambda e: b.configure(bg=bgc))
        b.bind("<Button-1>", lambda e: command())
        return b

    def heading(parent, text, bgc=BG):
        return tk.Label(parent, text=text.upper(), font=(UIB, 8), fg=CYAN, bg=bgc, anchor="w")

    def link(parent, text, url, bgc=BG, size=9):
        """Clickable text that opens a web page."""
        l = tk.Label(parent, text=text, font=(UI, size, "underline"), fg=CYAN, bg=bgc, cursor="hand2")
        l.bind("<Enter>", lambda e: l.configure(fg="#86e6ff"))
        l.bind("<Leave>", lambda e: l.configure(fg=CYAN))
        l.bind("<Button-1>", lambda e: open_url(url))
        return l

    def ui(fn, *args):
        """Run fn on the Tk thread (safe to call from worker threads)."""
        try:
            root.after(0, fn, *args)
        except Exception:
            pass

    # ---- settings <-> saved data ----
    def sync():
        data["last_target"] = target_var.get().strip()
        data["multi"] = multi_var.get()
        data["advance"] = advance_var.get()
        data["close_after"] = close_var.get()
        data["auto"] = skip_var.get()
        data["gap"] = gap_var.get()
        data["fps"] = fps_var.get()
        data["unlock"] = unlock_var.get()
        data["cap"] = cap_var.get()
        data["tracker"] = tracker_var.get()
        data["update_check"] = update_var.get()
        data["takeover"] = takeover_var.get()
        data["link_ask"] = linkask_var.get()
        data["own_client"] = own_var.get()

    def persist():
        sync()
        save_data(data)

    def gap_seconds():
        try:
            return max(0, min(60, int(float(data.get("gap", DEFAULT_GAP)))))
        except (TypeError, ValueError):
            return DEFAULT_GAP

    def cap_value(raw):
        try:
            return max(30, min(99999, int(raw)))
        except (TypeError, ValueError):
            return 9999

    # =========================================================================
    # SETTINGS WINDOW
    # =========================================================================
    box = None  # the log box (created below, used by log())

    def log(msg):
        write_log_file(time.strftime("[%Y-%m-%d %H:%M:%S] ") + str(msg))

        def _w():
            box.configure(state="normal")
            box.insert("end", time.strftime("[%H:%M:%S] ") + msg + "\n")
            box.see("end")
            box.configure(state="disabled")
        ui(_w)

    tracker = FpsTracker(root, log)

    hdr = tk.Frame(root, bg=BG)
    hdr.pack(fill="x", padx=20, pady=(16, 8))
    tk.Label(hdr, text="Settings", font=(UIB, 18), fg=FG, bg=BG).pack(side="left")
    button(hdr, "\u2190  Back to launcher", lambda: back_to_launcher(), pady=6).pack(side="right")
    tk.Label(hdr, text="Esc also goes back", font=(UI, 8), fg=MUTED, bg=BG).pack(side="right", padx=12)

    tk.Label(root, text="Accounts are stored encrypted on this PC only. Nothing is sent anywhere except Roblox.",
             font=(UI, 8), fg=MUTED, bg=BG).pack(side="bottom", anchor="w", padx=20, pady=(0, 10))
    logwrap = tk.Frame(root, bg=BG)
    logwrap.pack(side="bottom", fill="x", padx=20, pady=(6, 6))
    box = tk.Text(logwrap, height=6, state="disabled", bg=PANEL, fg="#c9d0f5", relief="flat",
                  font=("Consolas", 9), padx=10, pady=8, wrap="word", highlightthickness=1,
                  highlightbackground=LINE, highlightcolor=LINE)
    box.pack(fill="x")

    body = tk.Frame(root, bg=BG)
    body.pack(fill="both", expand=True, padx=20)
    body.columnconfigure(0, weight=3)
    body.columnconfigure(1, weight=2, minsize=310)
    body.rowconfigure(0, weight=1)
    left = tk.Frame(body, bg=BG)
    left.grid(row=0, column=0, sticky="nsew", padx=(0, 16))
    rwrap = tk.Frame(body, bg=BG)  # the option cards can be taller than the window, so this side scrolls
    rwrap.grid(row=0, column=1, sticky="nsew")
    rcan = tk.Canvas(rwrap, bg=BG, highlightthickness=0, bd=0)
    rsb = ttk.Scrollbar(rwrap, orient="vertical", command=rcan.yview)
    rcan.configure(yscrollcommand=rsb.set)
    rsb.pack(side="right", fill="y")
    rcan.pack(side="left", fill="both", expand=True)
    right = tk.Frame(rcan, bg=BG)
    rwin = rcan.create_window((0, 0), window=right, anchor="nw")
    right.bind("<Configure>", lambda e: rcan.configure(scrollregion=rcan.bbox("all")))
    rcan.bind("<Configure>", lambda e: rcan.itemconfigure(rwin, width=e.width))

    def right_wheel(e):
        try:
            w = root.winfo_containing(*root.winfo_pointerxy())
            while w is not None and w is not rwrap:
                w = w.master
            if w is rwrap and right.winfo_reqheight() > rcan.winfo_height():
                rcan.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1), "units")
        except Exception:
            pass
    root.bind_all("<MouseWheel>", right_wheel, add="+")

    # ---- left: accounts ----
    heading(left, "Accounts").pack(fill="x", pady=(0, 6))
    twrap = tk.Frame(left, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
    twrap.pack(fill="both", expand=True)
    ctree = ttk.Treeview(twrap, columns=("user", "display", "status"), show="headings", selectmode="extended")
    for c, w, t in (("user", 150, "Username"), ("display", 150, "Display name"), ("status", 80, "Status")):
        ctree.heading(c, text=t)
        ctree.column(c, width=w, anchor="w")
    csb = ttk.Scrollbar(twrap, command=ctree.yview)
    ctree.configure(yscrollcommand=csb.set)
    csb.pack(side="right", fill="y")
    ctree.pack(side="left", fill="both", expand=True)
    ctree.tag_configure("bad", foreground=RED)
    ctree.tag_configure("good", foreground=GREEN)

    def refresh_ctree():
        ctree.delete(*ctree.get_children())
        for i, a in enumerate(data["accounts"]):
            s = a.get("status", "saved")
            ctree.insert("", "end", iid=str(i), values=(a["name"], a["display"], s),
                         tags=("good",) if s == "OK" else (("bad",) if s in ("Expired", "Error") else ()))

    def add_cookie(cookie):
        def work():
            info = whoami(cookie)
            if not info:
                log("Sign-in failed or cookie invalid.")
                return
            acc = {"name": info["name"], "display": info["display"], "id": info["id"],
                   "cookie": cookie, "status": "OK"}
            for i, a in enumerate(data["accounts"]):
                if a["id"] == acc["id"]:
                    data["accounts"][i] = acc
                    break
            else:
                data["accounts"].append(acc)
            save_data(data)
            ui(refresh_all)
            log("Saved account: %s" % acc["name"])
        threading.Thread(target=work, daemon=True).start()

    def add_account():
        def work():
            log("Opening Roblox sign-in window...")
            os.makedirs(APP_DIR, exist_ok=True)
            out_path = os.path.join(APP_DIR, "login_%d.tmp" % random.randint(10**8, 10**9))
            cmd = [sys.executable] + ([] if getattr(sys, "frozen", False) else ["-x", os.path.abspath(__file__)]) \
                + ["--login", out_path]
            try:
                subprocess.run(cmd, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                with open(out_path, "r") as f:
                    cookie = f.read().strip()
            except Exception:
                cookie = ""
            finally:
                try:
                    os.remove(out_path)
                except OSError:
                    pass
            if cookie:
                add_cookie(cookie)
            else:
                log("No sign-in captured (window closed, or pywebview/WebView2 missing). "
                    "You can use 'Add by cookie' instead.")
        threading.Thread(target=work, daemon=True).start()

    def add_by_cookie():
        c = simpledialog.askstring("Add by cookie", "Paste the .ROBLOSECURITY value:", show="*", parent=root)
        if c:
            add_cookie(c.strip().strip('"'))

    def remove():
        sel = ctree.selection()
        if sel and messagebox.askyesno("Remove", "Remove %d account(s) from this PC?" % len(sel), parent=root):
            for i in sorted((int(s) for s in sel), reverse=True):
                del data["accounts"][i]
            persist()
            refresh_all()

    def check_all():
        def work():
            for a in data["accounts"]:
                a["status"] = "OK" if whoami(a["cookie"]) else "Expired"
            save_data(data)
            ui(refresh_all)
            log("Checked all accounts.")
        threading.Thread(target=work, daemon=True).start()

    def wipe():
        if messagebox.askyesno("Wipe everything", "Delete ALL saved accounts and data from this PC?", parent=root):
            if takeover_var.get():
                disable_protocol()  # give Roblox its links back first
                takeover_var.set(False)
            data["accounts"].clear()
            try:
                os.remove(DATA_FILE)
            except OSError:
                pass
            refresh_all()
            log("All data wiped.")

    abar = tk.Frame(left, bg=BG)
    abar.pack(fill="x", pady=(8, 0))
    abar.columnconfigure((0, 1), weight=1, uniform="ab")
    button(abar, "Add account (sign in)", add_account, pady=6).grid(row=0, column=0, sticky="ew", padx=(0, 4))
    button(abar, "Add by cookie", add_by_cookie, pady=6).grid(row=0, column=1, sticky="ew", padx=(4, 0))
    button(abar, "Remove selected", remove, "danger", pady=6).grid(row=1, column=0, sticky="ew", padx=(0, 4), pady=(8, 0))
    button(abar, "Check all", check_all, pady=6).grid(row=1, column=1, sticky="ew", padx=(4, 0), pady=(8, 0))

    # ---- right: option cards ----
    def card(title):
        wrap = tk.Frame(right, bg=CARD)
        wrap.pack(fill="x", pady=(0, 12))
        heading(wrap, title, CARD).pack(fill="x", padx=14, pady=(10, 4))
        inner = tk.Frame(wrap, bg=CARD)
        inner.pack(fill="x", padx=14, pady=(0, 12))
        return inner

    def hint(parent, text):
        tk.Label(parent, text=text, font=(UI, 8), fg=MUTED, bg=CARD, justify="left", anchor="w",
                 wraplength=270).pack(fill="x", padx=(24, 0), pady=(0, 4))

    def check(parent, text, var, cmd=None):
        c = ttk.Checkbutton(parent, text=text, variable=var, command=cmd, style="C.TCheckbutton")
        c.pack(anchor="w")
        return c

    # --- multi-instance plumbing (handle64.exe closes Roblox's "already running" lock) ---
    def ensure_handle():
        if not multi_var.get() or os.path.exists(HANDLE_EXE):
            return
        if not messagebox.askyesno(
                "One-time download",
                "Multiple instances needs Microsoft's Sysinternals 'handle64.exe'.\n\n"
                "Download it once from live.sysinternals.com?\n(Only used to close Roblox's singleton lock.)"):
            multi_var.set(False)
            persist()
            return

        def dl():
            try:
                os.makedirs(APP_DIR, exist_ok=True)
                req = urllib.request.Request(HANDLE_URL, headers={"User-Agent": UA})
                with urllib.request.urlopen(req, timeout=60) as r, open(HANDLE_EXE, "wb") as f:
                    f.write(r.read())
                log("Downloaded handle64.exe")
            except Exception as e:
                log("Download failed: %s" % e)
        threading.Thread(target=dl, daemon=True).start()

    def on_multi_toggle():
        """The 'Allow multiple Roblox instances' choice (same switch on both screens)."""
        persist()
        if multi_var.get():
            ensure_handle()  # may switch the choice back off if the download is declined
        set_singleton_mutex(multi_var.get())
        log("Multiple Roblox instances: %s." % ("ON" if multi_var.get() else "OFF"))

    def multi_loop():
        while True:
            time.sleep(2)
            try:
                if data.get("multi"):
                    n = close_singleton_events()
                    if n:
                        log("Cleared Roblox singleton lock (%d)" % n)
            except Exception:
                pass

    def on_takeover_toggle():
        if takeover_var.get():
            if not messagebox.askyesno(
                    "Open Roblox links with Glint",
                    "Glint will become the program that opens Roblox links.\n\n"
                    "When you press Play on roblox.com, Glint asks which of your accounts to use and starts "
                    "Roblox with it.\n\n"
                    "Glint must stay where it is now - if you move or delete it, untick this first. "
                    "You can undo it any time here (or run Glint.bat --restore-links).\n\nTurn it on?", parent=root):
                takeover_var.set(False)
                return
            err = enable_protocol()
            if err:
                takeover_var.set(False)
                log("Could not take over Roblox links: %s" % err)
                messagebox.showerror("Glint", "Could not set this up:\n%s" % err, parent=root)
            else:
                log("Roblox links now open with Glint.")
        else:
            disable_protocol()
            log("Roblox links handed back to Roblox.")
        persist()

    def own_background_install():
        try:
            own_ensure(log)
            log("Glint's own Roblox is ready.")
        except Exception as e:
            log("Could not set up Glint's own Roblox: %s" % e)

    def on_own_toggle():
        if own_var.get():
            if not messagebox.askyesno(
                    "Glint's own Roblox",
                    "Glint will download its own copy of Roblox (a few hundred MB, one time) into "
                    "%LOCALAPPDATA%\\Glint and start games from that copy, the way Bloxstrap does.\n\n"
                    "Your normal Roblox install is not touched. Glint keeps its copy up to date.\n\nTurn it on?",
                    parent=root):
                own_var.set(False)
                return
            set_own_client(True)
            persist()
            log("Getting Glint's own Roblox ...")
            threading.Thread(target=own_background_install, daemon=True).start()
        else:
            set_own_client(False)
            persist()
            log("Glint now uses the normal Roblox install again.")

    c1 = card("Launching")
    check(c1, "Allow multiple Roblox instances", multi_var, on_multi_toggle)
    hint(c1, "Needed to run several accounts at once. Off = Roblox opens one window at a time.")
    check(c1, "Auto-select the next account after Launch", advance_var, persist)
    check(c1, "Close this app after launching", close_var, persist)
    check(c1, "Skip the launch screen next time", skip_var, persist)
    hint(c1, "Hold Shift while opening to bring the launch screen back.")
    check(c1, "Use Glint's own Roblox (like Bloxstrap)", own_var, on_own_toggle)
    hint(c1, "Glint downloads and updates its own copy of Roblox and starts games from it. Your normal Roblox install is left alone.")
    check(c1, "Open Roblox links with Glint (Play button)", takeover_var, on_takeover_toggle)
    hint(c1, "Pressing Play on roblox.com opens Glint's account picker. Untick to give links back to Roblox.")
    check(c1, "Ask which account when a link is opened", linkask_var, persist)
    check(c1, "Check for updates on launch", update_var, persist)
    hint(c1, "Asks GitHub once per launch if a newer Glint exists. It always asks before installing.")
    grow = tk.Frame(c1, bg=CARD)
    grow.pack(fill="x", pady=(2, 0))
    tk.Label(grow, text="Seconds between launches", font=(UI, 10), fg=FG, bg=CARD).pack(side="left", padx=(2, 8))
    gap_entry = ttk.Entry(grow, textvariable=gap_var, width=4)
    gap_entry.pack(side="left")
    for ev in ("<Return>", "<FocusOut>"):
        gap_entry.bind(ev, lambda e: persist())

    # --- FPS boost / unlocker / tracker ---
    def toggle_fps():
        n = apply_fps(fps_var.get(), data)
        persist()
        apply_unlock(True)  # FramerateCap 1000 on / restore on off (only while Roblox is closed)
        if n:
            log("FPS boost %s for %d Roblox install(s) (flags + IxpSettings.json). Restart any open Roblox windows." %
                ("ENABLED" if fps_var.get() else "disabled", n))
        else:
            log("Roblox install not found in %LOCALAPPDATA%\\Roblox\\Versions (Microsoft Store/other installs are not supported).")

    def apply_unlock(notify=False):
        if data.get("unlock"):
            want = cap_value(data.get("cap"))
        elif data.get("fps"):
            want = FPS_BOOST_CAP  # FPS optimization = YES -> FramerateCap 1000
        else:
            want = None
        if want is None and data.get("cap_backup") is None:
            return
        if roblox_running():
            if notify:
                log("FPS unlocker: close ALL Roblox windows first - it is applied the next time you launch from here.")
            return
        r = set_framerate_cap(want, data)
        if r == "same":
            return
        save_data(data)
        if r == "missing":
            log("FPS unlocker: open Roblox once first (its settings file does not exist yet).")
        elif r == "error":
            log("FPS unlocker: could not edit Roblox's settings file.")
        elif r == "ok":
            log("Max FPS %s." % ("set to %d" % want if want else "restored to your old setting"))

    def fps_watcher():
        """Every few seconds: if FPS optimization (or the unlocker) is ON, check Roblox's files and
        put our settings back if Roblox/an update changed them. If it is OFF, touch nothing."""
        last_msg = 0.0
        while True:
            time.sleep(5)
            try:
                if not (data.get("fps") or data.get("unlock")):
                    continue
                with FPS_LOCK:
                    w0 = FPS_STATE["writes"]
                    if data.get("fps"):
                        apply_fps(True, data)  # flags + IxpSettings.json, only rewrites what changed
                    if data.get("fps") or data.get("unlock"):
                        apply_unlock(False)  # FramerateCap, only while no Roblox window is open
                    fixed = FPS_STATE["writes"] - w0
                if fixed:
                    save_data(data)
                    if time.time() - last_msg > 60:  # don't spam the log
                        last_msg = time.time()
                        log("FPS watcher: Roblox changed some settings back - re-applied them.")
            except Exception:
                pass

    def pm_ok():
        try:
            if os.path.getsize(PM_EXE) < 100000:
                return False
            with open(PM_EXE, "rb") as f:
                return f.read(2) == b"MZ"
        except OSError:
            return False

    def ensure_pm(then):
        if pm_ok():
            then()
            return
        if not messagebox.askyesno(
                "One-time download",
                "The FPS tracker needs Intel's free 'PresentMon' (about 10 MB).\n\n"
                "Download it once from github.com/GameTechDev/PresentMon?\n"
                "It will ask for administrator permission each time the tracker starts."):
            tracker_var.set(False)
            persist()
            return

        def dl():
            try:
                os.makedirs(APP_DIR, exist_ok=True)
                req = urllib.request.Request(PM_URL, headers={"User-Agent": UA})
                with urllib.request.urlopen(req, timeout=120) as r:
                    blob = r.read()
                if len(blob) < 100000 or blob[:2] != b"MZ":
                    raise RuntimeError("download looked wrong (not an exe)")
                tmp_pm = PM_EXE + ".part"
                with open(tmp_pm, "wb") as f:
                    f.write(blob)
                os.replace(tmp_pm, PM_EXE)
                log("Downloaded PresentMon.")
                ui(then)
            except Exception as e:
                log("PresentMon download failed: %s" % e)
                ui(lambda: (tracker_var.set(False), persist()))
        threading.Thread(target=dl, daemon=True).start()

    def start_tracker():
        if not claim_tracker_slot():
            log("FPS tracker is already running in another Glint window.")
            tracker_var.set(False)
            return
        if tracker.start():
            log("FPS tracker ON - drag the overlay anywhere. (Needs borderless/windowed Roblox to be visible.)")
        else:
            tracker_var.set(False)
        persist()

    def toggle_tracker():
        if tracker_var.get():
            ensure_pm(start_tracker)
        else:
            tracker.stop()
            log("FPS tracker OFF.")
            persist()

    c2 = card("Performance")
    check(c2, "FPS boost (optimized graphics flags)", fps_var, toggle_fps)
    urow = tk.Frame(c2, bg=CARD)
    urow.pack(fill="x")
    check(urow, "FPS unlocker", unlock_var, lambda: (persist(), apply_unlock(True))).pack_configure(side="left")
    tk.Label(urow, text="max FPS", font=(UI, 9), fg=MUTED, bg=CARD).pack(side="left", padx=(10, 6))
    cap_entry = ttk.Entry(urow, textvariable=cap_var, width=7)
    cap_entry.pack(side="left")
    for ev in ("<Return>", "<FocusOut>"):
        cap_entry.bind(ev, lambda e: (persist(), apply_unlock(True)) if unlock_var.get() else None)
    check(c2, "FPS tracker overlay", tracker_var, toggle_tracker)

    c3 = card("Data")
    c3.columnconfigure((0, 1), weight=1, uniform="dt")
    button(c3, "Desktop shortcut", lambda: (create_desktop_shortcut(), log("Desktop shortcut created.")),
           pady=6).grid(row=0, column=0, sticky="ew", padx=(0, 4))
    button(c3, "Wipe all data", wipe, "danger", pady=6).grid(row=0, column=1, sticky="ew", padx=(4, 0))
    button(c3, "Report a bug  /  GitHub", lambda: open_bug_report(), pady=6).grid(
        row=1, column=0, columnspan=2, sticky="ew", pady=(8, 0))

    # =========================================================================
    # LAUNCH SCREEN
    # =========================================================================
    state = {"auto_run": False, "quit_when_done": False, "last_seen": None}
    launch_q = queue.Queue()  # (account, target) waiting to be launched, in order
    qs = {"pending": 0, "last": 0.0, "burst": False}
    qlock = threading.Lock()
    launched = set()  # account ids launched during this session (shown with a tick)

    lw = tk.Toplevel(root)
    lw.title("Glint")
    lw.configure(bg=BG)
    lw.iconphoto(True, logo64, logo128)
    if ico_path:  # the real .ico is what Windows draws in the title bar and taskbar
        for w in (root, lw):
            try:
                w.iconbitmap(ico_path)
            except Exception:
                pass
    lw.minsize(500, 580)
    lw.update_idletasks()
    W, H = 520, 620
    lw.geometry("%dx%d+%d+%d" % (W, H, (lw.winfo_screenwidth() - W) // 2,
                                 max(0, (lw.winfo_screenheight() - H) // 3)))

    outer = tk.Frame(lw, bg=BG)
    outer.pack(fill="both", expand=True, padx=24, pady=20)

    head = tk.Frame(outer, bg=BG)
    head.pack(fill="x")
    tk.Label(head, image=logo64, bg=BG).pack(side="left")
    hb = tk.Frame(head, bg=BG)
    hb.pack(side="left", padx=14)
    tk.Label(hb, text="Glint", font=(UIB, 20), fg=FG, bg=BG).pack(anchor="w")
    tk.Label(hb, text="MULTI-ACCOUNT  \u2022  LOCAL-ONLY  \u2022  v" + APP_VERSION,
             font=(UI, 8), fg=CYAN, bg=BG).pack(anchor="w")

    foot = tk.Frame(outer, bg=BG)
    foot.pack(side="bottom", fill="x", pady=(8, 0))
    tk.Label(foot, text="Found a problem?", font=(UI, 9), fg=MUTED, bg=BG).pack(side="left")
    rb = link(foot, "Report a bug", GITHUB_NEW_ISSUE)
    rb.bind("<Button-1>", lambda e: open_bug_report())
    rb.pack(side="left", padx=(5, 0))
    link(foot, "GitHub page", GITHUB_PAGE).pack(side="right")

    ah = tk.Frame(outer, bg=BG)
    ah.pack(fill="x", pady=(20, 6))
    heading(ah, "Accounts").pack(side="left")
    tk.Label(ah, text="click to pick  \u2022  double-click to launch", font=(UI, 8), fg=MUTED, bg=BG).pack(side="right")

    awrap = tk.Frame(outer, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
    awrap.pack(fill="both", expand=True)
    atree = ttk.Treeview(awrap, columns=("name", "state"), show="", selectmode="extended",
                         style="Pick.Treeview", height=5)
    atree.column("name", anchor="w", stretch=True)
    atree.column("state", anchor="e", width=150, stretch=False)
    asb = ttk.Scrollbar(awrap, command=atree.yview)
    atree.configure(yscrollcommand=asb.set)
    asb.pack(side="right", fill="y")
    atree.pack(side="left", fill="both", expand=True, padx=(4, 0), pady=3)
    atree.tag_configure("done", foreground="#8ef0b0")
    atree.tag_configure("bad", foreground=RED)
    empty_lbl = tk.Label(awrap, text="No accounts yet.\nClick Configure, then Add account.",
                         font=(UI, 10), fg=MUTED, bg=PANEL, justify="center")

    heading(outer, "Game  -  search by name, or paste a link").pack(fill="x", pady=(16, 6))
    lrow = tk.Frame(outer, bg=BG)
    lrow.pack(fill="x")
    entry = ttk.Entry(lrow, textvariable=target_var, font=(UI, 10))
    entry.pack(side="left", fill="x", expand=True)

    def paste():
        try:
            target_var.set(root.clipboard_get().strip())
            persist()
        except tk.TclError:
            log("Clipboard is empty.")
    button(lrow, "Paste", paste, pady=5, padx=14).pack(side="left", padx=(8, 0))
    button(lrow, "Find game", lambda: open_finder(), "primary", pady=5, padx=14).pack(side="left", padx=(8, 0))
    link_info = tk.Label(outer, text="", font=(UI, 8), fg=MUTED, bg=BG, anchor="w")
    link_info.pack(fill="x", pady=(4, 0))
    entry.bind("<FocusOut>", lambda e: persist())

    ttk.Checkbutton(outer, text="Allow multiple Roblox instances", variable=multi_var,
                    command=on_multi_toggle, style="D.TCheckbutton").pack(anchor="w", pady=(12, 0))

    bt = tk.Frame(outer, bg=BG)
    bt.pack(fill="x", pady=(14, 0))
    launch_btn = button(bt, "Launch", lambda: start_launch(selected_accounts(), advance=True), "primary",
                        font=(UIB, 13), pady=11)
    launch_btn.pack(side="left", fill="x", expand=True)
    button(bt, "Launch all", lambda: start_launch(list(data["accounts"])), font=(UIB, 11),
           pady=11, padx=16).pack(side="left", padx=(8, 0))
    button(bt, "Configure", lambda: open_configure(), font=(UIB, 11), pady=11, padx=16).pack(side="left", padx=(8, 0))

    status_lbl = tk.Label(outer, text="", font=(UI, 9), fg=MUTED, bg=BG, anchor="w")
    status_lbl.pack(fill="x", pady=(10, 0))

    def set_status(text, color=MUTED):
        status_lbl.configure(text=text, fg=color)

    # ---- lists / labels ----
    def selected_accounts():
        return [data["accounts"][int(i)] for i in atree.selection()]

    def refresh_alist():
        keep = {a["name"] for a in selected_accounts()}
        atree.delete(*atree.get_children())
        for i, a in enumerate(data["accounts"]):
            s = a.get("status", "saved")
            if s in ("Expired", "Error"):
                tag, note = "bad", "sign in again" if s == "Expired" else "last launch failed"
            elif a.get("id") in launched:
                tag, note = "done", "\u2713 launched"
            else:
                tag, note = "", ""
            nm = a["name"] if a.get("display") in (None, "", a["name"]) else "%s  (%s)" % (a["name"], a["display"])
            atree.insert("", "end", iid=str(i), values=("  " + nm, note), tags=(tag,) if tag else ())
            if a["name"] in keep:
                atree.selection_add(str(i))
        if data["accounts"]:
            empty_lbl.place_forget()
        else:
            empty_lbl.place(relx=0.5, rely=0.5, anchor="center")

    def update_launch_btn():
        sel = selected_accounts()
        if len(sel) == 1:
            nm = sel[0]["name"]
            launch_btn.configure(text="Launch  " + (nm if len(nm) <= 18 else nm[:17] + "\u2026"))
        elif len(sel) > 1:
            launch_btn.configure(text="Launch %d accounts" % len(sel))
        else:
            launch_btn.configure(text="Launch")

    def refresh_all():
        refresh_ctree()
        refresh_alist()
        update_launch_btn()

    def restore_selection():
        last = data.get("last_accounts")
        if last is None and data.get("last_account"):
            last = [a["name"] for a in data["accounts"]] if data["last_account"] == "All accounts" \
                else [data["last_account"]]
        rows = [str(i) for i, a in enumerate(data["accounts"]) if a["name"] in (last or [])]
        if not rows and data["accounts"]:
            rows = ["0"]
        if rows:
            atree.selection_set(rows)
            atree.see(rows[0])
        update_launch_btn()

    def advance_selection(just):
        """After launching one account, pick the next one so Launch -> Launch -> Launch just works."""
        n = len(data["accounts"])
        if n < 2 or len(just) != 1:
            return
        idx = next((i for i, a in enumerate(data["accounts"]) if a is just[0]), None)
        if idx is None:
            return
        nxt = str((idx + 1) % n)
        atree.selection_set(nxt)
        atree.see(nxt)

    def short_target():
        t = parse_target(target_var.get())
        if not t:
            return None
        nm = known_game_name(data, t.get("place")) if t["kind"] == "place" else None
        if nm:
            return nm
        return {"place": "game %s" % t.get("place"), "private": "private server (game %s)" % t.get("place"),
                "share": "private server link", "job": "specific server (game %s)" % t.get("place")}[t["kind"]]

    def update_link_info():
        txt = target_var.get().strip()
        if not txt:
            link_info.configure(text="Click Find game to search by name, or paste a game link, place ID or private server link.", fg=MUTED)
        elif parse_target(txt):
            link_info.configure(text="\u2713 " + short_target(), fg=GREEN)
        else:
            link_info.configure(text="Not recognised - paste a game link, place ID or private server link.", fg=RED)

    target_var.trace_add("write", lambda *a: update_link_info())
    atree.bind("<<TreeviewSelect>>", lambda e: update_launch_btn())
    atree.bind("<Return>", lambda e: start_launch(selected_accounts(), advance=True))

    def on_double(e):
        row = atree.identify_row(e.y)
        if row:
            atree.selection_set(row)
            start_launch(selected_accounts(), advance=True)
    atree.bind("<Double-1>", on_double)

    # ---- launching: a queue, so you can keep picking accounts while earlier ones start ----
    def launch_worker():
        while True:
            acc, target = launch_q.get()
            try:
                if not qs["burst"]:
                    qs["burst"] = True
                    if data.get("fps"):
                        apply_fps(True, data)  # re-apply: Roblox updates create fresh version folders
                    apply_unlock(False)  # only changes the file when no Roblox client is running
                wait = qs["last"] + gap_seconds() - time.time()
                if wait > 0:
                    ui(set_status, "Next launch in %d s ..." % (int(wait) + 1), CYAN)
                    time.sleep(wait)
                if data.get("multi"):
                    close_singleton_events()
                log("Launching %s ..." % acc["name"])
                ui(set_status, "Launching %s ..." % acc["name"], CYAN)
                launch_account(acc, target, log)
                acc["status"] = "OK"
                launched.add(acc.get("id"))
            except Exception as e:
                acc["status"] = "Error"
                log("  failed: %s" % e)
            qs["last"] = time.time()
            with qlock:
                qs["pending"] -= 1
                left_n = qs["pending"]
                if left_n == 0:
                    qs["burst"] = False
            ui(refresh_all)
            if left_n == 0:
                ui(drained)
            else:
                ui(set_status, "%d more waiting ..." % left_n, CYAN)

    def start_launch(accs, advance=False, target=None):
        if not data["accounts"]:
            log("Add an account first.")
            open_configure()
            return
        target = target or parse_target(target_var.get())
        if not target:
            set_status("Pick a game first: click Find game, or paste a link.", RED)
            entry.focus_set()
            return
        if not accs:
            set_status("Pick an account first.", RED)
            return
        if len(accs) > 1 and not multi_var.get():
            if messagebox.askyesno(
                    "Multiple instances are off",
                    "Roblox only opens one window at a time unless multiple instances is on.\n\n"
                    "Turn it on and launch all %d accounts?\n(No = launch only %s.)" % (len(accs), accs[0]["name"])):
                multi_var.set(True)
                on_multi_toggle()
            if not multi_var.get():
                accs = accs[:1]
        data["last_accounts"] = [a["name"] for a in accs]
        if target.get("place"):
            note_game(target["place"])  # keeps the recent-games list (and persists)
        persist()
        with qlock:
            qs["pending"] += len(accs)
            total = qs["pending"]
        for a in accs:
            launch_q.put((a, target))
        set_status("Launching %s ..." % accs[0]["name"] if total == 1 else "%d waiting ..." % total, CYAN)
        if advance and advance_var.get():
            advance_selection(accs)
        if tracker_var.get() and not tracker.running:
            ensure_pm(start_tracker)  # may show a Windows permission prompt

    def finish_exit():
        tracker.stop()
        root.destroy()

    def drained():
        """Called when the queue is empty."""
        if not (state["auto_run"] or close_var.get() or state["quit_when_done"]):
            set_status("Launched \u2713   Pick another account to keep going.", GREEN)
            return
        set_status("Launched \u2713", GREEN)
        if tracker_var.get() or data.get("fps") or data.get("unlock"):
            lw.withdraw()  # stay alive in the background so the FPS overlay / FPS watcher keep working
            root.withdraw()
            watch_roblox(time.time())
        else:
            lw.after(1200, finish_exit)

    def watch_roblox(started):
        # exit once Roblox has been closed for a while (so we never linger forever)
        def poll():
            if roblox_running():
                state["last_seen"] = time.time()
            if time.time() - (state["last_seen"] or started) > 45:
                finish_exit()
                return
            root.after(3000, poll)
        poll()

    # ---- window switching ----
    def open_configure():
        lw.withdraw()
        root.deiconify()
        root.lift()

    def back_to_launcher():
        persist()
        refresh_all()
        root.withdraw()
        lw.deiconify()
        lw.lift()

    def lw_close():
        if qs["pending"] > 0:  # let launches that are already waiting finish first
            state["quit_when_done"] = True
            lw.withdraw()
        else:
            finish_exit()

    lw.protocol("WM_DELETE_WINDOW", lw_close)
    root.protocol("WM_DELETE_WINDOW", back_to_launcher)
    root.bind("<Escape>", lambda e: back_to_launcher())

    bug = {"win": None}

    def open_bug_report():
        if bug["win"] is not None:
            try:
                if bug["win"].winfo_exists():
                    bug["win"].deiconify()
                    bug["win"].lift()
                    return
            except tk.TclError:
                pass
        bw = tk.Toplevel(root)
        bug["win"] = bw
        bw.title("Glint - Report a bug")
        bw.configure(bg=BG)
        bw.geometry("640x540")
        bw.minsize(540, 500)
        try:
            bw.iconphoto(False, logo64, logo128)
            if ico_path:
                bw.iconbitmap(ico_path)
        except Exception:
            pass
        wrap = tk.Frame(bw, bg=BG)
        wrap.pack(fill="both", expand=True, padx=22, pady=18)
        tk.Label(wrap, text="Report a bug", font=(UIB, 18), fg=FG, bg=BG).pack(anchor="w")
        tk.Label(wrap, text="1. Describe the problem at the top   2. Press \u201cCopy & open GitHub\u201d   "
                 "3. Paste it into the new issue (Ctrl+V)", font=(UI, 9), fg=MUTED, bg=BG,
                 anchor="w", justify="left", wraplength=580).pack(fill="x", pady=(4, 10))

        bottom = tk.Frame(wrap, bg=BG)
        bottom.pack(side="bottom", fill="x")
        tw = tk.Frame(wrap, bg=PANEL)
        tw.pack(fill="both", expand=True)
        tsb = ttk.Scrollbar(tw, orient="vertical")
        tx = tk.Text(tw, wrap="word", bg=PANEL, fg="#c9d0f5", insertbackground=FG, relief="flat",
                     font=("Consolas", 9), padx=10, pady=8, yscrollcommand=tsb.set)
        tsb.configure(command=tx.yview)
        tsb.pack(side="right", fill="y")
        tx.pack(side="left", fill="both", expand=True)
        tx.insert("1.0", build_bug_report(data, ""))

        detail_var = tk.BooleanVar(value=False)

        def toggle_detail():
            full = build_bug_report(data, box.get("1.0", "end"), detail_var.get())
            new_details = full[full.index("## Details"):]
            cur = tx.get("1.0", "end").rstrip("\n")
            idx = cur.find("## Details")
            keep = cur[:idx] if idx >= 0 else cur + "\n\n"
            tx.delete("1.0", "end")
            tx.insert("1.0", keep + new_details)

        ttk.Checkbutton(bottom, text="Also include technical details (Windows version, settings, recent log) - optional",
                        variable=detail_var, command=toggle_detail, style="D.TCheckbutton").pack(anchor="w", pady=(8, 0))
        tk.Label(bottom, text="By default the report has no personal details. Nothing is sent automatically - "
                 "you post it yourself. Logins are never included.",
                 font=(UI, 8), fg=MUTED, bg=BG, anchor="w", justify="left", wraplength=580).pack(fill="x", pady=(4, 8))
        result = tk.Label(bottom, text="", font=(UI, 9), fg=GREEN, bg=BG, anchor="w")

        def copy_report():
            bw.clipboard_clear()
            bw.clipboard_append(tx.get("1.0", "end").strip())
            bw.update()
            result.configure(text="Copied \u2713  Paste it into the GitHub issue with Ctrl+V.")

        def copy_and_open():
            copy_report()
            open_url(GITHUB_NEW_ISSUE)

        brow = tk.Frame(bottom, bg=BG)
        brow.pack(fill="x")
        button(brow, "Copy & open GitHub", copy_and_open, "primary", font=(UIB, 11), pady=9).pack(
            side="left", fill="x", expand=True)
        button(brow, "Copy only", copy_report, font=(UIB, 11), pady=9, padx=16).pack(side="left", padx=(8, 0))
        result.pack(fill="x", pady=(8, 0))
        lrow = tk.Frame(bottom, bg=BG)
        lrow.pack(fill="x", pady=(8, 0))
        link(lrow, "GitHub page", GITHUB_PAGE).pack(side="left")
        link(lrow, "All issues", GITHUB_ISSUES).pack(side="left", padx=(14, 0))
        link(lrow, "Open a new issue", GITHUB_NEW_ISSUE).pack(side="left", padx=(14, 0))

    # ---- Roblox links: the Play button on roblox.com ----
    def pass_through(uri):
        proto = "roblox-player" if uri.lower().startswith("roblox-player:") else "roblox"
        try:
            chain_to_roblox(uri, proto)
            log("Link passed to Roblox.")
        except Exception as e:
            log("Could not pass the link to Roblox: %s" % e)
            messagebox.showerror("Glint", "Could not open Roblox:\n%s" % e, parent=lw if lw.winfo_viewable() else root)

    # ---- find a game by name (no link needed) ----
    def note_game(place):
        remember_game(data, place)
        if not known_game_name(data, place):
            def work():
                try:
                    nm = game_name(place)
                except Exception:
                    nm = None
                if nm:
                    ui(lambda: (set_game_name(data, place, nm), persist(), update_link_info()))
            threading.Thread(target=work, daemon=True).start()

    def open_finder():
        dlg = tk.Toplevel(root)
        dlg.title("Glint - Find a game")
        dlg.configure(bg=BG)
        W, H = 540, 580
        dlg.geometry("%dx%d+%d+%d" % (W, H, (dlg.winfo_screenwidth() - W) // 2, max(0, (dlg.winfo_screenheight() - H) // 3)))
        try:
            dlg.iconphoto(False, logo64, logo128)
            if ico_path:
                dlg.iconbitmap(ico_path)
        except Exception:
            pass
        try:
            dlg.transient(lw)
        except Exception:
            pass
        wrap = tk.Frame(dlg, bg=BG)
        wrap.pack(fill="both", expand=True, padx=20, pady=16)
        tk.Label(wrap, text="Find a game", font=(UIB, 15), fg=FG, bg=BG, anchor="w").pack(fill="x")
        qrow = tk.Frame(wrap, bg=BG)
        qrow.pack(fill="x", pady=(10, 0))
        q = tk.StringVar()
        qentry = ttk.Entry(qrow, textvariable=q, font=(UI, 11))
        qentry.pack(side="left", fill="x", expand=True)
        status = tk.Label(wrap, text="", font=(UI, 9), fg=MUTED, bg=BG, anchor="w")
        status.pack(fill="x", pady=(6, 6))
        twrap = tk.Frame(wrap, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
        twrap.pack(fill="both", expand=True)
        tree = ttk.Treeview(twrap, columns=("name", "players", "likes"), show="headings", selectmode="browse",
                            style="Pick.Treeview")
        for c, t, w, a in (("name", "Game", 290, "w"), ("players", "Playing", 80, "e"), ("likes", "Likes", 60, "e")):
            tree.heading(c, text=t)
            tree.column(c, width=w, anchor=a, stretch=(c == "name"))
        tsb = ttk.Scrollbar(twrap, command=tree.yview)
        tree.configure(yscrollcommand=tsb.set)
        tsb.pack(side="right", fill="y")
        tree.pack(side="left", fill="both", expand=True)
        rows, seq = {}, {"n": 0}

        def fill(items, with_stats):
            tree.delete(*tree.get_children())
            rows.clear()
            for i, g in enumerate(items):
                tot = g.get("up", 0) + g.get("down", 0)
                likes = "%d%%" % round(100.0 * g["up"] / tot) if with_stats and tot else ""
                players = "{:,}".format(g["players"]) if with_stats else ""
                iid = str(i)
                rows[iid] = (g["place"], g.get("name"))
                tree.insert("", "end", iid=iid, values=(g.get("name") or "Game %s" % g["place"], players, likes))
            if items:
                tree.selection_set("0")
                tree.focus("0")

        def show_recent():
            rec = data.get("recent_games") or []
            fill(rec, False)
            status.configure(text="Games you launched recently." if rec else
                             "Type a game name and press Enter. Games you launch are listed here next time.", fg=MUTED)

        def show_results(n, text, res, err):
            if n != seq["n"] or not dlg.winfo_exists():
                return  # an older search finished late
            if err:
                fill([], True)
                status.configure(text="Search failed: %s" % err, fg=RED)
            else:
                fill(res, True)
                status.configure(text=("%d games for \u201c%s\u201d" % (len(res), text)) if res else
                                 "No games found for \u201c%s\u201d." % text, fg=GREEN if res else RED)

        def do_search(*_):
            text = q.get().strip()
            seq["n"] += 1
            n = seq["n"]
            if not text:
                show_recent()
                return
            status.configure(text="Searching ...", fg=CYAN)

            def work():
                try:
                    res, err = search_games(text), None
                except Exception as e:
                    res, err = [], str(e)
                ui(show_results, n, text, res, err)
            threading.Thread(target=work, daemon=True).start()

        def use(*_):
            sel = tree.selection()
            if not sel:
                return
            place, name = rows[sel[0]]
            target_var.set(str(place))
            remember_game(data, place, name)
            persist()
            dlg.destroy()

        brow = tk.Frame(wrap, bg=BG)
        brow.pack(fill="x", pady=(12, 0))
        button(qrow, "Search", do_search, pady=5, padx=14).pack(side="left", padx=(8, 0))
        button(brow, "Use this game", use, "primary", font=(UIB, 11), pady=9).pack(side="left", fill="x", expand=True)
        button(brow, "Cancel", dlg.destroy, font=(UIB, 11), pady=9, padx=18).pack(side="left", padx=(8, 0))
        qentry.bind("<Return>", do_search)
        tree.bind("<Double-1>", use)
        tree.bind("<Return>", use)
        dlg.bind("<Escape>", lambda e: dlg.destroy())
        show_recent()
        qentry.focus_set()

    def pick_dialog(target):
        dlg = tk.Toplevel(root)
        dlg.title("Glint - Launch Roblox")
        dlg.configure(bg=BG)
        W, H = 400, 470
        dlg.geometry("%dx%d+%d+%d" % (W, H, (dlg.winfo_screenwidth() - W) // 2, max(0, (dlg.winfo_screenheight() - H) // 3)))
        try:
            dlg.iconphoto(False, logo64, logo128)
            if ico_path:
                dlg.iconbitmap(ico_path)
        except Exception:
            pass
        what = {"place": "Game", "private": "Private server", "job": "A specific server", "share": "Shared server"}
        out = {"v": []}
        wrap = tk.Frame(dlg, bg=BG)
        wrap.pack(fill="both", expand=True, padx=22, pady=18)
        tk.Label(wrap, text="Launch with which account?", font=(UIB, 15), fg=FG, bg=BG, anchor="w").pack(fill="x")
        tk.Label(wrap, text="%s  \u2022  place %s" % (what.get(target["kind"], "Game"), target.get("place", "")),
                 font=(UI, 9), fg=CYAN, bg=BG, anchor="w").pack(fill="x", pady=(2, 10))
        lb = tk.Listbox(wrap, selectmode="extended", activestyle="none", exportselection=False, bg=PANEL, fg=FG,
                        selectbackground=SEL, selectforeground=FG, relief="flat", highlightthickness=1,
                        highlightbackground=LINE, highlightcolor=CYAN, font=(UI, 12), height=8)
        lb.pack(fill="both", expand=True)
        last = (data.get("link_account") or (data.get("last_accounts") or [""])[0])
        pick = 0
        for i, a in enumerate(data["accounts"]):
            lb.insert("end", "  " + a["name"])
            if a["name"] == last:
                pick = i
        lb.selection_set(pick)
        lb.see(pick)
        always = tk.BooleanVar(value=False)
        ttk.Checkbutton(wrap, text="Don't ask again - always use the selected account", variable=always,
                        style="D.TCheckbutton").pack(anchor="w", pady=(10, 0))
        tk.Label(wrap, text="You can turn asking back on in Settings.", font=(UI, 8), fg=MUTED, bg=BG,
                 anchor="w").pack(fill="x", padx=(24, 0))

        def go():
            sel = lb.curselection()
            if not sel:
                return
            accs = [data["accounts"][int(i)] for i in sel]
            if always.get():
                linkask_var.set(False)
                data["link_account"] = accs[0]["name"]
                persist()
            out["v"] = accs
            dlg.destroy()

        def native():
            out["v"] = "native"
            dlg.destroy()

        row = tk.Frame(wrap, bg=BG)
        row.pack(fill="x", pady=(14, 0))
        button(row, "Launch", go, "primary", font=(UIB, 12), pady=10).pack(side="left", fill="x", expand=True)
        button(row, "Open normally", native, pady=10, padx=12).pack(side="left", padx=(8, 0))
        lb.bind("<Double-1>", lambda e: go())
        dlg.bind("<Return>", lambda e: go())
        dlg.bind("<Escape>", lambda e: dlg.destroy())
        dlg.attributes("-topmost", True)  # appear above the browser
        dlg.lift()
        dlg.focus_force()
        dlg.grab_set()
        dlg.wait_window()
        return out["v"]

    def choose_accounts(target):
        accs = data["accounts"]
        if len(accs) == 1:
            return list(accs)
        if not linkask_var.get():
            name = data.get("link_account") or (data.get("last_accounts") or [""])[0]
            return [next((a for a in accs if a["name"] == name), accs[0])]
        return pick_dialog(target)

    def handle_link(uri, fresh=False):
        """fresh = this Glint was started by the link (so it closes again once Roblox is launching)."""
        target = target_from_protocol(uri)
        if target is None:  # something Glint doesn't handle (e.g. join a friend): Roblox does it as usual
            pass_through(uri)
            if fresh:
                root.after(1500, finish_exit)
            return
        if not data["accounts"]:
            state["auto_run"] = False
            lw.deiconify()
            lw.lift()
            messagebox.showinfo("Glint", "Add an account first (Configure), then press Play again.", parent=lw)
            return
        chosen = choose_accounts(target)
        if chosen == "native":
            pass_through(uri)
            if fresh:
                root.after(1500, finish_exit)
            return
        if not chosen:  # closed the picker
            if fresh:
                finish_exit()
            return
        log("Roblox link: launching %s" % ", ".join(a["name"] for a in chosen))
        start_launch(chosen, advance=False, target=target)

    def poll_links():
        try:
            for fn in sorted(os.listdir(LINK_DIR)):
                fp = os.path.join(LINK_DIR, fn)
                if not fn.endswith(".link"):
                    continue
                try:
                    age = time.time() - os.path.getmtime(fp)
                    with open(fp, "r", encoding="utf-8") as f:
                        uri = f.read().strip()
                    os.remove(fp)
                except OSError:
                    continue
                if age < 120 and LINK_OK.match(uri):
                    handle_link(uri)
                    break  # one at a time; the next one is picked up on the next tick
        except OSError:
            pass
        root.after(500, poll_links)

    def offer_update(info):
        parent = lw if lw.winfo_viewable() else root
        notes = info["notes"][:500] + ("..." if len(info["notes"]) > 500 else "")
        msg = "Glint %s is available (you have v%s)." % (info["tag"], APP_VERSION)
        if notes:
            msg += "\n\n" + notes
        msg += "\n\nUpdate now? Glint will restart."
        if not messagebox.askyesno("Update available", msg, parent=parent):
            return
        if not info.get("url"):
            import webbrowser
            webbrowser.open(info["page"] or "https://github.com/" + UPDATE_REPO + "/releases/latest")
            return

        def work():
            try:
                path = install_update(info, log)
                relaunch(path)
                ui(finish_exit)
            except Exception as e:
                log("Update failed: %s" % e)
                ui(lambda: messagebox.showerror("Update failed", "Could not update:\n%s\n\nYou can download it "
                    "yourself from the GitHub releases page." % e, parent=parent))
        threading.Thread(target=work, daemon=True).start()

    def update_worker():
        cleanup_old_update()
        info = check_for_update()
        if info:
            ui(offer_update, info)

    def startup():
        if "fps_asked" not in data:
            data["fps_asked"] = True
            if messagebox.askyesno(
                    "FPS boost",
                    "Enable the FPS boost?\n\nIt applies optimized Roblox graphics flags "
                    "(no grass, lower-detail distant parts, grey sky, lowest render quality) "
                    "for much higher FPS. It also sets Roblox's max frame rate to 1000 and applies "
                    "a ClientSettings preset.\n\nYou can switch it off any time in Settings "
                    "(your original files are put back)."):
                fps_var.set(True)
                toggle_fps()
            persist()
        elif fps_var.get():
            apply_fps(True, data)
            persist()
        apply_unlock(False)
        threading.Thread(target=fps_watcher, daemon=True).start()
        if tracker_var.get():
            ensure_pm(start_tracker)
        ensure_handle()
        set_singleton_mutex(multi_var.get())
        set_own_hook(lambda: apply_fps(True, data) if data.get("fps") else None)
        if "setup_asked" not in data:  # first run: offer the Bloxstrap-style setup
            data["setup_asked"] = True
            if messagebox.askyesno(
                    "Set up Glint like Bloxstrap?",
                    "Make Glint work like Bloxstrap? (recommended)\n\n"
                    "1. Pressing Play on roblox.com opens Glint, which starts Roblox for you.\n"
                    "2. Glint downloads and keeps its own copy of Roblox (a few hundred MB, one time) and starts "
                    "games from it. Your normal Roblox install is not touched.\n\n"
                    "Only your own Windows user is changed (no admin rights). Glint must stay where it is. "
                    "You can undo both any time in Settings, or run Glint.bat --restore-links."):
                err = None if takeover_var.get() else enable_protocol()
                if err:
                    log("Could not take over Roblox links: %s" % err)
                    messagebox.showerror("Glint", "Could not set up the Play button:\n%s" % err)
                else:
                    takeover_var.set(True)
                    log("Roblox links now open with Glint.")
                own_var.set(True)
                set_own_client(True)
            persist()
        if own_var.get():  # download / update Glint's own Roblox in the background so Play is instant
            threading.Thread(target=own_background_install, daemon=True).start()
        if takeover_var.get():
            err = refresh_protocol()
            if err:
                log("Could not keep Roblox links on Glint: %s" % err)
        if update_var.get() and not state["auto_run"]:
            threading.Thread(target=update_worker, daemon=True).start()

    set_singleton_mutex(multi_var.get())
    threading.Thread(target=multi_loop, daemon=True).start()
    threading.Thread(target=launch_worker, daemon=True).start()
    refresh_all()
    restore_selection()
    update_link_info()
    log("--- Glint v%s started ---" % APP_VERSION)
    log("Ready. Pick an account, paste a link, then Launch.")
    root.after(400, startup)

    # straight into the game when everything is set up and the user chose to skip this screen
    root.after(500, poll_links)
    if pending_link:  # Glint was started by pressing Play on the website
        lw.withdraw()
        state["auto_run"] = True
        root.after(700, lambda: handle_link(pending_link, fresh=True))
    elif data.get("auto") and data["accounts"] and parse_target(target_var.get()) and not shift_held():
        lw.withdraw()
        state["auto_run"] = True
        root.after(900, lambda: start_launch(selected_accounts() or list(data["accounts"])))
    root.mainloop()


# ----------------------------------------------------------------------------
# Embedded diamond.ico (base64, 6 sizes: 16-256px). Kept at the bottom so the code stays readable.
# ----------------------------------------------------------------------------
ICO_B64 = (
    "AAABAAYAEBAAAAAAIABCAwAAZgAAACAgAAAAACAAyQgAAKgDAAAwMAAAAAAgAM4PAABxDAAAQEAAAAAAIADSFwAAPxwAAICAAAAA"
    "ACAAFD0AABE0AAAAAAAAAAAgAFCKAAAlcQAAiVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAADCUlEQVR4nJWTXWgc"
    "ZRiFzzczO/uX3W6azca16V+iqU0IBqa9KdQhtvSme2WZQpEYsaVFrELxpqHW6RIVQQRbRWqVShBpuiFNbatiETEKSaibou3aUgtp"
    "ltbFmqwbszvd2ZlvvtebGEKgoOfmwOEc3pvnBf6HiIgtdQBQlnVYJpORvi2VJGASmFxINQ3JtjZijPFcLqcyxhwiYowxWlyapikB"
    "CAKoA9AAoBFAAkDTggfvTk/1ENGlcpmaiIgREVMAwDAMOZ1O+x9b3ZE8mhl+obEx2uoIgsxF1XIALksh4ZFT8CIJpVCYmrhypRaL"
    "xeTu7m7+72V12+Ztbf3ZmcvHpom+t4hniehajco/zlH5gks0/Ad56a/Ie2Nk5uIWbUsrAD9MU2K6riubdqTamo3975ci0adLf8Pu"
    "qsdsRwPqmmXUHAFcteC/n0dl6g7i0RgCUVEZLf4w8NLXX3z6GwOAEyPZ58ftJz+e+csp+hSoqkwP2j2FBwG10RZku8JVCpbCXRbi"
    "Ljkr4qGG8IZbLz7bs+kTpmn7fb7qYKRl3y+ncpV1u5xKCZIC0VpTK4Eq1FVVjqjnOfX358OugBzx10NpKZw3x7fvS4rUvJTNfsQn"
    "biSsVdOv9nXEZ6+p4QgkBSQixMNB5vrDkhuWORcKoAbqoD4+l7sYf/Nw4adCJZVKehJjjAzjLf7OiXN3Hy2eObRmhV10KShbjBhj"
    "jEsM3OdwBu6Xw4+4pduJbw5deP3zvGFkeDqdFhIADA3t9toNU7x79JWJJ6SxI00RRiUu/FDhqBI5VPbUuriP5tZff+3tvgNjhmGK"
    "oaHdHgAsIgkAa/XewPzogH/PB9f7J62NL7c8sPOdsw41/CnWuRvzHx48rh3RY732aH7AXkR3OcpoNgI7m8dXRnvGB6z5eOeOKYvU"
    "SPHmsd+feS55dn1xEpeqABYRlpb/i7m3vfblxL2S/fN7fV1razcTHd6t7yqnDhfO/lpMmZq9dPxQ6bqpAAidPv3Z1pODg08BCC1k"
    "/126risAfAB8mqb5Htb7BxGXYqJxsM5VAAAAAElFTkSuQmCCiVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAIkElE"
    "QVR4nN2XaWxc1RXH/+fe997MmzfjLYwdO5M4ZLGdSUIIJgRSUrEkCCRomiI2qQQKVUMblkotiAJqMGlJm7CI0LTsRBRRNRIiahEJ"
    "m1RolQKuSQKuiRPHZmxnjONl7NnnLff0g2cSk5IF+q1XutJ7eve+/++cc++55wL/742Zxcm+02n+53THHS8OIuKTjTkZHRW/SwAa"
    "AL3YjVN0HYB++eWXG0REtm0vA0An8oR2EjABQIbDYT1QV6c5hYJkZZGlvBN6Iw2AhOSa6jDt2rVr+LWdO+t1Xd8Wj8dXElFs/fr1"
    "oqWlRZ0KoGS1XtfUZMbTPj/2dQogbCAECegE5gmIkntL7wDg03jgwK78vvbPblowr+k+AFNra2vfZeYHAbwC4EsQxwMUxWuM+iUz"
    "QrED4+YF0fqK791/39xU3pMQmqYUCPLocAEBSKWO/pCEYOEWnK7uw1ZFKPBWJDLjxsR4Yody3Q/XrVunAfAmC052Z1E87GtcPLes"
    "sytrXXfZkvDqhzfdM31aRdTUMM3xwDQxg6UOEWJ0JfNQo4wGdqEYIGZASgiVwaFUb6JzZZOLiqqFdwODiXA47A4NDRWKEKok+mXx"
    "ZYvKOvcMBn58wxWR1Zsf/+3eUMWqvw0qyiq4GQ1WimGlgeBIAQECdF3CGMjCHPUQHHVhjTGslILbfgi+jlzl1e/2BCM/vff2uTCa"
    "qitmLywHwr5iiEVJuLTa9abl54Q6d7f619+7ds6F9//ysY+ldWEmATWYE9PH8qpPZzA8KElgAxjyA+VVuqqyBI5IARYelC4ATqJ3"
    "ZBSRTApq75C5dOnVdz/a8tBP5h78oM3XuGxRGVBjlLRLALK2oTmw/+9v0mObH5k/87a7trR5/rNzSXiSQdDhaxtGUHoYEhqExyCL"
    "kPA8VEKJyioNY54HIgmhKQx3dyHABFOyokJGqfZB34I5F9225Q9PPrGoc/c7qG2ImEUvkAAgwtGonoofpld27Fg6Zc3Nv/+3NObC"
    "hfKbkJof5NeABInIoIMhywRrOuxIAG7IDzPgg292FTxhIO8LAuk0Bo/kMR1+QPkEUUAIm6A+SeqzfMtv3PrSzp3fSh7uF+FoVAcg"
    "qLm5WW+Lx/Unf3RDZPp1G1/Y0StrLXYKCkIezWIEVkyyyqeOLDKlMZ6BWQ62gyHSgq5CLgX3C5v0QAgF+/NCLpHEVEHwGCCAAQaB"
    "4Nm2MC5YIkbaup+45fabn+hpbq5zCIDW2LjM9Ma7/Q889+7aVz6b1dL1RZ4DOkhN2t/MEoZfZRd5xuGxI1qDJ4CQ3x04M+d5mZSI"
    "SALCFc7BUO/4VLtAwcm7TQhiO89cHQmIulUjG9b86pKtFYXZuc7O3TkBgDs7e90BdYZ4fN38l69fPPLnqTVlkiXD8EvSfYJ0nyDD"
    "D1JEAVEJLxDwlGkCVpCkaUHzBQBheRwy2XUAi00i9msT3dTIlkDZ1Ao5bZX96rXPXrKND4WpM9PrAmABgIF+1wj68vuSUdW2/ReP"
    "XdWU/Ij0oPBcTzEDzABYsccajYE1XSKrlIRisFLMrASkhpyWtSWUJqAUoziRPU8ZsMTMi+w9Lx7YtLnw9hTPPEMW0N9/FEABUInu"
    "tsKc+qrc1mfeGq46sv2hlY12PM8+IcDHshwTxlzPMnxIAQIE8MQ6kfAbSCHjBXhybiPFytbFzPNp8NMz3mn50wN/PBI5uyoXi+3L"
    "l3RLiUgBcLv2/iPT1Hx2Ye0P13YsDf3r1+fOFIW0QyRo4mAVUEg7CAkLaeLJSZQQ0JB2M16IiQEQkWB2coRI1G87zQc23nPN9z9p"
    "XLzE7tp7KAPAPT4TcjE9Ovt7P07Nnn+Ze/2VV7191ey+rWfWWJSzwYIAgoe8oyzbgCPgQE0cs8TkwWKv4ORVEKRABDh55uppIaq6"
    "dPiZa29a9cas6Aqvs3dPChhwiuI8GeAYxNCQPZzuTJXXn+M81bJm2+p5I38tKwsJx1VKgFlBF2mhpEa2ywqCFQSk7RkFR4ClBDF7"
    "nlKhYEhEVuR23fnync/VyFnuSOZgEiMjXzoHjgcohcIbj8XylplNvf9hJtP33qObr5yXbleaJRisCIQxpQK6j1LMLJkhfDrSKu0E"
    "GAIAK6lMUf9tb//2sRd/e3B7T0qUe6nxWCx/vPhXAZQgnPj+1mz9WVXZjRu3xSPpNzZcPMcbzrq61OAiZXOZNEWKACgCBXSk3IwK"
    "QSq4OSnrl8hET/3uDc/fsaUvuqQuO3CgLTs57qcC4BJErLUjPee85sKtN67ds7ymfdNZ03U3W2AueMpyfcrWiFyS5JnwCspmy855"
    "XNfg92hZ7JE7Vq9pnT9/sd3R2pEG4BSt/6/68EQ1YRFiyB7t+ihZs2iZs+6Ga17/TsPAC5GwRdk8yazOQteoIDSy/Y6HfE7pU2pC"
    "FF6Reunqn63ZMaPhfDce70oCQ/aJxE8GUAqFOzo6WsiN9CUz1jT71S13PfvdBWPvmFY5jbqe4fdx1jAoq1K2YfkqqH6l/V7Lmw8+"
    "VdZfZruiL5lIdOdP5PrTASh5wk32d+SmVXLqL7sOjqfbn990RUOqZziHaiNAqZDJSXvUq44sd3rf5ld/88HTrYkpMzgV37+/FPdv"
    "XJaXABQAp/uT7szcebXZ+3++JbaA3ms590xpD2lwAmm3MC3q84bm7d3wyA8e7p6zsDrX0/55Ke5H9/uJ2uleOCZKtqoqc2b9+ZWf"
    "73lD+91r+27NB+ZdsLQ/rwb8PR9fe8t5Tzc2XeR29rWOYnQ0h6/Ycv8LQAlCLy+vNyvrZpWnkzHjw3/uvsUgIaMrVzw3JW8VEhwf"
    "H4/Fcjhm/Snb1wE4WjuWz1hojo8MGpeuvLjc8Bl4//U3x7UpNfZ476eTxU/q+m/aCBO1nC8cjgYBhACEis+lavdr3SO/yaWTil1E"
    "o1EBAB0dHQrHrP5alv8HM0Mfc55VKYcAAAAASUVORK5CYIKJUE5HDQoaCgAAAA1JSERSAAAAMAAAADAIBgAAAFcC+YcAAA+VSURB"
    "VHic7Vp7lFxFmf9V1a376J7umZ5HZjIzyeQxeRFeMRFiggZWVAKHBVTWXTWBfeADhZU9PvawsgY5Hlf2QVQUoq4HOItnIRIVWVQ4"
    "KBGCi0hWDAkh75kMM5n0dM/c7tvd91X17R/dPelJJjEBPLt/WOd8031qbtX9/b76ffV9t24Df2x/bG+osf/j8Y2NXs8gfgbXsgbj"
    "NWv8/nptcs4vfOELZ4LnjIFzAAKAAUACMAFYAOxj1nea1jgGFgDzlltucQAgjuNPFovFpUQkiOj3EjJOAzwwxdu9Ap0RRxzzjNZc"
    "6zQDqHbd6apgdn16cnmBzpt9Lrvrrru8/v5+SwjxD47jpBljOzdt2iSJiBhjJ534VBpulIwAegXaKkZznDSUYxqOZQqlpCAr5iCb"
    "AQBpfVoxwTivAmI+MZak/L5fVx5++GF77dq1NzY1NX1aa70vCIKPJhKJbah6heEk3jnZCkzVemenbPaFjI1mM9nVYzmmY8WmIYWV"
    "NEQMQYZgRJpByqmzRFH1U0ogQlV4tX7GOEkJTIyOVHbt3vtnSxb1/z2ADgAjnPMex3GeIaKfAPjEhg0bBgCw22+/XU8H9FTgBTo7"
    "jXRFWlFz0u5u70vsz/sSbiBlulmSmZS2aRuwJDeIGGBMuiSOASshuSE4CyqBmuqpGLFixFSk47IXv2P5PPuvPnTloneuWXltczp5"
    "IYBCoVC4v1Qqbdm0Zcvupzdv9rdu3aprq0DHgz05+I4OmZJtlmTSmTl/fmrnjlGx7s8v77r91huuLpt2L2kCETg4A+l6HFRXWwgG"
    "rnQp1kxHnKVIgQhgtb9gYEQgMMY0oMn2vV0/e+Kp7TffsP47nld4LJPJXAcgUQMcA1AATiBhnBq8tAyIROfChemdL4/J225478xL"
    "PvXJDY9pu3tVBj6T6A8VwI7bK4gAwYEOYJvnI34NWEPhNO7SgGED0sehw4czF5y1+tqLdeT9+sFHn3li/rKV85JNKXVg30DRi8d9"
    "ZLMNo6q3aSQwNWDr4J1MorN3afMr24eMf/78X/evWLfu1icqctlYSetOia29aT7TV9rBcbsdF4CKdaHb4WYLh1XKY4wbaNWRnsKW"
    "oGHGCMtZfuDlIb3mUDLZnU6qPRIltf9l1XTuqkwsE+NxUxnwOoDpSDQmkir4zk6jEfzu5/aI+7766bPPu+66Ox4ryWVeCSplcb49"
    "zxdKwm7T5pwBYAy8ZhASvMngQwzoFhyzMyaGuAHOOZ+8DgQmbc6bGN/96gHMdxwuggDqx6+IhXMvuPaL/7l5w7LfPbdHdPbOa5aJ"
    "tJOSbRY6OiSquai+llMWnwMzjbSUlky0OV1di9O7t77CfvjQnRe0rb3qS4+7YnFYgTY4hA5BFYGenROoGBFcZoA36JLFEahFYFxr"
    "zNBAe4+NQhRAoyHzMwFIgpc7jEIhQp+OQYJB6EjTU3vF/Kb+y+94/PGNq3dv3cVbu/rSMpF20oFlorPTaCTBj4GHyGQcafImq2PG"
    "3OQr216gnz957yXx6nfd8cQEn61DaIOjuoGz6gw7J7AYGrukBKi6qCQMMK6RS3HYwoTkBnibiaQEjnJZCxENMiwwJ8auvYNYKMQx"
    "UQvOGRT00/vQU+lY88Wt2+579/5tL1CqeUaT2dJpZcLQAPomy5AGCXWKyDakyHRarz73aPSbXz96+ZGzV234eQ6dItaKM4AIGlUD"
    "IqjQQPv/5AAzxiivklDgQBPHIDS6tYZWCpoBPa0Sh6mKUjEBmBq51w4iqmh0QUPVPKAJ0AyaSWi1bT/ahq3lt21/6WdXD7z4WCTs"
    "hB3ZHRLwp6xAlUBbzNsyzcboS8+r3+ze/5fbe877yrNlZCwJcJsLZoEze9IYbAjDBHaXsLwY4aBjg1lJGJqADge+aaJHcnApwE0D"
    "XX1pxFEMkgkYVhMYKti/ZwRv4TZABgRMziDBIcFhckaSC9MCnh9Geru/+Esv7Dn8UXfwBeVkmo3W1kjUsU/uQud0LzF27Hg2GDp4"
    "8EPbjTlXHczp384WIEUnr1gZQBEgs3kMpUO+1ddoEUq7kcHHxwVe4kAooFHSMIXCWHuFPx35utWRvBAciUe6BbOFQlzNDNNUCoxB"
    "GND5EWITvHftoQMHSl3d3Xf3nXcez+fzABryAOdFAlJiojA6vGe4O/HDXwQtLQlNSp+65tdksKdTOvlWZg4cPCRmcRH1EiAiZegZ"
    "7fHAvIqKjx4xZgkZ9hlgSseSze5TO5wB93wxjnawiNgpbkECJAvExDXp4sh7xgaBJpbWqckBdQL00tCQmrXonMTZ563c+rtdex7Y"
    "tWTWhp/vjlmLAyg6BQfGEJRUJpxBR5mBVsU4GBGElACLSpohFtJoJUSIwEASMIzYnhiP5iltGccKpBMbF4A/oTF3eQId75z41jn9"
    "5/5s1qJV5o7XdnmT16Cemg1DR+7RaNbSS5x3r71i802riw8smWmgXIm1oIiYjonp6ATjOtKKJPMMTZYIi6SJiJQmHRGrlgCx1lG1"
    "jzRxGZbtQMcUGwYQEBBPa4zHFFZC3THLwvkfjh+6dN0HHpzVf4kTqaMRhNColRXHCIzaqlKJIh2UgnzYTvf+6xe//bcXx8+kmmwe"
    "xSBWrWCmMQAQyAaUbkqKHMGodbKGZat9J4MlHJ4nN0gBArU6n51gDEzHRLZt8wvWy+e//OjXvlk6YCjtlIJKNoqQtVQddz1ANTCg"
    "XbMcu6XDfl9PIty06dnx7I5H7vrY2+lACMmrO9w0GgUxThq5smqzUzTOwMDYiRFZ7eNIJSnvT6hWAoHoZNok0qHgK661Dz+vfvFv"
    "D9z2g7GuRc2RO3bYd81yDAzVCUzJoBrZbOwFyXB48EBp8UVz4nXr7tiz1P7tXR9YYbhuIJhgNO1WwRGj6OtWlkSZUwxNJ0YlERgx"
    "hZSE5xfjNuLquFWqzcaJAg/s7HclvXjZwMaPvPszOxet6lfDewdLnu9HyGZjHKtKJ7dIqnUq5PdFRqCD7MCA13/RUlr19o/88tqz"
    "R7590QJTuRVATOddaIq0NEsCzDJUmcCPr08BMM6NOLDDmFQknOlWlHGQXyLMOSehe/+0eN/FF33kqf4LllJ2cMCToRdgPBniuLK6"
    "kQDV/hm7rh+FajQojw8XO5f06fXrb9l84+rKD+d0OqwcEvET/UaAQDZWqWSS52i6Bz0y4CR5ntwwCRgnyIwxIA40tXUm2Pnr+OMf"
    "vvXWBztbO1TJy3mRzvquG4Q16Ux5Jmj0VL1TA6NxMYqCQr5QsRCWdh0cLz/64FfvvfmS+AXLtnms9BTx1uNgrKxbkymWYyc8whIA"
    "jnQSucCNptW/1pqksPhbP2y9dO/z939j9xMHvHSrXy7mRyvFIAiB0eg47+N4AlNXIpuNvECHuSP7yvNnJ8J/+tJ/HYkHf7rxhtUY"
    "qijJ2JR4YIxDoVhRbSyJEqcYx4cBMY2UiaJfUCfon3GiuCLYsvc6ozuTv9r49U/e99r8ZZ3h8OCBkhfmA+Ry0fGePxmBOokp8TA4"
    "erC49B296v3X3L5jZfvur1+1TJbcCpsS1AyKQmXYJUMxy6ByvQJhAIEEuKECJ45VHPLkseeRmu6LYEvWJHxz1cg31q/5zPazLpqr"
    "BgZe8YxAB8gnIlTzyRTP/z4CdRKx64ahob1gZHh/cd7b+mnVFTc+ue4tufuXzzWp6BP4pJYZEQyMxTqZTLA8wHHsPEfU9Z8AJBir"
    "MmAcFJQ1ehYlMP/a8HsXX/mJx+etWKBHRoaLkkq+a/sRMBQ3YDotAseRGIkLURSEpcAv5Ye9TGu7+uznbv3ezReHP+lsTbAgImJV"
    "NzNGhLEytSZTLFe7FYGBAIGmJMuFrsrU9c8YoEKi5haHLb/OeOrGjV+5P6OtqBSOlaJyoVIIghCjo3XpTOv9UxGYSmJ0NPbCXOBN"
    "ZMspGZSffHZ/8Zc/feCbN12sdzDD4qQ11fOB6+s20QSvNjHjqOo/bVOhUojbiWsAjGnSxEjyFR+yXv3+3i13P/PgixNNM0TFOzJU"
    "9oKxENnsSXV/ugTqJKrxkMtFZohgJDdYOntJS/j5v/uPoZbiLzdev4qPepHBOCPi0BTGPFGWpAV8rQhcEzhxH04UqihAE6DAOFFU"
    "Euz8K538SO/Ojbevv/vg0uXt0ZGR/Y26P2HHeb0EJkmMj1ciibI/vG/AW7ymR112+W3bL5116J7LzjF9t8KY4NAEiZyKkwmLXKVg"
    "aEWGNJXHirHNtMm4IO17hAUrnajl0vymq9d86vnFb1uoRvbvLxraC1w3DGu6/73ePx0Cx5EYid0gCEMd+BNHDxXnvmW2vvSam39y"
    "/YqJh5bOslD0NROMkK3GwRjAGGnwVBPPRuNxBgIIyqCuOQm25C/UI+/5m8/9aM7CWXpi4nAx1IFfCIIQGDlt8KdLoJGEqsdDMe9W"
    "lJrwlDTCf7nzK/fftCZ8OpN2eByF5AbUKpIoCmhNHJSyyPVLujVWESWTllix3nzuHx+659/V4UqgxIRXzI9WGnSvcJrgz4QAcMwr"
    "tXgYD8ayI+WuFlV5+JHt43te2Hz3x9fQHg2D+b5uCixStuQVbvLA0XEUlONmijlb8QHn4BMTT359y11Pj3X1GJVcdqRshgiQz9fr"
    "nNMGf6YEgCnxkAzlhBdkB494Z50zI7zp4/ce6GMvfu2DK42cG9q8CLKabFY0HVYyfSWDginOvSzhukv23v2Zq+98dfFbW+Ps4IAn"
    "3bI/Pl45Pmj/oARqJIaUawdhpLP+yPABb+GF/epPLr/1V9cseO07axZy/Wouass0s4nmFjHuHq5k5ixzMPMq77tr135264LV8/SR"
    "gUPFSAe+a5+57t8IgUYSCqPVoi8quxX36GvF7oVd+n3X3/KDj11Q2DIjIzt8RxdaRDyeTMnOsz4Y//h9n/rc5u4ZaeUWhotRxa0U"
    "g2yI0dH6yfMZg3+9BIDGeMhmYzPMB97EeNmJj3qHhsLKj75359euv1C/nOgWfl9Ke+deY++9Z9umjYPPHi7ZrFTyjuTLVsT9WpH2"
    "usG/0VY/ipdAr9Pc3NeSmL145pILr1gA9Cz41n2PvD9XVpsrbvz97z786AeB9gWLL1q7MDF78czm5r4WoNepjp08XHvdIN4MEhyY"
    "KZubTTMyk/bcBbOTO5/7qf/ib393pbCkPH/Jki1LV11mH9w7WJKOF7iDUVDT/Wll2z8kgUYSAphpZDKOjCxutqTazaG9/x0BoN4F"
    "K82J4lgoKlFUzbRvDvj6zd+MVpfB5NvMjG7myZkzRBrAyMhRNc5djZxTP1Fo1P3/CwKN75Mb3ynX+ocaa6rG7fINB+6b+VsH1vDZ"
    "aMBUwNTQ94bb/wKl4nOdwYFO1AAAAABJRU5ErkJggolQTkcNChoKAAAADUlIRFIAAABAAAAAQAgGAAAAqmlx3gAAF5lJREFUeJzt"
    "e3l8XNWV5nfvfVstqkX7ZssG3LYxGBxMsMHEcSBsTkhgEmh6AgmZDIFM2AZoCOmwpT2kM9NMuhkIQwIEEiCBnkCHdBICNE4DYQk2"
    "izEOBhsvkkqlklSq7e33nv6jVHJJlmTZ4O6Z3+Tod3+v9Oq9e+/57nfOPee8V8Cf5E/yJ/n/Wdj/5ePQPi8gYgDAGNvntVPJBwVg"
    "8v3/VoDSNJ/3W/gB3MOmafwgNDHdd5///Oc5AIyOjqYLhUITAFZjw/6IdgDKTz5O1eqvAdC9v/Mak976f6juSN3d3QKAE4/Hv8IY"
    "awBww4YNG3QAIfaDFbNFjE36XFvxsWMHR5tiUGONiIFSLD12g1LygEyDc0EAkAcANkpgjMA5LVywgC1sXgRz2RzvkZtueh5AYv36"
    "9Uc3NDTIUqlEa9askWNd7BOI2UxsqtXmQA8HfI4mXyTDuKAGyZWMcpBipCSPUoRVIooBQHQ/Fa+JPXaMOZxs5hAYI1ZxVLmc8QCU"
    "BgZyZ7a1NT8IQDiO8+VoNPrTSXP+wADUf19bcYGODgHfF8kwpsmoJZShaZbUBRmaULrGTaVzIsVg6AdklxMmwBjB8wCLEw9CFU+Y"
    "4e23fKtr9eoTPm1Z1nmc8ySqilaUUg/Ztv3Qr3/963c2b94c3nzzzYR9gDDT5CavfNUBdXSItBvRw4irSS1hmLrQ4larYcUjhuCm"
    "kJYuNMk5Cc5JCabrAJE4IBAYkxQAYFKSruvIbd/mrP/lvWcuXLjgOgBJAAUo+GOuXAOQBlABcP0555xzBwA8+uijaiYQppvYVMoL"
    "tLRoST+qyYiuGyJiyqhptKQ7rZ1DBR5sHyQ0N5uwEhpMXUBwDqGP7TLahMO4eIECAJg6RzjVNMZOykBBKgXPlpGoQd+45LNdX/zc"
    "GWu7O9vO4JybUAA4PN/3f1EoFB5+8slXX7/11qvdt99+W44pPy0TptoFZlA+oocmN4xo0uSImR3d7dHNb/XhK+d/uv0zp318cbHi"
    "+oxxDcS4qkYmrIqAADE1AWypAKYJgwFMKOlN3pAZcQKqvowDREQkGCkiGUAw9tlzL/3f13/zitc/d8aqvwEHf3/n7psPmTf3dgAR"
    "7NkuCYCq63YvEKYLZKZWvjFh6KRboiFldXbMjW/auAvrrv6Lnj+/6Pz/EkmYlg0sVgQCwNjMtkdMg2gC3vQDBH0KxyCEpBlMkmis"
    "TwHewvGOKoX+4z9/+PYLzvvcdemY2Xji2j9fuzuzy05FYsH7vVudouf5yOVCVFGsmcFeTJguDthL+SAVN3UlrEhDi9XW1dnw+uu7"
    "cdetX1t48rlnXfajvDi2qaieXNnOCxWBedKbAtpJnSsfUtMxFEqEmwqIahwGqRlQI4DrQJSpzMZ3eW6wrH1q7ennwoQ9uHHLwMuv"
    "/ObZ8JDVn4gPDOwshyIhE14RxZYWIJer9TAlE+qJx+rO7a28pVuReEuksbuz4fU/7MbPb7/26BPOOfu6HwyIY0ds0G6Hr+QKG3UJ"
    "JQhKKNA0TZk6KAa8F+GYk9SxsEngj5YOMgCpE2hyMwDSAWVyoJX4K305rBgtE372mnHCTjt1eKU8vMPHnyVMsyHKIulog9VghWbC"
    "SHimgZYWDeipRZR7BWl8WuXb2sQE5aNdkcauzobNr/Wzpx++5fi5p3zyL+8b4EsqPsgkkDSQeD6L1jjwthYBJwLApvirjsKSGnaE"
    "Cj2Bwvx2E7ulAlMEPtU9BJAwwWMM7/5xKxpcjmYNTElJ/L4XMdfqWH7x7/9wxyfeeHU3Ghtb42YkHW1obLDCdMJI+hEdLbaGiWH1"
    "uM71DNgT2bW1iaRr6aGZMAxmmqloVyTRmI6//cYAXvnH75xkHnv81Q/047AgAOkcTAGc+aAdLpaXA7zDQwRsmiyDCfDAhZ1m8BRD"
    "CzQk2kyQ9FHg2tSGQ9UYUFkO3to2iI8yCSKACc7AQXh0I+YHqaOvfON3f3fG25uHmEg0xcxkW1SHbgWpuJn0Izra2upZMM6EySc4"
    "OjpE0nX10BKGETfNZFNXRIulolvfyrEtT9/+qdEFy674aQbdTIE0jvEclAjETVjPZTE/wfCaHgEDTbA7gKA0A4hyvKdztGlalRMR"
    "DV1pA1u5Xr1mwi0KpFlgKQ2b3n4H7aQjTqrqaAkAZwwcoMffRHtGW/T1d1+64+z3+4sCLB5JNXZFTBExwsaEkfZ9DeioZ8EEBuwJ"
    "dHxfyGibZmoxI9nYHAm4sHb2FcT25+46d2v7n3395wNo1QnEGSYn4BwuaCDAUZkKenkAG3ziihLAlAJSArtDwoJQAaEEPIUFnSYy"
    "oT8+lz2M4QBX8DGK93YXcAxCUN28q/8wMJODfrMZTZtL8y7e+bu7vlAOHN32dDPR1hE1faYHVouORk+rhvB7Fn2SY2gTyTCmKUPT"
    "0q0dVi7va9yW+s7n7/nSy4n5F/0qi3QEIOytfG0yJAyI3w9jcQPwqm5NZIHQwZSPkZQAmECjDEFKQgkN8VYLhlAYEAYYaMxLE5Rm"
    "gaUFNr6xFYcyvbpTTDEuwMAiGujZd5B4IdP55U2/uvui9nTc6u+tiPSceZYyNC0p4wJt7gRTqCFZPdEUchULeXtzp7FtWy+OaW0w"
    "Nq6//5Lf8rYvPptDLCYgiY0HF1M1MA8yr7Dw/SKGdR95plUVAUEKDRQX2ApCN2PVexhAClCCoadJx9bqjJQCQTEOCELJH0LvoI0j"
    "ICExw/gEUMyEfGk7rCd3NJ/3z0/cedmnlndGt722hVob20wZDQTCcFoGcBAxS+/St294QX7lrNXJe3/xk1se9hov/H0R0ZgFJjUI"
    "0sFnalKD4Bb4c8M4niv1ummBcwNcMyEkgaWAvCfVUgDcMCAMA4IBPAAWd1go+wGgWVxwHVyPgyckXn9lC44TBjQCBAT4TE0xiHgE"
    "7I0+WI9sTpz33++4+7/95eXntOx47VnfSnbqIGJA9zjrq9ldNafXe3paDc+r6F/96pe6rrrmymuf9qKHv1WE1qBByf0odzGAAoK+"
    "ugnPJyws9YA454AAhhcB71WAlQQEISAUwAQQaoBmAX942UO3T2hXEqQzeJaNV1/YglWCzxwpThYNoFIAdlgL5Np5/rZ/ePTRv730"
    "+lveaWw25a5NQx6QCQCoCZEgkWID5QHq6mq0XGW2P/wzO5C+CrlW5emsqycMFCot3JameSsj+pbXtmCp4FIyhigx+ggpVpZSiO5u"
    "tX2ur4JdO9ihXAQeY+woDhYCyiapi0MX4e3yrtLc9n7yuJCSaP9qjs1EcInL8KbmtsY56Wg5M6Dmpg9nwFA9UHukVKqoOV1LIxdd"
    "9LUdxx699J4zjz72e3/1CzTFTQLtZ+mRIKDny0H3XPFs/5BxdG3HpbGgXhGHFHbc8OAOD0aPAFMg4nsskww0tzhDxY32ytCLxcAU"
    "ZrsEBIBxgldi+PjF0eL2wqZrPnPy2jcXHLUi0rcjU6m/VsN4XJxRedZI/ijCBctPii/76KoXioPb/mdmdffVdz5jJxvjXEmJfeQ4"
    "NWFgIIRKaEFEeXHDKZZ9Fudj2R0DUyCTGxpzNUUewVWMedWkFlUAuOF7SY3skYBFSCvPmn9EABeMKoWQH3d2ujzvzPL/6oitePqw"
    "Y06L9/f2lypcECD2ygWqWRJjxIUhh/KFoGfZGdbcZRf88ivHlR8/aYkZ5CskOAcjML7vBk4AJEzWZ6tUIs6yBJ0TqvcrQvU6AqvS"
    "mnEi8PHAjHQeS4hBORzGoQxeZQ74bBrjYG5JivlHx+SyC/ivVn3sov/Ts+REs+KUAsZdBV5QQO94djgRgGFD8oqtvKIdaKgEganJ"
    "S7/x3ftvWMueO6RVU7ZP4LO3QsZJob+k2tJpnh3Dejb0IUAgleLZStZr3Z+CGmNA6BESrTqdfEXipetu+/49A73DvogjLJSHA2G7"
    "EppWnxqPFw3GBs6oglYJuRaG+dKI29mdlg/+ZP3Is08+cfdfn2VuMTTOpJpdkY/AGEeI4bJqt1IocAqAWfGYGDGJxpgcKedlO7EQ"
    "s3V+RCAGxk65rPG9X2995u57vv2zbM+CbpUfyrg8UEFBlCWy2VqVCJjEgGpAYRhS2F7oSQqK2YxzxHHz8aXzb33HKr3+w2vPiGTK"
    "HmOMzc4lcoTk+CzhGlCmFtqE2dQGBWNa4McZ+V6FGsEkMAvgGAe5ZWKrv9SYK3Ztv/fCU/7qzSVrFrDhwZ2OF1IgbC+ErteKI+N1"
    "whoDagopZDKyYNihGB4NirbvZwd22ItPWsSXnfBfn/vkIdmHvnC8Vc7bYILPCgRSMNDvBolUgxgg6MCM+wkRSEMsznJq1ItCmXws"
    "YpxRuAA5RcWOOiXudJ7mPLr8I1c8fdjHFvHBbLZSdAqeli/6BcMOkc3WHpqMt/qktXZSIZeTRd0JRFjxpV9xC4NZe+7iTjrx7Osf"
    "v2y196uVC4yg6ICJfTKBgREhU6LWdAqz8QMEaEimxYCdDVqI7ZswjIO8CrHuRZHwuIvMpz59/o2PdHQ2qKAy4oTekCdC8ouaHSJn"
    "1q/+HvAmKV8zBQnDkLqbC7xSxXcqRccQrts7MGjf+N277r/l0+KV9pQgNxyLJafXhguEyJVUe6yR5RmFVVSmv4MBCs0JDJWHZTtV"
    "E/9pr2cMkAEhkhA4+crk69998OF7N7+0tRhNhF5hOOf4ZcfT3VyAETMEeqesDU7FgCoImYzMW1agudL3pOPnRgecQ+cngjv//vHM"
    "W3946ge3fNZ6j8AZ0cwsYJCwPaQ8Q0lThG51H5nuFsFI+GGcSc+1qQlsZsAIIBUwdsrXG3e8lH/5B//j8vt2LVzaIsu5rO2T52lu"
    "GOTzRghkpi2MTlW32cOCMX+g5Yu+7xS8gR199tKVPTj7M+s2dYs/3nflKZFc0WUzmgIDKQWTZQOKJeNskKDPoJFANM6GaDSwSOoa"
    "mJq+XwFyi8ROOC+Vl4v7H/jcims3LD7pMGR37rD32L0TAFmJiZXhCTIZgAlPYFH1B2HVH5AvnZI31JerLPrEoVj4sW888x+OGHn0"
    "7GNMu+oUp1vW6oL3lsLWxhQbIAgwNkV9nlXtP5XSMk7Obwbx6coOY8ortvhjMe+Qs8LHj111zW8OXXUoCrn+imQVd5Ld1z8cqddx"
    "SgAmg1BlwnAk1N0w8KXjOf6o6+TzTkdXVJ76xVsfveaT8umjevSw5BLjUyhGABMIMVSi9lgjH66Fw1OoRQSgMUlD5WHZrrjEVM8V"
    "GQf5DrHWHlOtuiTyLxdce9tDcR1+4I84TnnU9UoVX3dzAaLRYJLd76X8dADULqxrvTJvOYFwgsAve97oyLCTNENvw6YtpTvv+fGP"
    "1p2lv5aOCfiSpnKKjCFE2aHGIEKBwXxfERN7DUgkmPBkg1COU5ItVfuf1BsDZEgwTIFTrkq9dfc/P3HPM4+9ONLUqvve6IjjScfX"
    "3DDIW1aA3qmd3mwBqAehunVkMrJguYFwR4OACt5wLuscPr9ZfvumB3f1bX3hnhs+E9kRSF5N9yYjAFIhLD4YyGhDnOdUfQ42Pppg"
    "VoyPiEpgkNT1qeyfARS4YCdfku77I22651tf+N57hy9rVyP9fRPtPjO909sfAOpBqAKRzY7FB0VfuhV3cLC3sujEHjp17c0bDk9s"
    "//Ela6z8qDO1U2QE9JVkS2OKZwANE62FAGhIJNmAnfWbQGIv+2djwc6Ks5PFyPLhh05ddf2Li9YswuDuXbZ0Sp4Ii35Rd4Kxx2ET"
    "ynQzyWzfEap1JjE8HJZcN/DDii992y305eyFH52LJadd/5vzP1J8/PSlpjvqTHSKBDA+Fg80pDHM6qsrdWo2pdhgZShoJ64m2D/j"
    "IK+k2KHHRoMj/gL/tPpTNz5xyBEt5BQzFek7ri8dz/A8H8OR+meB2HuEAwNg8s4gMWKGwgkCXw37dinrhvaoE4vCv/Cq7/30m6fT"
    "vyxo11TFq3eKjHFIlBxqphg8jfsBYcwNMADEQNxXSUNVKiVqJRagZv+MAYFHSLcbas2l8Rcv/e7dP6kURhyQ544OFVy/7HnCCYIR"
    "czzYmeS/ZpbZMmCiP0DVH2gj0g/I80qjGacppvu//O3Gkcce/8d7151tvhUxOUK1J4xjkBSSKXJSWskYzyli4IxRbfuzYmKElQKd"
    "As0ct38GKEUkOGenXpHe+sibT93zyJ1PDc7ptILyUM4OqOAJdzQoWG693U9Idz8sAGog1I4S2awsGE4g8kW/5ARefmSHfeThjeqy"
    "y+7aFuY23PvNtZE+26/PHBmBOPpKsjmdYgNjClI1ARJIJNmAPxSk6+2fMZBvg338y6lsX+q9H1121m1bjlzRRdmBATt0Sp4IUbX7"
    "aoo7K6f3QQCoKV8bSCKXkyXdDYR0vNAref25/soRJ8zFytNueOmEjr6HLlxlFfM2Y4IT1fxAtqTak2mem/j4B2hMscFyLmgnVrV/"
    "LkBOQbFlpycqzSfbj5y46pu/W7L6EAz176hI33b9sOKX3MEAw8P1dr9Pp/dhAFAPhMSIGepuLvDLjidLo25xKGfPX9JMx53z7V9e"
    "vMr7p9ULdb9QdYrgCFGwqQUxcgUklAInRZxYiHREleyCbCMegnEGt0xs7pGRcPl/0n972n9c91j3IXFVLGZsuzTq+mrYF04wluTM"
    "HOl92ADUBqjzCRmZN4xQc8PAJ8/z7BGHBaFTtEvu1eu+/+CNZ4oX5zRpyvEBwZQKlaGPkDQiul8OJemkIJhu+5rjCxloEXBJ0ifE"
    "04JOvjL56o0/fOCBXVu2V6Ka73qjw05AnqeNSL9guUFdkrNfdv9BAagHosqCbDYsGE6g5Yt+0Sl4pdxup6tZBPc/uH7w+fVP3vft"
    "s6ytQnAmFQAI9NmqMZlgGaUgZEhaQ4IP+INBqvo4gylSjJ16edP2p3e/eN/31/28r2d+KsyPDNklJ/BELdiZaPfAASj/QQCYImky"
    "5XjSxCpurq+3csSyTvrif75jS8p/60dXnRYdKHmMawiRKar2RIrlGKs++k8lWbaUk20QCm5JiVVfSA+Xenb9+ILTb31jyfFzkOvr"
    "r4RexRPS8Uq6GyCXq8/wZnwN7mABMBkEBfROKKKEbsUbGthVOXzFHCw95abnTjss+w/nrrDKBTtE2VatvIFVLAGPaSxMmii6Jdlm"
    "lwIcsabB6TnTe2zFyd96ZsHKDhrODpal57p+eaSuuLFXevvvAkBt4CmLKD55HlWKbnFkxO6a0yBPvvA7j135ce+pj84XwVBFRGxB"
    "IhnlBSMmypb0URqhho4FerjyYnP9uVfc9khTgwikXXCoMuT6VJhVcePfA4CaTFlEKblF1xvNOlHNd7e+11v+mzvuf2Dd2dqrzQ0G"
    "theCxrY0H040i2EvGzRYUYudfnXqjb9/4rH7Xn76zUIiLr1SLusUnYInRkaD2RQ3DkQ+DACmLaLwQAXSrbj5kQH78LkNwW1/+9ju"
    "7ZvW/+CGM9ju/qJqb2pRw+2t4VCxz29ffVEs+6qz4YfrLrlv++IlqTCfzdi14kbV7vdd3DgQ+TAZUDvWFVFy40lTf9/7lSOP6aHT"
    "Trlu45LEtrsuOD6q2Wk2Os+Sg0ednoiaywd/eObRV7505JoO9O/or0jf2e/ixoHIB3qTe5r+6l+s1pK2YYSWMIxY2orEU1asoSny"
    "7ttvyndfW39VrKkNja7ys3Y+cdQn196aSnUy3xl1nUrR8SuBq7kFvxD1fWQy9SnuB7b7evmwGFCTKYsomit9v5J3nUrBsSsjdlOi"
    "Lfza5df+XbPhJ3hadl3z17fcJsvS437JdipFxy+PeNreSc6H4vQmy4fNgPp+J7506Vq6jOi61JjR0jnP2PXKhuA737t1XiRiicu/"
    "evG2ucuPN3IDQx4PSoHmyuqTnInv+tbi/P9nAADGQegRaHNF2o9pYehqKmqJdKJV7333pQAAdS9YYeQL2ZBrZqg5fpg3KiGylgR2"
    "HtTVr5/owZBJP7EBBzpE7Sc2ALFYR5QDDahksgooUEHTJIYNCRjq30L52iQPpjDsBUQPR4fPx39gBQCcEzgnZDL1ju6gK1+b4MGU"
    "qX5wVd/qZXIp60Pd7/c1wYMpbNLnqZSvyVQrftCUB4B/BefReEff72ycAAAAAElFTkSuQmCCiVBORw0KGgoAAAANSUhEUgAAAIAA"
    "AACACAYAAADDPmHLAAA820lEQVR4nO29d5xdVdU+/qy99zm3TG/pyWRmUoDQi1gAuyKIDfEVC4pdUV/bq6++CmJ7BURBRWy8igrS"
    "sQQERClSpNcECCSZJJM69fZzzi7r98e5d3JnMpNMJjMhfH88n8+de+65Z+45Z6+113r22muvA7yIF/EiXsSLeBEv4kW8iBfxIl7E"
    "i3gRL+L/L6Dn+wKmGHvzfngvnmvasK8pQPX1MPa965ssRt/LPqM8z3cD787598kGHIXdvcaKYjxv9/N8KMBEz7mz455vxR0POxPk"
    "uN+dddZZBABnn3027+I3phx7syEnKtCJXNMLUQHGO6Za6KPva9qVQUz3CRDf1FgCq+wXYxxHY7zEqPfR28/XS1Rdh6z6vMtr+9jH"
    "PiaZGcz8Sq31W5gZt912mxzVRtMKNc2/vzPBVxMjsZPvRx9b/bu8/X/bp+iSJ4p1lY1KL62+h0qvruxzVd8N+/xEIiGIiJn5w0qp"
    "BUT0l6uuump0r6++1ynHdGnYzgRfjbEEX0Z71bal4ffZ5V3OEYTg4e3nC5VrqMZmWd4nq74bVhgHAMcffzzddNNNuq+vb05LS8vd"
    "ABqjKHpVIpF45KyzzlJnn322w9juYkoxHRZgPH8+erv6Vd7XjljIluCCeH9FuBWBR9uF3cxMRMQAwMx7VQmqzztQ3gYQK0SbwYjP"
    "ACBmc1kxJNDD1loJIKyvr383gBkAoJT6AIBH5syZU+0KgZEcYUqVYKoVYFcCr94uf24nwBJmagEEsaDLQm5mpopgnasvH79d0BYA"
    "syMiwcx71woQbe/5DSO/YQAQIsvxccRExP0A0FZRhpm8atUqe+ONN9Z7nncqgAiAFkK8tbe399zW1tbNmzZtklWjgmrBT6kSTGWj"
    "TaS3A8PkqB1AJDDTEVz8qgg8FjYTsyPmWkJdLGhwloBaAOXP+xC2K0QeoHomEowcQJTn7d9lWIgWfsXxR3s3XPHHvsFs7l0NtbW/"
    "BzCIWKhtWusv+b5/wXnnnVezfPny8I477qjmDzzO9uSveyp+BGMLf3SvBwAR9/iy4I0RYKYmZnKuTlQEzrWO2MXfoaYG7ByBXdka"
    "pJHifPn30kAKQCkFsCOgBNAYPnkqwY6AVHyeVCneVyrGb1TLQDF2D+XrIFFiKklXk07TwoWt9NSqVTrb05MDoCNj/uZJ+UoA2XIb"
    "pQCs+u1vf3vM6aefHgCQF154obruuuvsHXfcwRhJJoEpUIKpUIDRvzGGb6/0+tnbe7wxsgmAtTWS2RHXpGMFSCYF2BG7hEglXWwF"
    "rC+SAIAkmIsUcIKQIgb7lESIoGwNEoiPqrxNOYLtGyGAJKU4YCZQxAiAJIVMlGYgQCgEIwi4qbGRkqkUVj50awAg97LXv77ur1f9"
    "8dj6mvoPeJ53LABd1VYMwHfOPWiMuWTdunU3LFmyJAsAp5xyit/U1MS//OUvbdWx1e+Twp4qwHisfoxxb1n4WssmbiTnjHA1aeFs"
    "JMFp4qQRSZcQnDACnCTfUyJgn3xnBXsq/l3PEaIEfM8Rh2UX4CeGTx5h+l1DxZz7w3tCkBYc+pXvNUMLpog4kQB6Vt6RBxB86/vn"
    "z//46e87oaWl5R1SyoPL/5zDjm3IAGoQ87OnAFyRyWSuamxsXFP+XmJk8AjYAyXYk8Yaz+wDI4Ig8wSgBdriXt/g6oSrMYJdWrBL"
    "imTCk5wwgp0vnJLSd0rA94idFZ5KC/YcgRWxksILHcH3Y5cAxAoBH8yOPIwkZtMJZke6cj4yjKiqIaQbNtOZvkF9/W/POeCoww45"
    "uaYm/Qoimi2EiAAUy4dIjA2LWKgpxPas1zl3l3Pud+95z3tuufrqq8fq/ZO698mOAsYS/hi9f54ALKHFiCbTIIZ7vQmVS0iZciRs"
    "LSSbhPRTdeRZIZ1HkpUUnhKCpRDspGCVJF8xsS+JWRIpR4AHVRkBSEcwAEsmv3pINg2ImIkssa8AsvHog3zBgIY2gn2ybKxlD0Cq"
    "1grJrkVIsYCIGoUQFrHJH92Go1Fh+gax328QQswXQjQccMABlfZ1Vcdh1PaEMRkLsDPCN1L4baGEtaKJG8naSLp0UqasL23Ck+wr"
    "6VRa+kpIZ4X0UgnpJElPJoUUkFApkoalSwgBTpAUVkAJUvDAFkIrBVUZ+yuALDEzExTiZpsOlH+biJglU+U8hiyTEOxZxwYaMI6t"
    "c87zE/zcHXfloTdGF//yp/ufcPzrT5w9q/V1nufNQeyxAuwoA4e416cBbHbOLbfW/sH3/XvK33vY7gL22BLsrgLsiu2XTdp24TfY"
    "WumcEa4tKVOmSVovUE4pmXB1wqUSShlPqRRJKXyZqG/yEp6SUnjCeizZekL6SghLgqVPkI6kEOQiCCgJFkzKAFByWOhWCB7XsO4p"
    "LCCHo44WgIRRFuSIiZiJHMM5tgAoYufYuETCJ3LGPbXm2Xz2kZXFj33m/TM/9eFTjlu8pOMt6VSy0zloIUaQQM9auyEo5q9Y8dQz"
    "1xx99NGrAMi2Aw5IHd3Z6ZYvX24wUgH2SAl2RwEmIvyY7LUZMezvXVq41lAljS+dXyedFMqTSeWEr2rSKeFIKaESXk26Vj29YrVG"
    "EUBTSsFPKkhPQPoifhckhSegJCBIKEhAMsWntZBlqVtmmrACOFcOzIiJtYMFMMLF2FjxiNgYCwh2gIUNLcMZBxMynLEItYMvHWzo"
    "0L06gA71AUct8f/9z2t+UVebOgBA0TlHQghfG7PlJ7/47Zu/+OmPrgOQPvTQY3xrM+aJLVs0epUDNldCxJX3PVKCiXKACQp/HqEt"
    "FLBWNLg6YdNaslUyaVLSeUJ5IqmUgHKUVtL3FMmUSid9j7wa9fTDq8O/XHPOa5Z1Ltzf6LBUFgoxgyAE4EAMS9v5JeCYqcI8Rk5r"
    "7lqezjEckQcAiob98i4wdptWwsJww9+zEBzHARgshGBm5yBkqmfrwPr3feWC21bedsfgYyufW37MSw46GNuFWDPQP3j9Fz/90W3H"
    "nPie+etXP1N6bus2LYsBmqUVAy2O0D+PgZ7KLY8OEu02J5iI5k+q59u0lpxskQktlasTytNCeal6ZZO+Sum0sumEl65N+s4o+ezq"
    "rfqBGy54x5HLOl8HoFgCWis3wADRNEyCMEBpYACAyzm0VG5qd080ZgNWaSO7+BAHUINAL4DUc+s23f+SEz//+2MO60hcc8l3fun7"
    "qgWAsc6ZH138m//4xje+1z1zwXyRKwwYqa0pRYNGFj2bETkHpexUWoJdKcCugjw7F76SymmhPJVSXiqhbCLtJb2kZ5FUDY21fjG0"
    "YjBL4l9XnHnygV3zjvnjVjdjphRXzm3C0q3ACaYEA7gpzVlgAkshSMANHSb4wrSSpRuHcEYRbr7TU5+HSBBOJiBbFe6bmcOtj2x2"
    "H3jvESKzpXfgkc5XvP9n9y//6QcPXNLxQQB2a9/AjbPaWr7SddTJ6exAXxipISPzzgTKGhEZIwpFl5W+hcpNmRLsrHF3T/hVZj/l"
    "N6mElspG8DxZ77lksyf8ej/pJT2hfK+pqSFVKDkVcdJ79Ppvn3Zg17xXXrrRtf0rL+bek8WJnRJ3QyMvJDyQkDSFL8FCeEnIBiUe"
    "JilnlwgHtXm43/OFFBBCkJBT+QJBCQdzWA1uvf05vO7hzWLBr+52bbPamo/ovvt3n73mxgfv1dr2AaBbbrv/Rr95USqRFp6s9zxP"
    "N3i2VqikJ5UzSrmatKi3kYRtiNscs6uTZDBKPuPNzexUyON9N8YwD2KE8G2trAjfGqlsrVC+aVQqlVAyIT2han3hJVRta1Nyy9YC"
    "z5k3O/33i790+oyWxqUXb3CzniiImSkHxymI42vx86VNaN4g8S6dh4OYuswlZrDngxYB53kKx1pGmzD43R05fN1ZeDyV2cgMp9IQ"
    "syVurR/Ag5c/hq/AgQMLMb/BDX7mVWJTLpt73DJ1+kp4Ha943xlNM5pIh7nIFgJtYbUM8sa4UOt8caQlUEUDKV2VJRhtBSZkCcZq"
    "2Gotqhyz+8KXjUomPc96CV+kan1Kpr2GlpZU9/oBd+ThB7fc+asvf7y1pXG/89a4BU8WxMwUx9MsbIC7snjLLMLDIsIW4YOYp4YD"
    "MIOVD5IOPc0SmZCxv2Z0NCdAtRJPywSAKToXACYJQoTiYTW4/eZVeCsDxA6UEuBNWdH0g7+7hfBrlrQ21Tbc+8S6fww8sU7PmN2W"
    "Ipn2Einfd770LKU9TyaVrU2rhE57zi9bAjNLwTYItEQSmFc131I99wJgF5ZgVy5grNi+iNl+2eePJ3yq8WRtykv6SY9k2mttaE49"
    "syFj3/KmV83587kf+4iorV/8v8+59u5INCUZ7Cq/reHyAnP+0osDOzzcIDzQVImEAFY+0CDwoCPMExINnoIIgP1neXhATCXbcGCZ"
    "AHWkcPMjqzGzP8T+MGAQyAHkEbi/JGouulPstzmL6I1HdR78lQu/fsi9D6+PWma0pkk1eAlZ48u6GmX8lF8nk8rVSZnQFCtBOpL1"
    "JlBwLo65xO5gtOB3acnGS8kaz/+Xe34oYYystzXjCN/zpC89IWt8Sqa91pkzUg8916M/9B9vXHjZN077eNZPLTh3jWvfbERDlfCH"
    "z8UR+OEc3py2eM4P0a2SIPAOU6G7D4IwAexMhSfzwJEEwDggZ3FURwJrOUSeJAT2dNTBYPJAUqN/WRL337kGb+E4cLt9nAiQT0C2"
    "hJqf3+mWrs8n2r//2ZM+fM5/nX7gww+tDVtmNqX8VNoT0vOln/IM1Xi1IuG5utZYCRJaunRSNrg6AVMnY04wjzDMzUZ32rEVYzwX"
    "UH1gdXiXMNNRhfC5GivSyRZprSet2i5856c8WZP0hPK81pbm1EP/XhV+90sfWnbRl0/5SA/7M85b47oyVtQmdhQ+QCBYcKjQeO1W"
    "vHxpAn+GAJj32C87lQASwLMNAjp0OFAbwFiwATpqJGrqFR5XU+MGWPqg/eqx/B8rsTRr0A4Lh1Ht7QAoAQ6MSFz8L3St2qqav/zB"
    "137g0h9+6eX33/1c0NjQkvQTSZ+k58uahG+TtapWsOfqamXS1CuX8KVN+arBxa64bAlGy60a47qAsRp3lCLME5ipBbSWDbY8o5ds"
    "kUbF43y/ptLzU16yJul5Iuk3tjYmH3psffjzH33pJV87/Q3ve6YgZ16wDosCJ1JqLOFvPzNxCH46wGsLGn11Bo97aRC7PRAMA1IC"
    "TRIPRA6LfYWkc3BgsC9BBeDgOT4eYt5DZWM44UMkLdbPNXj6oY14M8fB2zF/kwGSBLCD9+t73eL7u0XraW992cnX//7s1z70aLdO"
    "1jUlEskGT6iEJz3ybUJ5dTKpbK1QSSNVKuFLm9aywdZKGFO2BLMr6enVbnw0CON8Wa05Zb/STkCV8J2WzjSr4XF+VO8pUadkrfJk"
    "TdLzEnV+bWNr8rFHN+g/XvTlYz/+jmPe81BOzLi4B52akVAcB3h20owEB9YS6T9vxWv3T+AGOBiarFgYIAFhSghmCzybZ7zElSNM"
    "AEg7oOBwZEcSW6RGr4x5x6SUjQEiARxYh+U3rcQRJUYrHBxo/PtlAIIAASGvfth13fYM2t72mkPedtvlZx+/4qlNJplO++naOl+o"
    "Oi92B57ny0Zla4Wyvied36RsOikbXD3B2jjvInYHY1mDEe5WjN4xxjYBgUSLEU3M5Gq0dKlmlUxombBKeqpRuRSU8MiXqPPSiTo/"
    "maxLPPbgmvCWP3z7De9+40tOuXMATb/Z4BaD4UmOo2K7bEmCQABeE+LYNXmYBsZ9avJWwHlJoEbgiZREwgBdUTx5JIhAxoCFxAxP"
    "YkazwkMyzjHZ7fOwA6sEqJbxdG0JG5/YihN4gsGlihIoKWj5CnTesMI1v+ro/U984Prvn7xi1RZrRdJLNzb5ktJK1qY8JRLKNynl"
    "tFAplxBstXROywZrBbSW5VT68ZRgGKNJYPX+KtLnCM4Ja2uks0nJyYRwXq2yMqVU0vNSyVolE0qla+t8K5S34tkN+t9/O//k17/s"
    "wBP+ug0tV27FIo8ECd7NVnWAFZA39OHEpT5u4QiRkMPtNWFUTHqzwIMFhwM9CckjSSUTATmLIxYm8ZgLwbyTHrvTczngiCb85a9P"
    "4lUaSJctyYR+q3JTCQn88xmx8KqH0XrksoXHPXXL+e/vHYwoymuZamhMSEopmZCeStUrT6WU84RyCV+6dFIy1wlwI8XDw9nVQ0OM"
    "8b6DCxh18GjSF2fxJLxAOZWWTiaUE6ycl/TStS1+ZJTsHWR6YvmF7z764K7XXLkFM27qx8JK0tZudykBQgjebHDYo4OonyXxD5Xa"
    "TfPMYOmBOMTgLImNBYejDI9sBAJIW6DAOHRuErkEsE7tphtgB1ZpUKuH+wt9CFYP4jhMMrTMABISfF835l36bzd7v4Vzj37yz9/5"
    "QG1dY2IgW6C6+oakRdKTSU95MqE8SSrp10kuK0FDJaF2+8hg9JB+GKN37jhUMGXT79KCrZbJRk86Uys9SUolPaWStbKhtsXPFgJR"
    "DFk+ev23Tztw8bzjfrsRbXcMYX4intCZPCjmC38fwEkdAndxhCxJECauT6wSQK3AI0RohsAcrcFU3cMJZC2cr1BrgIWtPh4QcY7f"
    "hM8BAZBBdEQtbr5xJd5ggQRGKdrugAFKSPDjm8WsX9xlZ8+b2XrEbX/4xkcXz11Qs74v41pamxKOlLJJX3mqUTojZdL3JLuksDYp"
    "G2ydiBfVWKpaZbWDix/LBVQN+bRAJWW7xgiXaJTsjPBrpVTCV0qSbGhsTmzcNsitja3Jx5af+8n2eTOP+Nl6N/P+HOamdk32JgKB"
    "EDxAWHLbAOYvkLhJJWOSONGGdBqYJfFwETisnF465v86AFmHo7qSeMoF0KCdBsqqT8JeCjQ7iTvXb4TXk8XRHMVBnwne47jXnhTg"
    "Z3pl24/+6eY11Nfvd+vvz/z06448vOXJVZtMa9vMhBK+tMJXfg0pdr5IJrRErSNmW2UFot2OA8SaY0w5nSspnfVlKunImVrpWSFZ"
    "kmxsmp1Y+Uy3fu3RBzfffdW3z2htadz/vLWYv6JYDu1OVUydALa7HyKuDv22KAyVGIdFNjb5O5yCILQBQocDWhW4VuLpckxgVwGo"
    "MUO+e3K71XDYHjo+71Z0aJHquOan/3nGJ087ef7jdz8ZtrY1JVmS9GSD9JWUzlfSJXzJtbXUYGslnKuspxxzRDCOZrQjHkoAzhmB"
    "WkectIKtkn5NUjmZlE2tM/wnH1wRffjUt8++8oIvnsHp2qX/+5xr7w7RPEZ0b89AoMmEiKtDv8ZhnpJoNGb8nukcnK/glYD9Jhwa"
    "3knIdxJ3Os4p4tDxYBF1P74NC/vCZPvPvnnap8466z+XPHb3I6WmWa0J56RwKiXBSWKXEM5GMl5NxfE6jJgL7ICxiEHc+52jJufK"
    "q3UcpZJJcp4SzB61zp/jPf3Pu0r/9eWPLvz1tz7yxYxKdZy7etzQ7lRh90PEo0K/AEA7VxuyDOR4gqHhCYR8pwoMkCJwNkDtRbej"
    "Y8OgP/ubnz/5sz++6DuHPH3L8kLLjGbfU0o4JWWqLHhmR03M8Qqs7cPC4XsFxh4FoLIc2zlHFeYPdpRwnmib1eA/edPv8hdd+pOD"
    "z/3qB7/Y4xIzz1vrOscN7U4Vdj9EvEPoN7KxqR/3FATSZrdCwxMK+U4VKkoQGKR+dqdbvGqrbPnMB958xvKb/3Lcitv+kGtoafR8"
    "pwT7WjKniGtraXhR7Ug3MIyx4wCV5VtoiPelHLHzhVeTlE/ddm1u+Y13vvxTp534qWeLsu2CbnQGRiR9hnUMBsNN14sIjBD2mQCv"
    "DjW21Rk87sXDQjP6WHZwQgBNhAdChy6lkHAGhhlupy8H60lwAThwro8H2cVcYozrMeSBUgbr2h1WPrwRJ8DC0vYMnWl5McBKwDIL"
    "ecm9ruvBdaL5xDe8/PR/P/DICU/ddm2+rjYtEq6BkIrXU6Kymto5GqOIBo2RFDpPABoo59yzM4K5gerrakWm+7no/oceet1Rhx/+"
    "+dv60XrdIGaRH5dB0ICcnq6/HQwADgjTqL10E9724bnu5hUQB3s1UFxZJlE+UEgIXYBr9bA2a9xHUr4gJKB2NTvCgFAAssa9Zp4Q"
    "D64IMZRoQKONhkPHw8cJBezvuRuvvA+vKUkxAwbxGoVpXZoSa4KQgGMhrnwMS7ZmXO+JRx76maeeeTax/9LFV7Yf8kqV7E+IkCMa"
    "5gHj3PJoBRhThnMb68Vzzz4Q3HrDTS896tDDPx8Bq/oEnj2mEb5HcHasf5oulK9QpuFafLG13eFyR2iEHC4jUkmHUfU12NwMZCzE"
    "/RpQqSpfLgAOAN8ClET14q64gVO+EGmg9JIULtvm0CmT0MPuLQ7vCBEi7PDFc4/PQcvBIZYLgpvKEcBEwAzqd8INahT3W7LoQ6vX"
    "bvC7li39TVfHEd6WvhwAoBlx9msVKnEUHsMCxP25GYCprLpNOEKx6BobW9sgQI+u1sUnHjamtYYotHun0lQ1iJhDI9S1C2THK+eo"
    "x6//p9lfjHLTTGAm55MURxvtMvFeUf5/cKidOuoguW5eksNb73KLpXKWeXsfJyImjw8nByOZt2LEd8xWC/ny16lnntsUzWt8KNTJ"
    "JPda5r3bFA6QHlAacNg2mOamY9O2vjY9C8Wi42S559cDXOBqbjeCNE9oXUAmk3Uz249O/89///ed11132bFds2pfeld3uHBdNuWl"
    "lYWdbOB8kiAwNHzMe7a47rBTxe9ufdCeZlxih8lCBsCOd1j3QWBYEAxFNx+QdP0P/Dv5HqIQo1XZORczwzES04kEFhzB5624PPeq"
    "/tWpw5wsYa92/niGE1YTZE2Eg97V+JyGXvmJT3z+l02dRyTDSE8ogWZcBRgA0FBebdsfCG5rqqebb78v/MzXzr34kgu+MeM3H0oX"
    "T74ot18YsZcQ05C4vwtIlJApitlFATenRaxYv00vkxQ6V91TK39GXZwgOOtqhJIIfcWR48gJKjnmsdeXVMeyicDOSVFXT5sWzvOy"
    "d/XqhVZFrszP9p4GCICZ2ArGO8+a8VRLuxr80Y8vvejaa6/Kzz/iZV5h60AAIkYWIFVhJbIyN1FRDhptsrbfanm1S2XJdZTtc0uP"
    "OC7xfxeeu/WXv//bJe0tIjr7rem1kRPEQLkkxt57ERglm/Dv7dazlszHWoZHsQknsatXWdCCGcP/E++b0P8ScYLaZqvuvpW63hSp"
    "iWGJAbk37x9EFAUkj31/Q3f7wanoplvuvewL//nBZ5cdd3w61z9kqpfKj/L/o/VotPDX8ejSZ0QlDkXIA9s2mqWvO7nm46ed8ujt"
    "9z559YmHeKUPvlytz0eKJO3ZnM9k4EBYud4uXNwu15UnB/ZCD2QCCPO6qHvzM3oeW29XwaUpBwlmXRB0wKuTm152amPuyZXrbnnT"
    "G99y29LjTqnd1jeokwCKKIJIxPWJRi6ZH7E9lgUgbEa5vFmGqaAcSvGPUEpwdkufPuCV76x59cvfdeOz3Zvv+eqb00PHLqLe50MJ"
    "JAye2oKOzg7X76swZExwkeceQRCJkDu7vA2bn9Gde9v5kQCbQFBrl8i85Wttvb0DQytefcJpV7W//BXpTK5gEAkORcgUSBfXKaK4"
    "QwvBVbUKt99N+b36LhwgGUKwEIKJ8kwicCSUC7PakSm6bFiwC47YL/H20752eaFQWHPR+2s2zWvifMnI2DbvBTBICGj0Z017oBya"
    "6+V6ho84JWPazspghWQN+mfPtMW+jboLwkxFwuqEQARYQ+TXivCd35yxLnLRtk9+4ce/oZoEEwkWxZKLhHEUSkdUYsoLrpSrK9co"
    "3GHBiBi9I0asAINEXDEjpUCwkMZpIZ3JFUxNTYLXbt5Q+s9vX/qbdMJmfvzedLev2Fg3MmAynRBwXDSJxIM9aF08n1c7yOmWBIMV"
    "WmfK1YNrwpqwiBameH349J62cnKws8wnfK5xbcNsVbrg4uWXXnvjDX2zZs6RQaGkhXSWorwrCeVAxEIU3SCVLQBktfCHMZYLiE3F"
    "ZgBSOoCYCsqJcMiSiFykC05ItgPFnO5Y1Kku+fkfen5x1e1/PHCuLH3thOSawAqiPcwB2Q2wg8ATG+zCpQtkd5zCM91MXGBeF63r"
    "XRXNIeNT9Zrw6QQJsC4KOvpdtd1Ljq0p/u2fj/zpK1/+35UHH7osOZjdFgnLNqetIxk5EqET0rcxN6dq8z+6s48buGDAdwCQUXkb"
    "uwHpgsi3pK3VBePIWDc00Bcd+NKDkp84/ev33/HAszf/x9F+8ZQj5YbcXuQDEhZP93DH4kVimycDzdMbkSYSGh2L1Lqep3UnmPdK"
    "YSoSzLooqPOl/rZXfag5s/LZnntOeNeXbz3w2IOTffn+yFi2kSk50gUbKN+KMLKUz3NGZBlKuSrzD4yyAtUcYNRB6xAvPASkLFjk"
    "BaPUx8I4E8mSFYE2FEQ2WxwKlx1zUPL4075847pNfY999x3p/iMXYCAfyWlXggoP2JY1C2XK2qY62cPsYU+z0MY9HStKpNzggvmc"
    "6+uxnSzMtNcoJgE2oaDGuSL3zrNmbBrM59e89UPfu6Zr2WyvmCtqE2kjSmylZUMychSEDlRgIukghIt7f89oBRj+PI4LqLx8B6Xc"
    "IBFLGVghPRuI0AmTt1qWrHXa2FzBaqt1c3MdTv7cDy8LomDTj9+b7mmrQym0008KBQwXtJ++fyM1d87BaiaFHeN2UwFmwEPLTLkm"
    "v0EnSzk7a7r9PxHgDEglSL/9zBnd7JnMZ7/+m99vzW4L/IRyoclp4chombGRKdog8i0FgRMF6TIiG5v+zf5YtQOGMZYLqBzogHWM"
    "rV6ZUOScKAaWgtCR9GyUt1bbwFpYnc8O6pb6BK98clX2az/602Uz6pH74anpNURsp392hNiRxOPrw479FlI3ppMHOIE5HVi39Wk9"
    "m2ySIKbd/7M14Nd/unHNjE4V/OJ3t13xh2uXb+qa1ywzg9nIOFgZRCYqsCEROREOWVEMrJS+3V5JZNj3j6kEYwSCRkMyfN8Ojwhk"
    "YIMhbaXHRls2wmljXGQzvf3RkkWz1Y8u+PWzv/vzvdcd3SGDz7420V3UksQ0uwKCw4qNon1xp9ziicBOUzyASGi0dyW6e56JOuKo"
    "0/RN/JIER0VBh725ZsNBr68t/vOelX874wvnPHTwoYv8gf6h0HDRyNBobYasUHkbaGtIelYIzw7SUDXzr37uwA48YHS602hNKY8I"
    "JMPzbEbmrSx6VsjIBlHWCtNvTSk0ItDGOmMGtw0EBx29f/IDHz/77vufWHvnx16VyJ10MDZnI0VSTI8SMEhIjrBlUHemG62ur5Wb"
    "poUHsCQvaXKdC22mt9t2gfS0jf9jxk80/zCv7w2faRlY3bPtkTeedubN+790cTLXnwktnBYBGV0MrPbYiGHTr1xG5hykdNgqGOjZ"
    "ZemYsQJB1Z/LmSg9w64gA2ISRUdB6IROmEgXrClFxnLBWC6Z/EA2XHxol//GD3/zT1v7Bp/+4am12/abxZnCNI4MBCwXtFf30EZu"
    "6JhNqzku/jWF52IHeGhq89aUtmmvmDFz3DT5fxJgGxHVtlLx7V9v25QPSj3v/NT5V8yZ3UimEEbO5LUNC0a6yERqyFDW2CDUVhR9"
    "S7TRgYhH1Q8avonRNwWMzwEq71V8QDL6fQuVt6LgWVFKmJIInVDGShtqEwptwqJxpYKW1mhPGvuR/7nkcqvD3p+9v2ZdY8qFkSWa"
    "pmAtG1Z4bINeuH87rY3VbIp5AEvM68C6rU+Fs2B8OS3+nwBnAaHIvP1/2takG5D96jl/vPzptWvzdWnBhXw2CtgYEWiTt1kjrTNB"
    "qC3JfitEyWaUslDKjTL9Y7mAYYzHAcYYNqwbDhFnZM4JUbIiMibQ1kQqb6UNjXQwFoEuDmajOW11WH7nnb3f/OXNly1oFsXvnZxa"
    "Yxw5niaGJsjhqU2ivXOh2KxEiaeWBzARLOZ3eWs3rzIL45zvqff/RGAbEh33wfruOcsSwW+uveean/7qijVLFrbJXGYoNGyMCfLG"
    "2NAI60wQ+VbIyMqiZzMy56CUw1bPlU0/ML7gR3CAMb/AmH6jx6E3YWM+kHOiUHQijGyorYlMv9WlyNhAG+tKZnAwFxy+tN37zrcv"
    "Wnn9bY8uf+0BXvDR47x1OS2mnBTG4RiNnj7b2TqLg/pauWVqeYAilYyKixbxwLY1pgs09fF/EuCoIOiA16U2HnVyff7eh1ff/qEz"
    "vvXvg45c5g/094WWjRGuYEQJRqiCFVHOkhq0ohjYjFC78vvAGL0fmFg2V7U28TAfkNJlKecqfCCIPKvNkDEuNBYlbaOMGdw2GBx0"
    "9KLkO04/+59PrOq594vHpzKvWSq2ZaeeD5CA4Xwkmh7bwnXz27Bm6uIB7OAUGppVt81YmRuy81hMrf+PZ/iIZiwRQyd9pbV347b+"
    "FSd88Dt/2f/gjkR+YCBkqyMblbQMYr+fyTkThJ4VvYElyjmIjEOv4J3UDRxXEXbGAaq3R/1oT0w0lLKiULCilDAiskZ4zkQ2MDKA"
    "MaEwzkQ6yGbDjq5Z6m2fPv/aTLaw5qfvq9nc2cq5eOZw6pSAANbs4ZF1YfuyDrGGmaYwHqAwp0Os3boimgHte4CduusmwGqiVAMF"
    "p5w9c32ow20f/vKv/5hqYMfO6NAUNLm8FRlt8jYw0jpDw35fue1+P2mxiyEfxugQO5kLGPNzlSJIhoovQIiiIxnZINJW2qLJmyEr"
    "g7wJuGjyQUGnlbXbBraFHz7z0ssSyg789L013UmPtXFEU8mjCYwVG0V7Zzs2KREypoYHEMFiQafq3vhMtJCZttcGngIwg+HYnfil"
    "lrV1bTL/7Qv/fPk/7vv3wIymJIqFfGgiY0qh0EZlYr+vrdnu9/N2u99fN8pSj+/3q7EzFzDWaKBqVNAT+xwhOCPztsIHgsi3wkFr"
    "W44PaKezgwNR5+xWuvZPN206//e3Xb1klgjOPCm5JrLE4KmxAgyQhMb6Pts1aw4XapLcz1DYcx4gSPpR2LUIfVtXmy6QxVTFNkmA"
    "dUnQy95b1935klTp2r/d/9fv/uDXTx+0ZI430J8JbVgyItBGlHJGWzZS5w0FgRNFP64bPNLvAyNNPzCO0Efc3SSuu+rHN8eVKqV0"
    "WVmwJIqOQm1FlLPalIwpZY0ItHHk9ODAtuCwQzr9L33p/Ef+fu/Km95+hF9879FqQ15PFR8gEjDIBWh5up/S82aI1Q7eHvIAdnAe"
    "6hrVOhUZZAfNAo4DQHuc/k2COSoKWvKKxJZj3t+UffSpDXe98xPfu/PAo/ZLDg0OBtKE2nLBKC5obUomiIwtBaETxcBm5WY7RtHo"
    "nQZ8xruOXd3IeFHCKrJRVoIKHyj22SD0rPCciQwb6fLGhEUjdMnkB/rDg47s9E/44HduWd2z7ZEz35oeeFkX9U2VEhAcR5yghzeY"
    "+fsvpDVTM1GnMKed1m5boVsQegnQno//K2ldLe0i+46z2rb0ZfLPve0j//un/ZfOVEEuG4alSJfCohEBmZwpWaGMFZ41VIxDvRCi"
    "TPp2GO9XMCHhAxOzAOP9WJVClOMDSlkhlCPZX54vKJq8DYwJIhOwMXlT0DoM9OzZdTj5cz+6Ml8s9vz0vTUbZzVwMZiSmUNiAuPJ"
    "DW5h1wLZI0nHIfs9+EEixoLFXvfm56J2OLHHCaDxDB+Rl4Y++awZ3ZGIBj7+9V9flrV5LYhNFJYiC6eli7aP97U1VAqclMH28T6G"
    "x/s7M/lT5gLG+uFqPhAPDZVyI+cLfCuMtdJpbYK8kdrpYj4X1dcTP7N6bf6/zr32soaUy1347vQaJdi4PVxaHPMAg3W9rrO93ebS"
    "STvIrGjSPICJhBfozi5s3fzM1Ph/BrMzzMd/pnl183wVXPirW6+47m93bJ3X2kC54lDZ7xeMLsFoO2CkzhsRRvF4X+Zt7Pd3EP6u"
    "XMC42EMOMLxth0mhlC4jVDx1HA5aofNx4CIQ2gTaWAQ6258JD2hvkz//7dXdv7runmsPa5fB51+f6C6Y+Gnqk7imMogENIaKbtba"
    "LCVmt6g1TP4keUA8/19XL3vqPGsz/dFCFyeATtr/kwDrgqTD31a7fv/X1JRuvP3xv335mxc/eej+HX5+YDCwkTGWC8a4rNFmyASR"
    "Z0tB6KhQdFnKleP8CVuV4DEe458wdudmdhYfKG9vjn2TyDgpC1YUAxuEns3knInkgJUub2xYMFaXzODW/vDQwxYlPvaZc+7718Or"
    "7zj92ET+HYeLjXuaThbzgBTdv8HM26/drXWT77EM9jBzgViz5cmo2YVeGmQmf13lnL6FR/m9r/tk8+CqtZsfOvHj3/37gYcv9gtD"
    "vUFIkTahMTIUOrJshOfi2EopYYQoxKSv368If4/8fjV2V5t3xQfigEQ5i0gIz5LstxRqK60zeRsYkSEjEegAgckPDoQHHj7ff8uH"
    "v/vXjdsGnjz3lJreQ+ZisLBHpJAYBDy5wS1cvFCtFzCT5AFMAGN+l+re/Gy4AE5OevxPIo7x189G4Z1nzdiYKRTWnXzGBVctnNso"
    "TSkThSbSNl80kos6nuRhE0TakoysEEWXkdJVTfLsytTv1jXuiQsYva+8v5xFVJ4vGOYD2hphnTEqNMUAxupAR2EpisLIpOqlO+UL"
    "F18RReG2n7yvdkNzDQehFZOdOSTJGms2u86OhTaT8nWOeRKJoixIqMB2LZabNz3lunZ8bvNEryae4ZM+zDu+PnOtSrns5797+eXd"
    "2zaU0gm4QjajLWfjxBquTPJkrQgjKwpFlxE5B8+zU+n3qzFZfzaOC6jOH6jwgZwTxXLCQpSz2g4YUYqMDK22XDKlQiFsa/b5kUef"
    "GPzGRX+9fE4j8uecnFzr4ooduz2Q4zIPGCy6OT0l8ma0qLW7v2Ak9v81dWJTU1rrTF/UwUKDeYe1lLsEAWxC0Cs/Wr925hKv9Ksr"
    "777mN1fduGHx3BkimxkKHTlt80IblzVRrmApzDgKI0ui6LKybPq3jkjsnNKFL1O1nn20Jjpgc0xYlLJZuTnmA5E2IyaNwoKRJtS5"
    "LYPR/kvnqXN/cOmqK296YPlx+3mlT77G685rOSlSSHAcuqR8cJ2dvd8CrHa7LzcGFGbOF2u2rjQNpiTrmHY//k8yTuc++E3pniNO"
    "aijcfv/Tt33sC+c+eOhBHf7Q4LZAGtYmLBrp8iYqxH4/jBJGFH0rCoXRwZ7q3j96+AdMovcDe6YA4528cnFx4ZBewRDCCeFZKign"
    "PGuEMlbkS9YEZEph0TgT6cFtW8NDjupKvPuM79/5wMr193z2tanMm5Zhy+RIYbzod8VGu3DJfLlexM9i3g1jwgQG5nd63VueLS1g"
    "p3Z7/F8hfXOWqYETvtDa172p7/GTPvy9Gw88vMPPDw6EzkQ64KKRQRRP8nhFEwxVJnmK8STPjnl9O+Ngk8KeWoDxCEj5YnvigIWK"
    "c9WkDCyVAhdoayKvYEQ5iSSA085EOp/PhfstmalO+sT/Xj8wmH/ugvfUbl0yA5ni7s8ckmSDVZu5s2sRDyS8qBjHAyYKQSQC7loi"
    "e7Y84zpAu2d1ieK0rppmUXrHmW09xSjY/N7P//TKxrYU6yjQUVDUpcgYExa1cVoLY+3I5I7qSZ6e0cPuPSJ9O9zpnvzzqAsYh5z0"
    "uEr+QEbmrSgGtpJEou2A0aXIiKBgbFgyOgwiAWutDfQHz/zNFcRR/0XvT6+rSSDSuzFzWOEBAzk7b9CybGtU3QwPNCEeEC8ATdeJ"
    "La3NOhzYrDvjBJAJnn047MTupK+0rKlpkbkzL/jrHx9+5tlMU9rnQi6jLQI9IrlD581Okjt2ldi5R5iumjajlSDmA0S88ySSkill"
    "hsL5rQ3017/fveX7v/nnVR2tIvjWW5Nr9G7OHApYDl3Su2+9nRnzgAk/UZrBHmbMUWsGntZ1ukRNHI//J6QARGAdEB1zWv3a9sOS"
    "wR//ct9fzr/ostX7dcxU+f7+0FGobaiNDCITyQG7m8kdAKbG9FcwlSRwrO2RSST98YKF8ZNIjHGG9dDgtuCI/eb5//PtXz+x/M6V"
    "fzvxEK+4+4UoiKsLSIgJF5CYfAGIONIn6IBXJza/7NTG7H2PrbnrPZ8/9+5DDlvoD/YOhCFFWkRFM13JHZPBVFqAnfGB3UoisTow"
    "maG+4JDDFvonfeRb/1i5ZsuDX31zenB3C1FMroDE5ApAVNK6WheJzFu+NmPb5r7BVSd+6gd/Xrr/fC+fzURsinq6kzsmg6l2ATvj"
    "AxNOInHa6bCYN0EpGy1qbxbv+OyPrsvk8ut/9oGajXMbuTCRQhSTKyAxuQIQw4Ubaih651kz1oU26v3Y/1x6hSdDy7ZkwqCobRTo"
    "6U7umAz2Vl27qpvYdRKJKSeR6Hwu8pNkN/ZuLH7mnCsuT3k2+5P3pddOtBDFJApITKoABCMu3HDiF5pXN8xWpXMvvvnKm+6+t3d2"
    "Wx10phDureSOyWA6FGCsOYJqMjPhJBKrrSllBqNFc2aI31/9t56Lrrrr2t0sRDGJAhK7VwBie+GGuu7Fx6RLf7n1sRvOvOCSlYfs"
    "N98b3NYfOh2YYC8ld0wG0zkKGG+7/JpIEkmsBEN9vcEhB7b7n/6vHz/0j/tW/eM/jvYLpxwheiYSJBqrgMROSN1uFYAYWbihKfPo"
    "Mxvuf+unvn37Ics6E0O9g6HToQngtGSj90Zyx2QwnS5grBuo5gMTSiJxhVBLOJMfHAyXHTrXf+sZ59yyZmP/k989uaZ3V4Uoxi8g"
    "Mc6V7kYBiErhhqa5lH/nWTM2DeQLa0/53I+vX7pknsyVspF2QRT7/b2X3DEZPA8cYHh7YkkkTptA53QYFDVHoW6rS7h3femiK0tB"
    "sOUn76vdsKtCFGMVkMAYDUoEN9ECEKMKN6yFZ4c+c9Zlf+zLZAMBazkfRKWotNeTOyaD6VaAsVxBtY/jiSaROBPq0lAuqqv3ecWq"
    "Vdn/vvAvV7bVIf/DU1O7KESxYwGJHQ8pv0+8AERcuOGMpjVtnV7pJ5fefu3ly2/d3D4jJYJsf+go0uJ5SO6YDPaGBdgVH9itJJLc"
    "QH+4bOEM9eNfXvncb/9635+P7lC7LEQxuoCEY94hLMjMgoTZZQGI4cINJ9VsOOgNNYVb73rq75/71s8eOeLAhV5haCiw2prgeUru"
    "mAz2tgsYva+8f+JJJE6Hpq8vExx8SEfi9M+df++9T6y762OvSmTHK0QxZgEJeDvadRZiVwUghgs3HKr63/DploFnN2x9/KRPnvf3"
    "Qw5t94cGe0NXzJvnM7ljMtib9e3HcQG7mUSCQDsq6nx+KDxg6Vz/pE+d+9fNfUOrfnhq7bb9xylEMbqAhIOHkRbXAfDQ1CrXjlcA"
    "YkThhm/M2JgrlTa+63MXXz13bpp0saBdUNTh85zcMRns7Wc9VGO0xk88iaQUas4VNVNkktLaD33z0iutjnovGr8QxYgCEiPDB5Wa"
    "8BLzu8TaMQtA7FC4QWT/+9zrrnxuw9p8yhNcKuQitw8kd0wGe1sBxrvJSSWRlLLZsLUxidvvfaDvzF/cfOWCZlEYrxCFIIenNsYF"
    "JDwZ2RHZ3QwAFvM6VfdYBSBGF2749dV3/elnl/957dL5LTI/NBg4w/tEcsdk8HxYgPGITrlRJppEEvOBoaGh4ICuWd73fvR/T1/9"
    "j8dueu0BXukjx6r1uRGksFxAYiAuIFFXK7cwACLHcVBIwU+a/IgCEJXnTYws3JC765HVd370v3983+GHLPD7Mn2BhDOlqLRPJHdM"
    "Bs+XCxirIapeE0ki0cZGgZY6NJm+bHD4IV3+uz59zh2Pruq5/0tvSg+9ZikNF6LgSgGJMC4gsWAGVjMAQYIdHAgSjS3e2rgAhIkL"
    "QDDR6MINPdsGn3rbGT+44YBlc/38UD4URWcCndMi2DeSOyaD55MDjMZoJdhFEknW2LBgciannS3qfCkXLe2cJd752Z/8KZPNrx1Z"
    "iCJO8h8uINFFayutTiQYDMzuwLq4AETCAywTgSuFG971rVnrSlGp94P/8+urkmnp2Bmt8/korK7YtQ8kd0wGzzcJHGt7gkkkbCQL"
    "LUJjXCnSuhBEQjmbyQwGH/nO5X9MiGhweyGK+LlPlQISi9rlRiUAY61k54gIaO+UIwpAMANx4YbmtbWtonj2T2644u6HVw601flc"
    "ygxFlovWItAiQ/tMcsdk8HxbgJ3xgZ0nkeQ5LpXmYIJwyFjkTCmbDdvnpumaP9+++fzL/nXNyEIU2wtIzJvHhYSMitaRZBYEEbhF"
    "S6h322rbCbIgAcSFGxq6O1+SLl1z00PLz/nZ1c8sW9SmBgf6ImkiHehAywBmOLkj0uP4/b2X3DEZPN8KAOycD4yfRCKzVlhndCln"
    "jCMTaKelyZu+3oHwiAPneV/6+s8evemeFbdUClHktCJFmnMBWp7YxjWzmmmN1uRZDVXbKHoqBSCgNMKCEHHhhobMIyvX33PKf55z"
    "58GHzE/09fcHrlTUQZg1MrRal5M7RJSzFEb2+U7umAz2BQUYD1WNNTKJRKggbvByEolwoRG5ggkKgXZG66HBofCQI9v9t3/ie7c8"
    "19P7aKUQRTEisuTTQ+vN/K65ttsySAfstc1267c9ZVpgVNKEjNZ2lXnHWW1begeza952xvl/WtoxQwX5fGiLeePIacsw0oWmktwR"
    "RNrIUmSe7+SOyWBfUYCx5giqSZMbnjRSylIujhQGoWeFcSYqDBnFWttQG2dC7YKMLuWK0azWWrztMxdeMVyIopHyoSU8tdG1z50t"
    "epIJjqyzNHOuW79pVdRuIwk/TeHbz2xdH4lo4BNn/t8fSjoXSmKjw3zkTKhtVNImLGpdCOJJHs8aKig3XJ//eUzumAz2FQUAdj1p"
    "xIDnYlcgXcwH+m0gtZWeM9o4a5w2NrI6NKEuFYphuka51d3P5b9y7hW/b0i53IWnprt9RO7ZLa6rq0NkZjTIwUQ9BZ2L1abNz9hO"
    "Zw2O/2zzmpYFXumnv/rH5dfd9M8t81trqFTMhK6YMzYKtAm0kTYwkbI2CEO3LyV3TAb7kgIAYzfUKD5QmTQqJ5GEMSmMbMlol9Ni"
    "KGdtFGhn8jo3MBAsmdcifvaLy9f++vp7rjx0gQq+8HqxdvMQz91Ygn/oEupZuMzfOrMJemt3sOiQt/o9+72qpnTLnY//9YtfPf/x"
    "w5e1e9u2DQaulNdBVNKSjdY2NJGxNtR5IyJj9qXkjslgrz7peoIY61HnhO3KKoDZEm1GwFpRb2Ypl45k0lfKelL5skZJUefZRNpT"
    "CaWESnjNLa2Jx/7xUPGee//wrpcd3PnGz14WzJeS//Wjd6fuBCBv++Xgsi3Pmreeel7bujUbttzXddj7L1l29GK/NDQYBbpkbLk2"
    "vwm01rZkAp03wtNGRpHJFgpxXl9/yowxv79P+v1q7GsWABi7sap96XZSSMRZ2uhEMbAlFVkRGRsZa40NjQyL2kZWO5PT+cGBYP+X"
    "7Oe/7qRPXjMwMPDo905JDi5qQxrx/btEHerf9MWmgZIurT75vV/9fcfiNlEqDEahCbWNAi1zRmsXmkjbOFvJ00b0BlYWChZEvK8k"
    "d0wG+6ICALvmAzEp7PctpHREOSd6AxuEkRU6b7QtGetyWoZFbQthFJYKUWQLOt0o3Ls/+e1LpA3XfvLVqcZQ2xqr4b30P5pa6mZg"
    "29fO/PmvVqx5tiBSZMPsUFyfNzTaOK21K5nQDuggShjR68dP5hDCYcCz+0pyx2SwryoAMHaDjWpgyRjwbBwkip9hEKhYCSLryoGi"
    "yNiwpPPZTNjU1Mx/v/GGgV/+9sqfMNtEwpNHSg+HCYEZ1//5josv+P4Puhft1ynyA7nACRfJcFAXXE5rWzIyX9Qi9CyJwMWZPbny"
    "E7mS9oXm96uxL3KA0Rgxq1u1T8SveYS2UMJa0WDrhHMp6VpDlbIJYU2tcnVSJpwnlEwoVkbUN8/1nrnz8ty99z3y+pe+5NDPA/BW"
    "PLXmkgMP6Lpi6XHvqcsO9Gky1mlTspG2VihrRZSLh5zKGFEoumHSF4/3LXZwUTtE/F5UgD3Azkhh+X0eYaYW0Fo22DrhalLSJSOZ"
    "yvrSJROCfSWdktJ3SvieEiqdlOseuqXw3JruU33Pq1+w6PBLFh50qK8LJRdFEUfSWYq0E8pYEWlbCiNLQjlZzfjHT+4AXiDCB14Y"
    "CgDsqASjXztYAq6zwpmkZGcFJ5tF0o8kOyucrRPJhE++p8SGFbeVAPCMxUemgCTCKOeEVI5E5Eqhip+LJKM48piTLiMkQ+XGy+x5"
    "QfX8Cl4oCgCM7P2V9yoFAI22BGhgslpLcA2xSwqX0DLFSULSEXOCGurrBABksjlHFDICwYEIHUpi+InpolB0Uvp2UHgOYoB3IXyM"
    "8b5P44WkAMDOlWCkOzBGwDnR4OrJOS25lglcQ5yygvMpAoB0yhEAFEvx8i+qLTGKxBXBE8UTUMMPYB4Z468e57/gTH8FL1QFqN6u"
    "ChBV9s0TmG2prARUUQRmK4B6cO0QMdcSOFYAkGAgB8qXH45Jw49ejZm+EFyV0lUt/NEzmaj6/ILAC00BgPFJYbVCENBOgI2tgXME"
    "awUANDGTc/Vj3rcQWR6sVAOVMu7VvcrFT1JfB4zf61+QwgdemAoA7NwSjHIL7QAigZnl3m7M2LEPIRjOUTyhA8Tz+ZJ3snZvrGjf"
    "C0r4wAtXAYBdW4IxFMHGVmF2+QhXVgpRXgK+GYiFLnnUQ5cr2zvz9S844QMvbAUAdiSFle3xyGLVMfOoHMJFrBg9Y5ny8fZVfwZe"
    "oMIH/t9RgNHb1Z+rXQSPsb+CamESdi+2/6ICPM8YT/iV7fG+53E+Y9TnF9QEz+7g/1UFGL2vutfzGPtH75voPP4LXgH+P6OpzbQ2"
    "w3MaAAAAAElFTkSuQmCCiVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAACKF0lEQVR4nO19d5wlVZX/95xbVS907smZ"
    "STAzhCGIwBrAuOoS1oAsuob9Ieoq6q6uCQNr2HVNmBPoqqsigkgQIygSBBQYMsIEJkdmerr7xaq699zfH1X1+r3u13G6Z7pn3nc+"
    "8+nX9V6/UK/Oued8z/ecCzTQQAMNNNBAAw000EADDTTQQAMNNNBAAw000EADDTTQQAMNNNBAAw000EADDTTQQAMNNNBAAw000EAD"
    "DTTQQAMNNNBAAw000EADDTTQQAMNNNBAA5MGdKjfQAN1cTh/L/ZQv4EG+nA4X2gTjca5m3xoOJdRonERD47GuTm80HAOddC4yCM0"
    "zsORiSPeKRypF/5Efe4j9XwebEyU4R5xDuFIumDH47MeSedrKmM8DPmIcAaH+wV9IJ9vPM/N4X6eJwrjbYRjfb7D1hkcrhfmaD/X"
    "WM7DeJ+75PkO24stRvV5G8/POpbnqvmbyy67jADgE5/4xGDPddh9N4ebAxjN5xnpYyfiORs4MIzGEEfyWNvv50i+x8PCGfChfgPj"
    "BMLoDHqwx1Kd/9X3DfYY6nf/UM/X+D/6/6M5nyP5Dmpw2WWXKWstgiB4ltb6tQDsbbfdpvo/rh8OC2fvHOo3cIAYj1V8NPfVu8Dq"
    "IXGso1lRGqgPi5GdT4uBhl99Hwa7b+7cuURE1lp7MYDnXXPNNdf96U9/kvhxQ630yfNM2WhgKkcAIzGqwVb7wVaDka48gx3vfz/H"
    "/w/1CjqV/yfnb7jzzXUeM9jfVHDmmWfyjh07zM6dO2cCOAvAkrPPPvs5n/zkJ+U73/mO6v/4QTBlHfxUjQCGO+GD3T+YMxjqWLIK"
    "1HMWo339oUDA/DH82VTEtuTGaFbO5HsY6r5631H18QERxKte9Sr1nve8R3/sYx87H8BiAGEmk3m7tfaOo48+uv/jD7toYKo5gIk0"
    "/KF+rxcp1XnORfFPM8j7SI4rO/AYAJj6f3bYYU5yo9/5qHd+akB9922uc98A4+tv/DXfyymnnIK77rpL33///Vkiej0AH0AJwAt7"
    "e3tXtLS0PHXZZZepT3ziE1L7fod1BFPGCUwlBzAW4x/KqId6/BB/twj1DdwQENQemiUEZguRfo/v//uRjkHOD3OfIe1MbiTnfn4d"
    "I1Oo4xgGg12yZIlz7bXXlr7//e8/n5lPAbAfkfHObGpqeh0RffwrX/mKAiD9/nY4I58yTmCqOIDRhtsjXd2Hcgjx7/0NPui7PQcY"
    "YNzVv8sw9zdQH4nhV5+rGf3uq3YSNc5hDqoiCAK2VYfx1eU+yuVyctlll3Emk3kr+sIvBaCXmS/Yvn37V6+44oquM888k2+//XaL"
    "WqMeLhqYEinBVLgYR2P8I8nnBztWdXt+dVge3Z41lKEPYtTW1j3eWffByZ/U/5sIHUP85WTC/kHvIaJBDaJr8D+q/zfVEUL/2xWn"
    "UJ1OVJwBTj/9dLr33nv99evXr1q6dOntqF3lNYDppVLpLdls9odf+cpXUu95z3t01f31Uo2hMGmdwGSOAEYb8o8k3B/iWGL0hiqL"
    "waw6Rl5t7FXG2onEeDvihxliji4+kdqUwaCekVdf5IM5AV3/8KRDyxD3Df4521Br6JXzZwwnt4H9FSfSZeLzStSXZiUp16x+kcJu"
    "ttUkayqVUgBk0aJFF8dveB/67IEBlDOZzMXf+c53rrr11ls1aiOI/iH+SKKBSekEJmsEcCAh/3C3qfZ4teGjz+j7G3xs7PUMPfp7"
    "S9HFHT3OWiEittb2iw5aa9+4baQEoOrVu7ffffE5JEoek5zjyAn0OQaAqNt29f0SHU+eu+o1ZmEWpk3T4RVX/Gj6c55z8u0ApgMI"
    "UXu9CICm7u7uczs7O/94ySWXpL72ta8ZDL/6D2Xok84JTMYI4EBC/v4r/SA/q/N6Q5VcXoRq8nZrKTL4dgIiY+/j6TVVG7ltHmjI"
    "Yg0PWA11w+D7w1YH31kAVOUQkAMAEEmfoTNb9EbfpTEGkXMgC7RQG2KnYEHAfuy31lYiBGYLZnv8849xbr322sLxxy97LYAlAPZg"
    "oC1YAG5ra+vF1to/Vh3vv9rXiwamTCQw2RzAWI1/qHC/6mdi+Cb6OSs2eo26Rt9n8AbVK3u1sYvNRiVCCyBe7WtXfQ2gOb6vEB9r"
    "GvRDDogYDjNQjXH3R3J+0rETyAPIAIhZu/hvrQBoSp4nV3EOsWOocgqttg0gZmWJum2XMYQ2g4cff9z8z3e+09bU3HQBgCLql3kV"
    "gBwzv2Dz5s3H/u///u/fXvayl7m//e1vJXk7OAycwGS62A7U+IdxAvOpbpgvQkl431G10lcbPFqjUD0K/VvqGHpz7bFs/KpVxlw5"
    "VJfkyw48hGKdY1MZI/uMSX5fc0/iNIrVDqQAUIsF8n3HqNopkKU829rUAXjpS1/onn/+y7tOetazzl62ePE1iBjLwXT/GsBMrfV/"
    "u677sc9+9rMtH/zgB33E7j5+zFApwKRPByaLAxiL8Y9w1a/K8esYfvVqX2+Vt7aZYIUqxm6ztYZuhbKoNWxr07XvuXpVzySPqV7p"
    "M0N8/MMdJQD9IoNS/LNftEBUrsr3yRarHkMltpFTIFvtEIjytrm5mWZMm8Z7N+83O3Y8mQMQ+L7/S8/zXoSIdRjMAVgALoC9v/vd"
    "70572cte1gXAO//889Xjjz9unnjiicEcwZRxApPBAYzU+EcT8leH+3UNvyMm8moMv0VITJy3V4w+Wt1tJnEAQhmbOIp05RgyiVFX"
    "LDx6TDXJl0kDKMd/4vUdLwNI932gqpuHHcqDHCcOYmNIA6VyfKzKAVRKgaXIWZQQneoy28QxEJEtJg6B2U7PZCiT6aQnH/hdgCif"
    "cLdu3fq8zs7OC7PZ7NmIVvjhbEAAZIwx9yilvv+Nb3zj5ksuuSQPgN70pjeldu/ebX/7298m1NBQhj+YsR9SJ3CoHcB4GD8NvN1v"
    "1R9ixU9W+yS8t6K5xuirVnhr09Rn7CmqMfJMGlaEKsZbExF4NZ9zxHm+dfselxrRX0we+FW3KRzRRT6QHyhXhfeRAyiXAcqyRanc"
    "5yCSVb9UAojtnNmtXAaw4f47CwDK733vR6b9+7+/8xWz5ky/wFXuqQA8AD0Y+fUvAJoBuCLyqDHmulwu96Np06ZtBYBVq1Z5L3rR"
    "i+iRRx4xsWAowaR3AofSAUyg8Vet+lrHJJ2ljrqGXxXi2yyhCbBGc43Rp4VqDD7lUcXYraXEwPvSBJcSg63J+asNGtFVWIErVG0z"
    "hzMqviyMDDjwUKuirnIYNcKhIIxX+niVpyhqKBPZNIC2tlbq6em1u5/6Sw6AvuHmm1c857TTzuns7HwNMy9CZGg5EbHMPFy/fw1E"
    "RDhyOE3xR9gjIjfm8/kft7W13RM/TL3rXe9y7r77bnnggQeS2sakdgKHygEciPEPEvL3I/n6hfsirUMafrLaZ+oYfUQACqXT6YrB"
    "WyuEVCpOFSwBXrTqe4BXIQT7DN5aIVRf6MnvtW7gyANpCyuUOAMASM5Tn6FHhu8DSIVsAwCg0BKRbfFcam5upkfWPRFi99o8AOfe"
    "+9Y8Z8XyZee1tbW8FJFgowigLCLEzAfaAi/xfw9RVBCIyB+ttVd/73vfu/Ftb3tbEQAuu+wyb+fOnfaKK65IqgbVmDRO4FA4gPEy"
    "/oEMf009PzH+qlW/RchKc+QERDOsJZvJUDY24sjwU2TFsBUhm/IoHa/gIk504XhuZPDWJesKpRAZunWT1d+JjT9e+T0AvkORf4h0"
    "A25VCmAlenx1vnu4ioNqcnpEnzM6FiQPsGFyZwDACyKSL6iOBAIg7GP3dz72+yIA/9VvfMf0T37431685KiFr0qnUychWqVzIqJj"
    "ox/vc2oROQJCJO9iAI8aY67zff9HTU1NSc9z8tqT0gkc7Att4ox/JKu+ZDla8fsZfsrjymqf8igVP4e1HllRjBRgxeEBBm+dyBl4"
    "AKxDrhVKDBoA4HkVMjERDLnWodCrMgQr5CY3Y8cwdK18aqP6M1aMPf68biAE0jZE1TnoFyEQswVpCwBpNvKpD/3r8uefcdpLZ86Y"
    "/iJHqUTrWxhLmH8ASEjALCKXv1tEbg2C4Jpnnnnmjve9733BtddeC0xCJ3AwhUCjNf7BjtXP94dY9cVkGSJkxTCammCN5owYksTw"
    "xZJNuZQSIasViyWC55IVh21ayLMuWRKCSpGxllzrEFgI8KLVmoRAHpQwh+mobmStijgDVhaOJSuKiNmKCKWqIgAi14aIDMOldJQa"
    "JN/K4eIIks8bIl7lI9NPJ8Ke+H7tuZY4ZZ3kwZosrENgbSkdPTYMQ4Ac68KD4rxZNG/+wra2tmc5Si1CZIglEbE4uNOuOHltRNfm"
    "PGY+w3Xdx8vl8j179uwJzzzzTNx+++3AyARDgx0fdxysCOBAjb/f8UUEBNEXXGX8ndZSwvBba7gm15c027TmJMe3KZeT/D7luZzk"
    "9dZ1GNYlz41Wd+swRyG/Q64rZB2HYB1yrBAcJ+YQHLJKERAbv6P6yoOI1ncRwwBArmcdKxRWOQEHAHnximgVOcnSWO0Mpio0+hyZ"
    "C2gy1gWAEKg+By6x1UnvhNaVkJ+ILchYWCFtrLgANLNFGAJEdsu9v8kBLfyja7+1+sXPf865M6d3vICZpyEe7jFOef9gSPiANCJy"
    "MAfgDq31d1/3utfdcu211waINAbJ5xyJeGgkx8cNB8MBjKfxU6XENyuMvtTY+DtEuDbkbyYrOgr5s1myJjb+lMdWPLYilEp5ZMVl"
    "6wlZcdhzXbKiuBLei2LXjcN61yGrmJ3YqC0zWyvkui5gVeQIHBdKNGsAjlIEZmsNMSoxfuwYiKwyJj5ebeEaRJ7V6FsVDwf7B/pC"
    "ejWgBKqBEDA1NX9jidjaQIjIWADQxlgHgGFHoMPkYZJu9tiIlbV33lVAUDT//uH3zP3Xiy84e8Hc2S9Jp1LLERH4BWYW1M4XPBBU"
    "h/xZEdnEzL/evn379+fPn/8QIsP1zj//fHXttddq1NcHTAonMNEOYJzD/tj455hYwx+V+DqkjfuH/BHJF7H7GTFcveqL63A6/mnF"
    "Yc+6ZJ3I8K0ohuuQa/sM3ipmOA45oshaRXAig3dU/LsSguvCCrEVIddja00cgroObGCJiKwwVVYiRzFVrMPBwE7fwyX8T9Df8Ks/"
    "swMYgSROj5UVG1gijyyMWIgQKQh0/CdkLGljwWxJGxtCI+OkyHXZPrlhczlcd2/xtJe+quXyT/z7WcetWvay1tam0xCFYkURCQEw"
    "M4/22rdxKVAhWu2ViKzxff/a++6779ozzzxzKwCeM+eU9HHHddLatWvN5s2bq0uBk9IJTKQDGGfjXwQgYMxBVNvvl+9Xh/xWNCOb"
    "JSux8YvH0cpfFe67KjJ+1yERw9aJDN8xzH2rvaJopVfkOoqsErJWkcPEcF1Yy2TZsAMH1hDDcaIVzjLBiSoBLrmx4WvAMiVXvq25"
    "ABNrqOcJ4hMxxRzC0GKngZ+XRGwS7xgSq+LjxrBNogBowDCEjLGABpitMWIrDsGwdV0gnVK0d39PuO2eP/Ri1mL3/7522XEvOfOM"
    "s2dOn/YCZiTpgY+RX/82frPNgOSNMXfu27f/h5dccumfrr32e10AMqe8+MVevliUp+7eaKIhJNsSo6829knnBCbKAYyH8VeNeY6N"
    "vy7ZF4X5NSx/NksZo1kkxdWrfkpMbPwOe6LYum6U4zuKE8N3VGTwlpkdRWytilZ6JraOIsUuA4A1xFYxOXBgmVipPoO2BAZiZ+Ag"
    "NnzACldy+r4QPz6Q8NWmlrg2CVHGU6s0SDJYyG+izxoH0TpxAORawAAaIJaKlh/QIMNWA1HXnwFAYkVCiR4L0dAgYyxYrBEl0eOM"
    "bUmlqBwU5cnb/5pD2G3+7YPvnXvJ2177inlz5/x9OuXOx8AZAPVgAThGpDvw/d+tefTR/3vuaac9AiAA2ppe9KIXqDUbH9H7e3ok"
    "aTeOho/UOIHkeSadE5iIi2qcjb+qxj9g5Y+MX5qynJTbbDrNWSskxlU2nSJrDNes+o7DrihOyD3XSbNVzInhO8xsFbFVilJeRinP"
    "ZWU50poqJiXElpmUYoJlSm5bS2TFEhwFFRs84lXeMlW0ASqx9IpBD5/lWys0aLvKZIUZadQSRzyxwzAwfQSgWFt5jLA1SduviCWy"
    "1hixJGJBYo0hSxxGP0ULsbFG4miBxJIx9ukNO8rF9X/MP/elF7bectOV302n3CUi4g+TDhAgcv1vfnf+q17xij8DaJ65+LjUzJkz"
    "0bV1hy4UigKQVSonXUR2ECcA1DqASeMExtsBTIDxIyL8Bl35Y7KvmuXvF/KLOJys+pKE+oqUdbJkJV7p4xVf2GPHUZTKpNXGHXt1"
    "qStv4aQIihnKY0cxwVGkmBhQBOXAsWAoRYCCUkxgS9EyxwSFyCFURQLRp4xuD2/X8d9MNQcAxKu8DHnBVgasSNXjSCx0Ev1owJjo"
    "eYSsgQHisF8bsUC02huxAh0fM4GAjEVZBC5w9NLZrhErMMbO7mxXf772yj13PXD3+c85+biPi8j+wfQCImKYuaO7J/ezjvbWd5z5"
    "9xdMf3rP1qCru9dQqSxJtyEXnCnrBMaTZJ6Ylb9umU9zX31fRyW+jFBGLNlUG1sxLK7mlLSwGMXWNeyqNEtKsxViV6VIGMohYaSY"
    "FLtshZg9j112OZVJq0f/ttF//8WvXHj0UfM7/MBYq4hIQJaIhPpuAwxLQmSJwAwRS9aCmAFrKYkEAABWqPKZxQr1r1QPZuNiD3nT"
    "1pjAVP9CHbD7gQBcFS0Qxyu/9I0KImutJbaAgGEtILCWLBEsWWstw7IlSwzL1lqxxnqKsT9XKH/621dvmN3aoZyMwt6enJl94ovb"
    "vv79G+559gkrt7mO6sAgXYFxZOA/8OCjNzU3N6f39O6xhWcKZFkzMmmgWLTgZpGmPHPBEWNauFPlJJ5VKJgFYDcQzSLcZuu8RvKZ"
    "k7p///r/hOsExuvCmnDjrynzJcbfv74fG7/nOmzFZetqdqWJrROF/I6j2Bpmq0g56RQrQ2yVx4qJodLEnlKek1KP//7e3K9u+eaL"
    "XnHmyecjssvkyxm3Ez8J0H8VmsrbxCWorrcnn009tWn7HSte8q9XLZg7y21rzbDLbB+86Rf71m685z3Lj5r3pnpRQMz4N5fL5fs7"
    "O+e9bsayVaneXMGQUkJ+KERlW3Zcg2LREjtSHQkw99r9zINxAtXv75BHAuMRARyUld/UMX5JeQpWU8ZmSDylrA45lfJIjFLWZfZU"
    "hoWIrSJ2FbFljx2X2aoUK7JKPI8djpyAl04paGDzzr3mvgd+8qpnHb/0ZQIYiGhEZaMyRGy0mvffJ6L6I0wBiADMrogojtSJYOYp"
    "NIKo3vkHou8guk8EKYBhgfCYo+adufmO/21+0/u++rPHn95WWLyw02tddUrTz3595x8ufcc/nVcvBYg7//iJtRtvKJW6pL1tuuP7"
    "gfVVCMAFfEhal1UpnRaUy6iOBERa0YFe3p+8mUkcCRxoBHBwjN+08IAafxXTj3SKRIeqJt93onzfqpRyrROF/CrFDjMLO0qlIodg"
    "2eWsch0NBxu27QofveELF65YPPcsEfQyiwG4F0C4X2OhdZASA2unaEheAQm1Eu9MMfKAsAHzrjIW4eAIwyYWsQ+Yk8ZGjgywFRAH"
    "4Nbu3sKGf3zn57/9+IaNxWMWzUv9+Te37duz4Xf/NWNa65kikqtSDFoAbqj1M3//2reef/9Dj5VaWloRFkuGiG3gFAwFUSTA7EuR"
    "2FK5LAMjAWX386DVgeR1DmkkcCBf+EE1fmnSnNT4K0x/XOaznuGU6TN+V5Gy1iWbSSlHMVsm5UiKFXtsFbFyHWWVx4rAmeas09Pj"
    "2+3P9OpHb/zchSsWz32eiPQyM258BguWpPHz41vw1N/KeNEzLs7XPkBT1EysBSgykPAkD59vd/CMAVwFyPV78O+hh3kmmLpewFrA"
    "yQDtGn99SSd+XAjR9OvH8C8vX4VCc0ryALd19xY2vuqSy694dN3WApV69Bc/+c6T3nDu8/8bkY6fgQr5175249ZvHrNk4VePf/H5"
    "LXt39YShLgqFSliJKVOv5dAR4kA4CM2QToC6LZSSyegExhq3Tg7j9xxVMX6TUZHxp5V1MuxkUsphT1n2lKKsUp4T/Xczir20YijV"
    "3Nrmbt+Tk8VHLcpu++PX37Fi8dy/E0GOmfF/27D0NzksuHk3zgbQsjKNe7wyNrguLAwkVoHbqfSfLYzjwDYR1rc72GOANgO0AQhm"
    "e3hEEcACIQuQhZ1K/xkQRbDso3BGK34LwP7yEbzwnm04+so/Y1mgOQ1Irr21adGvrvzgv73zDS9b9Eyo6PNX3vi3fKm8HpGeXwAg"
    "Tgl6fnjd7//gzT4pky8LiSLlqLRymxwWwyolLSyuZisei+eqjBi26TRb4ykrWZYmHV27YqgTnX1t6rMkutb7dp+ifv+Hsp2hbG9M"
    "fnssDmByGH/Kjcp8pjky/qbE+JkdRcqypxzFrMhVjiJmcpR4acUOOQKl2jvb3C3bes2qZYubrv/SJRfPmt5+HIA8M+wPtmH5vXnM"
    "ag5g9gDL79yPFQDKcz38CQSydZWKk/+/WLAFaKaD+wGUezWO2a/xXACyIouHxYdPDEYt6Tkl/lsBVBo0U+EvzQ6e6Spj5uO78JyM"
    "hd3eg5av34FVfsApQPKZlDfjY2//x7d++j0XHP3ozTd1rXni6d8D8ERgRcQAaN6xu+uO/37/R59efuzqZt/X7Dppto5iMaTcJoet"
    "q+Iqk64oTTNi2GaErM1S4gSsNWxMyJ22gyajExitA5gcxu85SnSoPLdJiWHlNkXinshLp5SwpxRDCblKsaPYyyjrZVRUpVeqvbXV"
    "Xbd5vz7j1BXtN3313y5ub21aDEh3ySD15U049v48ZqQtrIlz/T/twwsBNC908UQqwKNuBgQ7KBM1OWFhlQOCj/xchacBeCWL48uC"
    "ZwNo7vCwp0lhE3vxo6cQrIVlB6R87Du5BXcAoF8+iOdpICsW1mPYnb1o+sJtOG7zPm4HkCPmzIfecs7/+8y3Pr/60s9ffbvWZjcz"
    "PETXafDHex6+1Z05xxUmdlKeEkYUUWZjJ6BYicMq5bWwlziBdDqSnqc1J04gkqdPXicwXtT1hBt/RgyLcZX1HCWu5pTXwlG3nsNi"
    "SIki5TppTsg+5WWVYkcp11HieA47SpHDTuu06d4DT2733/PGly6+7ouX/Ht7a9NCQHJlw+kvbcLKtWW0pWyULgNgBJAuxuIbnsGz"
    "AZSXpHGLDaFBIEwtQ7HKBZoZf/MYXaFBpwEWplxk8oJFAMpzU3gEAKyMfiU5lCDAkgtamMJtTS72PLkHS57ai+dBR5GMBcgl2O4S"
    "0lfegxWb96GDIUWAUx96+z++5y2vfcmyB5/c/BsAWWZOd+cKT7z10i8/tPjkU1vDQEhpJzL+TJod7UWLjKPYcxRbV7H1WqLSs3GU"
    "FY/TJlS1TqB5pE4g/jgHzwmMxgGM5MUmzPiTMCsR+FSMX5GyWcWuk2YVe2khVwn15fuKXPYopdpaOtz77l9b/PjbX7X042/7x4sc"
    "z2kBUMhrTl++CSu3h2jKWFipfv8EQAP378eZANqmM7Y0CR6Jo4Ap4wAsQEbDzlZ4AECYB451HLSCgILgWQDcYzJ4nHzk2J1Szk3Y"
    "BTsBnjm+CQ8CcP/4Nzzfco1+A4kTCDWc796DFRue4Q7FKItAv/lVz3uD6zgShHoXgNR9j224pbS/IJlUxhHPUSrlsfIc5TCUozxl"
    "M8zWpJQ4GXZNFAlYcdlzHRbXUbAdVOsE9EidQL1oAFXHgHF2AiN1AKMx/nr3V/0cB+N3FbtZVonxO9pTkoKyKU8p9jjtOUqRo+JM"
    "QLmO66Rbsu6aDTv8r1z2/0742NvO+X+kOMOQwsYi2j/9NE7YGaIp1d/4k3NkIAWFGVfvxBkAzPI0fis+CqSmhhMgQBwXpAz2zfWw"
    "FUC6ZHECERAaILBYGQg6Mwr7WxysVy4wFT4XAMBGsdjRafzKVeh5eAeO3taLE5LVv/ahIEVAqOFc8WesunM95jFL2QjohKMXrlaK"
    "xffDrf/5rV/cu+Sk41t0KKSQUuI5iim6pmya2bKnnEwkKJMMqajkHDmBVMojcUNlpa0qEpD6TsAYHsIJAAMdwbg7gZE4gNEaf703"
    "G/9PtP0HaPyKlYiKuvi0p6yTZsd4SlHE9Ede22WGUuymVFt7i7vmwU2l6z5/yXPe/fqXvoWI0wwUNha5/ZvbsKIocN2+sL/+Z9Ww"
    "a3rx4r0as1oZOzqAe5301FgprQXYBdoUHgbQUwZmGuCoUAPWQFwXzUXBEgDhURk8KHWMZ5JCVAqUNXh6VQseA5D+3eN4hY07L1Dn"
    "M1hE3RVMoJsew+I71/M8xShbgBSz6c6XN/xlzaZiczrtuamMw6SUclPKprLMlFGKMkqRG5HMDGWdDItk2HMyNU4AaUt9TiBd1wl0"
    "2PahIoHBjH4wJzAYhnzccA7gQIy/3/+BjT0HZvwZdtKecpSnnBQiw6fY+JFSrFzHS2WcTDbt3Hv7Y4Ubrnj/8897wYmvMYJAsfiP"
    "9WLGt7ZihS9wnKGNP/o8BjZwkblpF84AgEUp3CNl5MiZAlEAgY0PM0/hEQA2b7A65SAlUTETBKBkcSqA9NEprHcFe9kFEU1yotNG"
    "ZOzyDP4IoHjvJqzY72NxvPoPem0nnsEh2Jsew+Jbn8ICxYCI7J01rWX2ozf9zz89vnlX0FPWyLQ1Owyl2LKjvCjxd5QXV5fSHHED"
    "pERMjRPwXIeHcgJJibBDhEfhBNDv9+Ei8GExlAM4UOOvuj3Oxq9SUT5mPGXTzIriEC2VZYWUYlLKS6dUyA5v2t1r/vzL/znnvLNO"
    "fKUWBIoR3LaP5357B1YEkfFjGONPPglRAPtEEc9ZV8TiVsbOWYTfq8mfL4vyAFewo9PBTgBZ3+JY0/ehKdCAISwuC2ZAobfTxZPs"
    "oHbb7skGC3HSoDaLh45uxqMA2m97Ci+PrXvY7yN+ALkE++snsOiq+7CMmUUEpZVLZp+x/peff9OCObMye54pSHNLq6s8h8VRylLk"
    "BBQ7SshVjuLYCaSUmL50QIxSQzmBpEQo0joaJzBSvq0/Br2+B3MABxr2J7ercv5xMH5HRY08itlJJ8afUUwZZVNZVlCKXaUyTRlH"
    "4Kmt27vMXd//yKv/bvWyVxhB4DD82/Zh3nXPYLEbiUdGY7kEgdUO0jfvxgsBuEtcrCEfe5VXJUKfbIjVf9Nc3A+gUAAWWMK8UMOC"
    "wCCQCMR1kCparABgl6bxoAQwcaVjMsKCQBJCVmVxOwB986M4pVdjXizRGjG5bQHKMOwD2zDzJ3/FcmYIIPmj5k4/+cYvv/OiZUvm"
    "Ne3cnTNNzS0eU9QsZimqLil2lKp2AlnFolIqqg44PLQTiEqEUSQQO4HBOYH+//tjzE6g3okarRcZIuxfhHpju8e88ptUFHalPWVV"
    "svJbZT1HsWInMv5mp6essX7rXn3f1Zedv3Lx7OeIoEcx7A27sfj62PgJoFEv2wQiH3ZriOOfLGCRq9AzW+EWEDAp+wMsLDFYfPjz"
    "HDwJgAoGJ3kKylalLYSoa78YVQOa5qWxNQNsj6ObyefYLKxKgaY7+Mu8DDYboP3BrXg+BGP6FgSgFMM+uB0zvnc3VviaXUC621ua"
    "jrrxy++86Ohlc5o3bO0K21o6XEmcgMqych0l/SMBGdwJwKapzwn0iYUqTsDa4aoDCYZb/Udsw2OtAgxFSMS36+zWEw/z6G/8yGar"
    "BncOEfYrZlsx/njl9zJKeQ4rdri5pdXd8UxBFs2bnd34689evHLJ3NNFkGcGfrAdS3+3H/MdW6kNjwUEwFqG84udOBtAZlkK97sB"
    "nnZTk9BYCFZ5QBrY2Mx4xgCtvmCFln5fPIFDDYAxtyCYA6A4w8PjlBTSJhcsKRBpFE5pwq0AzNV/xVlFixkQWNixaVssQB7DPr4b"
    "nd+4A6sCzSlAcu0tTQt/9dX3XnLJ616yaM1TW/y2tiZPSCl2bMUJ1KQD6dgJxMRgtROISoQDxULVTqBzaCcwFDk41G0Mdrz/yRqJ"
    "/xyKmEhW/tj4DdUd49VSO7wzY3Rlau+gbH98cp2K8ccrvxOV+ppbWt1N2/ebFUvmNV33hXf8vznT21dBpJBIe/+aw8zs8GTfSMAI"
    "YJ/pkwiX5nm4bTJGAdZGjm6Wi/sAlPOCZUpheqijLUv6PVY8BVU0OAEAHZ0ZIA2eHIhX/5mMv7R62NNVxswnn8FzYA68cpGkAzt6"
    "0dQnHUY+m/Gmf+Id/3jRhy8+b8l9j20ptbW3uEypAU5AVTuBDCkxYSUSSKoDNtVfMSg1TsDa9jpOAIii6RE5gWoMez6qL4LR5P11"
    "cv3qY1UrP4Ca6b1V/fz9h3eKE6qKyMfEOX/C9tes/FZZL6PYUSpZ+ddv2af/7sTlbddf/s6LOtuajgLQU7LsVUt769T4x4aYZJrU"
    "EuGB0l+3KDjJ4fqkJQPQAviE1cagbTJKg4eS/MaVmAP+fgUgj6qlw2hHLB2+7O3n/r//+rfXHn3fE1v85pas68VOQCit6qYD2Uwl"
    "HeirDuiKYrDSQGSjBVGaNItoNqaFUeMEQo42wlmUvM2hnMBoFvFRlQEHIx/6PSYO/ZM3bwxXj+6uTPLJpDljdEXeaz1Tq/DLKrai"
    "uML21+T8fcbf2dbuPfD4Fv89//yyRb/40rve3dnWtACQnC9I1ZH2jhemgkS4VvoLdGiLZaEBqM65sFEaYIkxrUBYgEkoDaZhJL/j"
    "9TqDSYeJVOrSi85+241fee/frXlwU6mprcnz3JRSHnHiBAZUB+I5lJ5kItlw0kUYb1BTcQISp8QtETHYYdupxgnMAeJ0YKyLdl0c"
    "SDdgnRJFnVFeNXP7q7bpSlb+dIpsSihl3D7jz5CKjN9TNk3KplOVUp9NZVmRw0xKtTa3ePfcv7b48X999ZKPv+2ci9hRrYilvV/c"
    "iFV1pb3jBcKklgj3l/7mDI51XbSEJtHO1f8zh0ElwSmYfNLgEUl+xwtDSIfNuWeecP5NV37weff9+cmC6zU5rpNxlEdcPx2Asiql"
    "JGu40kBU7QRiTiDax0KzmGw071I0D3ACMEMQ7pXj9TBo5YCHe8Ag99dJAQYy/tEcvz7jr57emxYTtfSa2n5+6yQrf6S5diQa38Xk"
    "RCu/ZYccz2nJtjlrntruf/U/33L8KKW944VJKxGmOtLfssUJBICHMGQCSE9WafAoJL/j95J1pcOBFgTnnHnCq//w80+/eNOOfVqR"
    "w5lUxqlwAimPk3TAqnQ0ct6QElHR9nNxK7FNCdmUGzkBE/FhsPHUKyuRUKjaCYyuMjCiVGAke6UNxTLWMv79JL6VIZ7NUtmnLxng"
    "iXRHZWZ/ZZKPE7X0uk6aHScKoZTnKGGPk5Xfi6W9D6xZX7ruS+9+zrte9+KLxyDtHS9MSonwYNLfIN6DY9A/JJA2sJNQGjxqye94"
    "oZ502GEJjMB/4bNXvOqeH3/s/I07urVlhzOp5sgJkKNsyuOKYpA95WTSbJ1MdH2Lw1Y0e1op60ULoUiKrYkWSCTj7q3hyAnYOn0D"
    "dUnB/hg2FRiNEGgo9h+V8CRm/G1c7qsw/vGmHX0bdJqocaLK+K3D7DrMwogm+RiPhT1WXlopWOWmPcdrzqj7bn0of9P3P/T8815w"
    "8msE8Mcg7R0vTE6J8FDS32HEPQRYwiSTBo9R8jt+Lx9dTH3SYV6gGCJA78olc5/zwLWfeO3f1u4Oe3wfmVTGYai4Gc0qRxFbSXEk"
    "G4aycVXLuk1spYlTJoqCbcqNbCMTbWMfSYarhEJ1+YABpOBoVn8AwwuBhgoz6uf9Nfv1VY3vrhb6iBe1ThqlKjP8HI5ae1WaHZWK"
    "DT/qwIqMP+toy7Rx135zzy2Xn3vOmSe+SgsCBsIxSXvHC5NPIjyc9Hc4TC5p8AFKfsfvbQBAP+kwABHkj1k8++823PqFNy+eMzuz"
    "Z39JWtqaHUUOW84yk6OUZ5U1UI7D7DrpOMqN9qsQcTjlxVvVp9riqUIZqq4MRD65A5VUQGuOHIAZbSow4BIYixCo6kXjvL9K7NNh"
    "bV3SL2uFrE2TTacomqXmVqb3Wrcp2opbJT39zMqDEs9R4iqVSWcdy0ybd/aYe3/4sdecvnrZ2eMg7R0vTC6J8HDS3+EwuaTB4yb5"
    "Hb83NEA6bAHkFs2efsoNX333W45ePC+7Y1evaWvJegpK2VQ2WsxSHluVYmEo1+E42s1GGgHrUbSXhamQgjWVgf58AIBhREIjxlBC"
    "oKGIv/j3qrA/Xv0Hy/ulivRL21ayovpGdxtSicjHcoqFHeVwlq1xuTWddbrLGus279cPXvvJC6KpvegeF2nveGGySIRHKP0dDoRJ"
    "Ig0eZ8nveGGgdBgeIN3tzU2Lb/r6v128Ysm85ie37gmaW5tcge3rVCVE17hKR3MrXYeqOwijykBECsIKwUakYF8qYKgTwECRUA3q"
    "pQKD2vVo5wFUPWE/1r+ezLcq768l/UwkkZSY8c9Em3MKoTLGyyrijrYmd8czBbNkwfzMtlsvf/vKxXPPiKb2jpu0d7xAmAwS4ZFK"
    "f4d/nskgDZ4Qye+4vTnUSof9IJ463Ny06DdXfvDd//aGs4968NHN5Rmtba5llx32WLGrLKdYMaJ9KQ0pcUwUBYuKFsaYD0hXBozW"
    "pgI1IiEAg3QOAiOMBkZKAtZ54jj0BwAR6gSQ5P1AKxKlXyX0j0m/yvbcrkNwnWh3XmGONun0WKWinXpaWpvcp7fvC1ctXxBN7Z3W"
    "ftwESXvHC4dcIjwa6e8InuvQSoMnUPI7XqiWDn/jLqxMpMOZlDfjP9/56rde9p4Llt730NpSR2uTK55STjpFih1lORVJ2xWzFcXW"
    "uhQtiH18ANL1UwEAiBZaoE5VIMEgi/bA+4dTFdXL/WmA2q+K9UcrEOmbDVupHeFtxbB149BfkXIUqWRrbpXyoo072OOWbJP71Ppd"
    "4XNPObb9xq+/962Vqb0TJe0dLxxKifAopb/D4VBKgw+G5He8MJR0+GNv/8eL//tD/3LMmjXry61NGceSoxRTtBu1gbJVpKDnOmRd"
    "w9Z6lOw3UC8VSEqDtVEAUEUIjioKGEk7cP0nqUv89W3dZTOZSOGUjhxEynPZ2hay4kR5vyi2jkORZDLFQlCWPe5o6fQefnh96YNv"
    "O/+o67/67+9Lpvb6whMp7R0vHEqJ8Kikv8M+2SGUBtNBkvyOF4aYOpz+8FvOe+fNV378eQ//+bFiR2uTa72MSkhBR6XYKma4DlUa"
    "h0Rx2qbISiQSqpQG41QArUBFKgyglgsYVRQAYOQTgao8S9XqD0SlCXQgIf5qPJZNk7Ux6289sq5h11EM65DrCiWhv1UeO+xyS1uz"
    "+8Dta/KXve+Nyz72tvPeflClveMFwiGRCI9R+jvs0x4CafBBlfyOFwaVDgPmH15w8j/9+mefO+uB39ybz6ZTKuWllRViy9yXCrhN"
    "VJMKpLwoshaPs3E6HVXUIruriQIqMuHRRwFDSYHroe9xieIPfbl/hfjLCEXEX4pgLUUeLZ6jboWsozip9yv2mMmqbGuzeuihp8rf"
    "+cYHV3/0Ha98WyTtRf4gSnvHCwddIkxjlP6O4HkPvjT4EEh+xwt1pcOIpMMvP/PEC2770/detn7TrgDWUiqbiURCKloEk9Kg5zoE"
    "zyUrcdqcTpHE6XTFxqobhhIMXhEYDAQMPw+gnzepYv4B1Cj+6q7+QhLXOa3nRh7OUewYZkeYLTPblMdtHdOcR295qPibH37y+W+9"
    "4CWXkFKxtBcdB1naO144qBLhMUt/h8PBlwYfMsnveGEo6fBZz155wSO//Mrr1q7fFlomTmVblBiKUwEdbT0mhl3HYWtdqhCCNk1D"
    "RgEVDFoRQNXvNdHBYL0AgzgC03e8avUHAGttxFI2AcnqH9X8LUXEn2Hr6Iqns46idNrjVDat1tx4S+9vfvPlF77s+ae8ToCywiGT"
    "9o4XDq5E+ACkv8M/9UGUBh9iye94YQjpcM/yo+actfa27/7z2oeeLuf2F2xzU6uCY8k6WXJtVBmzEqkEbWzsURSQqo0CbBIFVKcB"
    "o8fopwJXDfqwcQgShSQt0YdPpvtYIZuU/azb918cguOQ8lwVBkIb1m8N73/khte87Pmn/JMGAoYcWmnveOHgSYQPVPo7HA6ONHiS"
    "SH7HC4NJh41IbvlRc56/7aGfvX3F4vnpHbv26KZMs+OIZms46hOwQnBdstajhAsAgOwAcRBQkQgDg6UBwBCXwih6AeLwv4b8AwAb"
    "hSTJhB9r41TAUtraKPd3LVknYjvhOtTiZZVjhTY9uSX42y1X/PMpxy97tREEDuDfto8PtbR3vHBwJMIHKv0dDgdHGjzpJL/jhf7S"
    "YcVsAeTmzeo8/Rff/di7T1m1PLtj646wubXTsa6Qa4XgOuRZibmAKP9HOkW2piJgKxJhABhEGATUt+cR6wCq7qsN/6Mf/ci/JDJI"
    "p+LVX8h6lmAdstaSa4VamjLOvq68rHt0g79hzdVvXrZwzotEZP+kkvaOFyZaIjxO0t/hQJhgafAklfyOFwaRDu9vbW5adsP3PvFv"
    "p6xe2fTEQ4+VO9taHStOVcRsowg65VHSJwAAsNlKxA0AHcliPDANGJMOoD/qPknlRVuTI81IyD8ASImQtR7BuiRiGABa2tucrZu3"
    "BcetXJTZu+H3/7FkwZyzRNDLzJNN2jteIEykRHi8pL/Dv85ESoMnteR3vDCIdLi3tblpyc0//OxHP3vZu5c8dus9xc4ZnS5ciSNm"
    "l2CF0omtWYnIwPh20iMQleFjjDINGN3GINWDPpPafxL+W6Fs/MYi5tISrEueKwQPmNbe6v7t8af9M1avarrxe59+77TOtpMA5Cax"
    "tHe8MGES4fGU/o7gtSZGGjwFJL/jhfrSYcllUt7M973tgv+4/FufWv7o73+V62zrdK21URqQSqESXWdisj1Tx8gHVAMWDXhIPYzu"
    "IhmQ/0dvCACi3MSSTccqpiT8B9DW0uE8cc8jpQvOOav9uh9d/h+tzU3LAdlfNkhNamnveGEiJMLjLP0dDhMhDZ5Kkt/xwkDpMLcD"
    "kgOp7LsvPv8/vvWD7xz7tz/ckG9raVYD0gCbqkTY1an3QB4A6Dc/cFCMsAowv5YDQHXjT/RmoqPZ6EcmDWs9AoDpnTPcp+64Nv/V"
    "r1227Eff+O//am3KLAXQUzacvnzyS3vHCxMhER5X6e+wLzYB0mCaYpLf8cJA6TB3KEYeUJm3v+lVH73jnttfsvau63pnTGt3PNcl"
    "AEgDfQuvFQKaa56zoyYCqCC5tgYt9Y+eA4jr/33oIyMSR5CKPdGsGZ3OI7df0/3N7/10xTvfcsGHXFe1AcjlNTJf3owVsbRXpHJe"
    "DuP/BEDD3t+FMwG09pMIS3wGRvyvv/Q3r7HKddCizeifa6T/CBCHgZLgZABORRrsRGrEEZ+LaHXvL/l1bnsSz7MMFesLaMTPNwX/"
    "WwC10mF0KoWiCPTzTj/pbXfd/9DLH7n9mv1uU4ZTnttP8IPYCQB95cAYoyQCnaHuHOyPK2F/s0TBrc0SrO5LD6wleC49fscNvTfe"
    "/IfT/uFlZ/4bM2cAFNYXMP3K7Ti6aKFSAIQPD5JnBCAYoJDCjKt24Lmvm4vfLvXw20d8rFAeshKRbCNb9SzgeAAC7JuVjaS/JeAk"
    "hwAmME3UGbVQBoCxOE4LpmUU9rW6WJ9zcVJYBI3qdW30+GNSuNlV6F6zDcdt6cbJ0V1Q8Zk4bKMAIPIEioDQwLnibhz7ilXYfOZy"
    "2W6ES885ZfVbH3z0ydRJzzrzhhnzFzuZrEeBLiHh2kpA5AQIFhERaIGekbxsTcTZ3wEc2AlPIoCUR0FuT/jQY0+9avWxR18kQAiI"
    "bC1x8//uwPxAEGaBQBDR/XaYpz1swLDQoMfyOGNPgIdmetg5LcSd3QrPlwCjadqxTKB2hfsVkAuAOQLMCDVK1mJCZ/dJAOt5oIJg"
    "URuw56g0HnikjGNUdFmN6P1bwCoXlNHYtLIDjwNoun0tzlIKPpkDVy9ONTgchQS/eQKzMg4Xn71Y8kbYP/G4Y966beOjs5918pnf"
    "QnaasiJEGcD6dcN9xFGCxSwh7FYjMitCbUMQ9bsd/485gBnRPn8d0sbJHn+i08pKmjPpaJcfcR01fVq7s/6B2/xn9nb/+/RpbS8W"
    "kQIz794b4ImywKQx2XbRPLgQgDJkwjZHBVCwZUFWjyGPThFKDFgRuFbBlVGeVCeaZwcZw2sTwUAQuIDNW2RGS+CyA9vMKAMQP4Sz"
    "vyAZhzHeBcwpA4ZAwAgEmNuOowAsExHLzJ33rXn0c88+5YTfLHz2SzL5rp6Q/B4plZWwCgxxUbjgCLMj+6nbQimB4wh2Kgtsq5d+"
    "oPrncCnAkLB19MfpTBq5vV3mjW98RxvIegACZna0YPt0DzsxfNpxJMACigG4xkClFfJgBBh9BMYAoBR8ADLiFKIPLgACI8RYAjEV"
    "vX4zUB713wIKBi4UKOWiNLud8zjMQ/6hUXF8WjSIHSyNf5cZ0ztmAzApz6OcFap3kkQMQVV/h2Y4ctkCE2CMZQCtqRRt2rE58Fxv"
    "OgDPiBQd5pPfc1Xx+Y9uk+aWlBVzWGi8xgYCrIaid56lfnv2iam//fJP4Um/vZPPYvgWqPv91kWfZsrSKKJma8Hkudb/6Nu9azrb"
    "OXfF5YVXd+3mOaSMWGuHXYKrrixbdWhEICKxxuNFy/STF16cvaV7l+644VN736gDmyKGtfXZ7MMbFtFFYQDHI/3az8zc29QeDcc2"
    "xuz85nd+eEt69spsby5fE+PZQZzBaDD+q3GpDNvUzn+5b334xove+d/X/PiKz3qeOwtA6Z/PcFMX/1+4eEeO4XBEZR+JIFj4yOKW"
    "xworzz4x9VhHGxV27cUSIBXzwxNpAxYWCoqLUi6LAtg8s1MWdu/NLACVJ/i1Y/GjeFi6wjwGoLT+3tLx+592VloOUb+L9cgAAdA+"
    "4flvy2xvalf7jIFVCvZH19z4pc//90d3LT3ppel95Vw43mfngBwAMdt6hJMf5Oyc5cekbrz26t4fnXvONy7651d9ItBwT13s7vrU"
    "uQbvvzZY5iprD+rI7EkEIghsiTfslYUAMqed4Oxsby7u6ck705n1hJ4XIlixRK7LJY4aU6AcBKCyEOsRRQBjR+Tc2MmZ40/ObACg"
    "tj9eXgQWS25orByBBIAFiMn6Rcsnndu887TzW582WpRyuOWBx5684l9e9+qHjz7j7Obuvd1Bf2sl4iGW0GFJQMLYOYD9AFrrLlXE"
    "bInYFoo9ZtVzX9r0lje8+vFjjnn4+8899YS3+RpyzknpPX/bZZu+c7uZ15bS1tgDjmKmHKy1xNC0J2fnbNojHUfN5D0zp9G2/Tln"
    "JiOUeE7DRL22BZhgpV8jGLGNQrIJNEISwOF0k963/DjnGQDpvZvCoyyYIGB7mOj+RwNi2KAIXnBCqufv39252Rgo5XDb9l17f/+s"
    "Zz3/5uWnvaKlq7tXV5j62Oj7Gz9zlcGL0AgcQPR3/X4f+o+49kWtCCF+I8U6D+/uyZklZ7yy+XnPfvZvN23b9buUgyZtRH3g5Zkt"
    "py9Bby5wSNGRmAgQMYwthk72znXhXADh8oVq46F+VxMPC4iD6TN4q1LI792mO/JdZo4lfXA3UJkkIAIkBGU7KDzvI9M2ABClkO0t"
    "lJ581eve+oPZC1d6gU5srgyUyogVAIM9YfTY3UNFBrU2PpzHrftEFL8Q5eMXon4/ASBgGxBbbUoy/1kvzpx85qt+2Jsr/M1R3ASI"
    "/c4bs2vnt1u/pBXxFBz4MA6wBg7WbDaLAPBxx/BWhwMjoAMZ4zclMH+xsxFAuOn+0lxTdrIgM9HEx+RD1AxmLYBzPzp9bXOnU4Ig"
    "ZcTkL/vMN7750CPr/Oz02SoMCpaILBFbYrYo9dlf1ZON+YIZScg14Mm7BjwkX+UEyEaeyAcCIAi1zabTHBS0veyLV1xpRLqNsNec"
    "Zv/yf8qsSzlWtBxhyg8AUfXNYN0esxhA5qQVzp6mJumKK3OHoUzCAiAm5ZtjVqmtAHjb4+WjyCrQEbgAEGB1meisi9o3Ljoh3W0M"
    "FBjOL2+95wdf/q/Pblt28gnpYqlXfADwq/+QbbHqdt8d+0f7FobN96qefJut5BTcP7zI9b03KlsA8JPHUGgpZNuTy5uFx63wvvyJ"
    "r2z/0XW3XKEYjq/FOWmR0/3Bl6c2BYZoKo59OhBYWFLQeCYns3Z0SavrotjZRnusVYf6rU0ULKDgpWx+0TKvC4DXtUUvsJTI/o8c"
    "EMOGRaJjX5zZc+qrW3caI6QUWh58fMMNr/z7V9x1/Ev/oWXf/h4N0pZCtqDQonrVJ7agYk0UXokKau2zv/BnAMZMujCrKCyJw5OE"
    "BCDyLUrlKrIiemO9Xd3muBc/v+lfXvvOh+6+//GrUw43+1rUhaendr72VGdXzlekjignQMQQWwpVZs0WPR1AsHiO2hTpgQ/H00AW"
    "1kHHNNre1IJcrse0FrvNDEvmiMr/iWF1iWjWCid/9genPy0iUIpbd+7Zd/fzXvjm61e84JzmXHevRlhl/IiVVomtVdC3+HYB/Yxf"
    "DWv8wOAOoP4fcVWYX/lAfawkEUU5CrMlCqLfEYCILLG2uWJZH/3807PPecVbf7dx2+4/pRxuFhH61Cszm0+cb/OFkI8wJ2BtCI//"
    "ssEsAmCPPRpbmAJrRyEGmjqIelbmLXQ2Aihvuq80OyhQ2xGV/xMgGki1kD7v0unrARhmzuYLpY3//I5P/6h1VrsTarJhqGtsgIgt"
    "+YGNCMAiqMQ1i29NBQBAZPybR/SWqh3A8Ia3E1VeZj8AsuhFHJLEuUk1FxCENgjZItQ2JLZaa6vJ2AVHzXFeddHHrsoVSpuYuQmA"
    "vvLNTU9Na7Khb4j4yLgcABAIgid2msUAUieu8HZlU9JroQiHnUyKCBTYpSucLQBo22P+QhKX6AiqAhFgRRP9w/s713fMdfNGIwWg"
    "/Nkrf/6/f7zjr7mOOZ1OqZwXYm2JyIZshEIlRIElZku+IwMJwOTJ66YA1ah7vF4E0P+BcRNBlZdhtvuTSgCxJcrbhAgkKlsQWZ+D"
    "KFyhMPoZagvS1gShaW5vVWuf3FD+zLeu/YExkjeCVGczl790YXZtJFTBEaEHTXiAnT0yb18ObR1t6Jk+DdutdXEgzO7kg7WAolTG"
    "9q443tsFwNuz3l9s6Qha/Bk2KDI9940tW5adnt2ntbjKgXPzbfdd/emPXL7xuNOOy+R7c5qIbRgvmggAwEe5yuijRbZoQWyj/J8s"
    "UXef8e8c8m0MuKZGUQbcDEDZag9THXoQsY1CE7JU9uNyRRCHKWH0U7MNtbaF3rw++rhj0p+59PKnf/bbP1+lGMrX4py2xNl/yQu9"
    "LblAEfORsDIQKRib96n1rnX+bADBkrlq4+HHAyT5P7a3tKEnt9+09T5j5h0p9X9SsEGeadnpXtffvb59mzHCjsPZR9dtufWcv3/r"
    "n04864ymYldvWL1QRmU/Ha3+fmCJlUSLa2J/uQrPNkj+X/2/P/pseJAHYNDjSRpAZJM0gPJRClCdBpBSUq6kAWGUBoTaEmkLItuz"
    "vzc84R+e0/z6V773ngceX/+rlMNZbUS9/QXp7eespr09ZYfUEeEErA3h0f0bZSEOWx7AApaT/N/f9EBpdljg1iMh/09Iv+lHqeI/"
    "fnT6BkCgFDft2df7yMn/8K6fH/vi05q7e3NGG2O1kSj8ZyPERuDHCyuzRdmPFtGq/B/opwBktoPk/+NSBRjwJNVpQOSR4tCEyjYh"
    "LqIPoITjD0XGESJjNRnb290brnrRyU0vuPAjv9qzr/vRWCSEL13Q9PRxc22hEBwJIqFotY95gPSJK9SubEZ6Di8egAgUyLKVzmYA"
    "tO2RIyT/T0i/JtLnXtq53klzIMKp0Jh97/jPb/2ks6OFjISiTSDEIgi1DbUIhWyDkCyxkTL5lRJgMSn/VYX/wP4o/x8+/K+HSuNH"
    "/5JB9c+qMKKfHoCowkBW1IEltiWiyGPF1QAEYRwhaBuSttqUhUSEjLFGrLQ0e/zP7/3CD0t+sEvAGWaEX3t9dl1bxurwMBcJ9fEA"
    "Zl5PAS0dbaq3vcU+Y62Dw4MHiHoPXM+Ulix39gLwntkYHHUk5P8J6feid7ZvnLk01asD8Zhhv/KDX3//ul/duW/2zDbHL5YMi5VQ"
    "68heWEmUMoeWKLAcOkJlP1pUOVn98xX2f39i/BWofjZbQd2y4Nh0ALu58qIRAVGdBvRFASCyfhAKUWCDMLSslSDUthIFGCt+sWSm"
    "T2vl2+55tOez/3vjDxnwA4PUwmkq/z+vSa83ctiLhIhhUAyo+aHNQSeAYN4stdWCD5OPHeX/rR28u3Mm9xqDbL5Lz7RkcDhTvQnp"
    "d+prmrcf96Lm3YFvXMfj1O/ueujn7//oV548/vhl6Z5cQUMbSyxCWiTUZaFQ20AbQRDayupP8aJajG2r2uBr2P8B4f9gHEBy30iV"
    "gNVPpmqigC5Ui4Iiz1RNBla8VqgFFOU3NVEAW+nJFfRxxy5Kf+JjX193020P/NxTcHwt7gtXevv+5bnO9l5fkXPY8gEEgpXAptS9"
    "T5sFAGTVUt5EZGAPiyXSAlZhzlzeCKC08YHSzHIvdQIaFhPZenzokCj9Fqx2el9wcccWY0R5KZV5cuP2O172Tx/50/HPPi5TzPVo"
    "lkBMZfXXfYR5QJZZC/nJil+OF9W44tYLAGT3j5z9HxSjKAMmiD1MEgVQUoaojQKKxJY4EGIltVGAEdIRF6DZitbGkjE215MLTznr"
    "1KbzXvOBOx9du/W2mBTkD7w8s+UlK6mru+wcxk4gwmM7zGIA7uqVakfKDYuHCQ9AII3FxzibAcjmB8sLyLiKeCJHlx46EMMan6h1"
    "Nvuv+eSMtQCsUpzd31tY94LXf/za5auOSvlBSYwlU7v6Rz8DrSTK/cmSUoKyb0ushMplSVZ/IiXMyqIm/K87AzDBoKrA0QmB6oUU"
    "Q0QBNVwAK6FQSxCyJS0Skraki5ZtaMhY0WIlV8jpFc8+NnPOW//rpq6e/FpHcQaA/cqFmQ1Hz0KxEKrDtH2YoKCxZb9ZYAyaF87m"
    "/Z1t2Dn19QBR/d/xdHHFce4OAO7utf7iQ/2uJgzxWC/lQc798LR1qSbli4FnjPR+6PM/vcoPyiadcWGKJUOmbI0Do42IVhIR5BRa"
    "CpLcXwtRbe4P5EC5yOD3U3dk/Mx2iPbfYY8PJwWu50VQIQOTF65bEqyqCLAS3w+isIZ19EF1SciIaCNiVCAsgZiiNsTGFkLfXPTx"
    "7/wgDE23EaTSHgeXX5Ben1JWQhn95MvJDgvLDI2eInXe9ZSeCaC8aA5vmvo8QJT/t3XQzplzeb8xaO7epRcIGxyO0X/U4cd05kXt"
    "m+atSnfrQBxWUFdc+8cfX/Gjm3YsnD/DLeZ6tBEr2lihkrFkIvafQraBjiplvgoFRBZltiVWgkIBILaslACDlf5Gv/oDIx8IMliV"
    "AIkX2s8sA6OAUk0UUCayFJoozNGOhDr+8EaEjBXDgQSlUM+b0aZu/sNf91/+w1//n2JYX4u7cq6T+9ArDtfOwWoeIFwAQFYs5c1T"
    "nweI8v/Zc3gzgHKU/+OwzP8rHX4vTe855byWXVqLcjzO3nbf3254x/u+8ujqU5ZlcsV8SGKFjBW2odEqMCFpy8aaSParhTiMcv+y"
    "b5l96asM5G20+se5//ClvxHZyEhIwEHKCf2iAPRVBLjgCLEjxEpIORJFAYFEYU1gKSxKGOsCtIqiAC0iJFZIAskVy+HqY+Z5H/rP"
    "b/7ttr88/suUw1lfC194emrnBaeqXfng8O0crOUBgqnOAxAotEtXOhtxGOf/xFFv/+wVTv7sD0Qdfo7DzZt37H3gFW/+1B+Pfdby"
    "dLFQ0iRWjARiVBARf1pHkTCFlnRkG36i+uNAisR9zH9c92fu7TP+ka/+GOzYWIVAVRUBVKKArmpdAOejVKBYjMKYcm1ZEHFZMCIE"
    "y6KNH50csUISSm+hpI89ZWXmFRd/5rb1m/f8OeVwszbCn3xlduNpR6E3d9g5gYQHkAV+iJaFs7m7vRV7pi4PEOX/ytX+shVqNwB3"
    "99rg8Mv/47FemTYKz/+vmU8BEGbO5vKlLW/64Nd/NntmsxKIkaBsjB+INla0qSb+4og4NOJzKInqr0RkqVSqX/cH6jH/Qxn+oNfP"
    "cFWAwYRBMeL+gCpdwP6kIpCrJQSZlZAfSg0hqEs1DKg2ImQCMX4gEhhjgrLMntbK5//7F6/r7i08nZCC335Tdu38DvHLUefgFDSO"
    "gbCwxDDoLdn2J7brNgD+zA7eOXV5ALKwCk3NtG/OAqcHQDq3T886rAaARBskWBDsuR+Zvjbbpspi4BmRwqe+c8NP/vLg33Jtba3k"
    "l/ImCv0DiUjvckT8aRNFymFRKqIfP4giZhVH0OxITdPP4Ks/MMrVHxi6F2CoP64KN+JUgPvKgsy99cuCMSEYhFqYtVAQyR1JG9EO"
    "ohMjvpAJREsggQl0W5tH6zdvL3/gC1f/yBjJGYHXkmb/c+dn1xMAmdpJchWICGID8dx7Nuh5AMIVS9XTRDJFeYAo/585mzcDKGz7"
    "W3l6qVtmHE4NQESwYZHpOf/ctmXR6j7S72e/vvvaz3/ppxtXrVqQyhVymvygEt2GWlsSGDLWMBsJk9A/iIg/4kBKrKRP9JOvlP26"
    "qo1/JzDI0I8Rr/7AyAaCjOAJla00CcWtwgkhyKoYebFSKapn+j2SpAKsxIRaR30CYWgrVQELwxIIiZVcoaSPXjTbvfKa3+y88ue3"
    "/UQxONBwTl3sdL//ZamNhVDRYTRTzgoYD27WiwE4q1fQdlcFgQVPRR6AQBaLlzsbAZhNa4J5EroeSCympEOrBXHU4bfiBam9Z1zY"
    "tt0YYcfj7F8eWf+717/ts3899fQVTft7CyGZyPCN1UYLDGlfwlBb1kYCbeLQXwmpKEIu1TT8JMRfElkDfWW/iupvKCcwbETQvxeg"
    "5s5hjlVFAf1SAYqYSmZHKqkAK0m0AUkqUKbeqFtQmzgFsIYj7yjGkjF+IGQC2V8shCcdtyTzrx/42qN/eWT97z0HTYEWfvNzUztf"
    "dRLvifiAKWcgdUBQMNi0TxYByK5c4uxtbZZnph4PEOn/WQXB0auc7QDUjidKi8nyYTEANCH9Zi7nwrmXTnsaAJTipl37eh972ds+"
    "99tVpyzLdJcKIfmhGKsNizZkRIjLoh1rSBsJQm0pJsWTmj+zH5HmHIl+uOAIQFapnAxD/CUYzbm1wMhJwKGigNpUABi0XTj5YERl"
    "S34gHDrCyhgKlYTaRN1QpK3mspDxhUUbY8mQhJLvLYSrVi9Ov/jNn/rN5h177/eicWL43GuzT58wz+bz4dQnBZPGoK4iZjy4SU8H"
    "UJw3U222UFOMB4jq/82teOaoo529ALL7t+tFlgym/OJf1eH3ystmrGPmEECmWAp2v+EDX/tJU4qJxIoJjWGrDflWtMSVLiNChdBy"
    "XPJj1pFKlpWQ34/1p3xkoCML/evxACNyDMMpAUdBCMZvLIkC+mkDWBUj4y+XpRSXOfoEQoX4hBihYqlysrSIkB8IB9oYGENipa01"
    "w2/88DevyeVLW5g5A8B8+cLs+vas1cGU7xyMeICy8byYBzDHLFEbpx4PUJP/Fw+n/L+6w69jjlswGh4g/ue+f/OP77r/qZ7p07JU"
    "8kuaJIzz/kC08YVMWUgbYeWaasFPRe7bj/Wv2fK7RvE3otAfwxyrYKxijJGlAohyl5pUoL9ASCkp+74ljnIiVq4ZWBoMhCSUkl/S"
    "0zoz/NeHnsx96js3/RQiQdw5WPifV6fX68Ojc9AKKOEB1BTlAQgkSf6vN60pHxb5PynYoFDp8NsT+MZRDlI33fbQDZ/4r++vW7l8"
    "dqq3UNJJJctYMpr9qkpXKc77qwQ/fih9ob+qCf0rvf7AcIq/URF/1fePRAk4EkJwyKpAdbNQtUCI2Rcq+5aVE52QUEcnSJf6SoMq"
    "MNV8QK6YD1cun5/6/Leu3XjDbWt+EXcOOi9c6e1794vcLb3+VOcDaniApogHwBTiAeL8n4Mwzv/d7U8ES6Z6/k8KNsgxLTvD64o7"
    "/Djq8Ntx53mXfOHPJ52xMpvvjfJ+HViJ8n5fSGxE/rGRUDtCQd6yMiYIdRQFU9kmoT+xI1woSiT4UXY/s/SF/pUu3KFsEBhlRDCS"
    "bsDBnnQI76OiN9xPIESkhPJ5S+wIitUdg0FUGlTGUFiMThSbWBcgfXxASIZ8K/nenvDE1Yuzr3zjp+96eO3WP6Uczmgj/I4Xpred"
    "s5r29gZTd5xYogfYX7LT1u3UbQDK09pp99TRA5AFFNJN1D1vsdMDINW7K5wzlev/CenXN9YLVinO7N3fu/7FF33mF0cvmuaVCmVt"
    "EOX9LNrU5P1hwbKxJlr5tfh+EC2MflTyo3I5Vs5WC376h/5AVa//cBHAYMcG4ED12PVSAQxoGWaOqwJxrwBHTqDCB/hBVBpMGoZC"
    "LWysIeObaj5Am0DYamNAplz0w+NPXZp57us/dcPOvd1P9I0Tyzy9fCaKhSlbGYg2Di1rJ3XfRjMLQLh8IW881O9q5LDxBqC01XWR"
    "27tNtxe7zcwpm//HpJ/jQc79cDTWCwapIDTdF1/2vf+DhOK6ZAPtG5Li4Hl/GEZpbmhMbcmvFNlCXPKr5P01G32OWO474tA/wWg2"
    "BhlbKlDVMTiwNBjrA5LSoIpnB7CRIAwj9aAuVfgArvABRQm0b0QbM63V4Td8+Fs/iceJpZk5vPyf0utb0tDB1O0ctAYu/XWjXowp"
    "unFo7Qag7pTdADQh/c66uG3TzGWpnA7EhYK9/Me/+dFv//RA17TOZi76Sd5vRZtAtIKp7fGvyvt5YN5PVXl/jdrPcaSO2i/BcJW5"
    "/qh74YxmItBgLzLEz9gJOI705wO44EgyMJTKMR9QkQqHwloitjTuGiQtQgKjjRXjR7LKovZNW1uWbv/ro91f/tHvrmbABgbuyjlO"
    "78fOTm0Mp2znYLRx6PpnZBGAdLRxqJ0CG4daoLIBqLsVAG9/vLxoqm4AGnX4MZ3wiuyuk89p3amDSOzzh788fvOH//O7T648eq5X"
    "yuc0+ZFuhUUbtrGiVZWFjTWhNkJhUYbK+ymft1G935Xakt+AvH+w0H80UUANxpICjNIJDOQDlHIjb5fP15EKR3xApWvQiGFjjXYC"
    "o7ksbEMT6QO04cCYUj6nj18+P3Xp53+89le3P3S9p5AuB+Ked7K356LnOdtzU5AUTPQAe3J2zqY90uG6yM+ehq1iJ7segARwkGmy"
    "Xcec4OwBkN67KTxqKub/SXvv/NVuz8veM22j1sKOx83rtuy6+x//9fLbjj9paSZXyGsDMmy10X4hTlPLoksiZKwhCm2l3j+CvL8L"
    "XTjAvH8wDPrYUWwMMqoXGZIP6EIXBkiF+/MBQRj3C8QTUrURXYpPsPhCftQvYGBMrpDXx6+cnz77rZ+7/YkN2+5KexEp+IGXZ7ac"
    "vgS9ucCZYk4g4gGKoZO9c104F0C4fKGaAjxAkv/zVqWQ37tNd+S7zJyplv9T3OGX7aDwvI9M2wDAOg6nu3sLT7/m37/2i2kdKSXa"
    "GNHG9Kn9rGjjS2hEiEtSkfpW1fsHy/sH9PgPn/dXY0yhf4KRRADjywcMJhVORELVfICK+gUCbYS1EuKSaInGKBmxkiitRBsTaN8c"
    "vXSW99KLP3tdV09+fdI5+J03ZtfOb7d+SU+5PQasgYM1m80iTDEeoDb/d6ZW/h+pLawFcO5Hp69t7nRKiDv8/uOLV/9ky9Zdpba2"
    "LBVLvol0/hHxpwWGJTCkRUg7lbzf51yl3l9mX6ic5P35So//CKS+w0Xa/W8PdawGY5UCD/big70xO7w+oBhxAmUnOlF+KBQoKVOv"
    "TVqH2bgGobYsgdECYyQQsSVDJpCgZEzGJeuXfPPhr/zs6qRzsDnN/uX/lFmXcqzoKaUUjHiAdXvMYgCZiAeQScwDVOf/aisA3vZ4"
    "+aiplv9HY72IzrqofeOiE6IOPyion/76L9d97+rf71i+cJqbKxZCdowxoTZGYKgc6fxD7QhpI6ERQ3FZm0NHiIMK6Ve9sQeREqVy"
    "MojUd6iFFRje+EeE8S4D9v/Z7/7arsGuuHU40gf09QtURELk275+AS1BGI9P0tEJj7oHrZhQG3aM6fVLesG8dueKn/xu53euu62y"
    "5+BJi5yeD758ao0TS3iAZ3Iya0eXtLouip1ttMdadajf2mCwgIKXsvlFy7wuAF7XFr1gKuX/lbFeL87sOfXVrTvjvL/pnofX//4N"
    "7/zsX5914pJMd28hJAmjvn1jhcQXraKolHQpKl8HoU3y/v46f2JHWEWLXZT3o1/eryyweQgbGjFG9NgD2hpsBI/tF8JstoP3CyhJ"
    "+gUqIiG/ul8g0gdQPFa8IrJI5gf4kVw431sITzxuafqdH/vOY3/86xM3pRxuKgeiLjw9tfO1pzq7IlJwKjgBIobYUqgya7bo6QCC"
    "xXPUpsm7cWiyAShtb2pBLtdjWovdZoYlMyXy/2QPv1krnPzZH5z+tAiisV47997/8os+/dvjTzo6k+8thMbqqDdFAjFOaIzAhLpo"
    "SRthNhKyFlZi/CDJ+3uitLYcV7365/1KSZ28HxiUU6t7X3+M+AIZbQQwGj5gkA+wbaATSERCNfoArswPSPQBrMSEHDcNGd+EpixG"
    "YIyFYT8Q8gMxVku5WAiPX7kg9Q9v+8Jt67buuTvtcVYE9KlXZjafON/mCyFPESdgbQiP/7LBLAIm+8ahFrCUbABa3nRfaXZQoLYp"
    "kf8nHX4tpM+7dPp6AIYZmVyxtOWNl37r2va2LInVEugk7w/EWG2o7EdKVS3Cxpqkv79MvbaG9Cs7QlSM0tz+eT8wlM5/qFSg/+2h"
    "jg2KAy0D1js2clIw2dSgPx9A+SgVqDM/IJoqbIRCjuSVsVTYONqI1REfoH0jYSizOpv5Nf/2lV/05EtbmZEFYK58c9NT05ps6Efj"
    "xCY5CARJNg5NnbjC25VNSe/kHBRKBArs0hXOFgC07bGpswFoIvb5h/d3ru+Y6xaMRkogwSe/fcPVf33gqVxnS6ZP7BNqk8z10/F2"
    "XmysqfT3cyjRaK+warRX3AafTzb16O1r8XUc6Zf3j4Zb649Rn+vx6Aasd2wEpCCAnX0ioUgfkJP+fACIo0EJgY4JlahpKIyHiIS6"
    "LFonuuuIDyBjpWhC3dni8pat20r/9Z3rf2pECkbgdTZz+UsXZtcSwYqd3LvT9W0cKvP25dDW0Yae6dOwffI1BkUDQFMZ27vieG8X"
    "AG/Pen/xVNgANNnD77lvbNmy7PTsPqPFUQ6cm25b84svfOOGjcctX5DKF8shSShaIqVflHZWz/UzQmFBavJ+Ktvq0V7Vef/+AaSf"
    "J1V5PzBOBN9IMN6z2YdyDP28W5zrDCAFB84PqBYJ9fEBBek/T5DEFyPaaClGfECxHC5bPNf7/Fev2/TTX//l5wkpeNoSp/uSF3pb"
    "coEintRNQ0QKxuZ9ar1rnT8bQLBkrto4+XiAJP/H9pY29OT2m7beZ8y8yV7/JxWN9Vp2utf1d69v32aMsHI48/DarX965Zs/8+dT"
    "Tjkq213sCY3V0VwKGyn9jMCQwJA2sdpPCyu3kvejvD+KXBOxT3+d/4C8v67YZ8Ly/mociAMY7gUHiwgGpgID+IB+/QKxSAjlsu3j"
    "A1wTFrSwsoYKBUuSfDEibGE40MZYLd1dPeEppx2TfcM7v3DfPQ+v/32y5+DbX5Defs5q2ttTnuydg9aG8Oj+jbIQk5YHsIDlJP/3"
    "Nz1Qmh0WuHUy5/8J6VfV4QelOLtrX+/jZ77xEzcef+KSTL63EAqMIRull9FY73j1j40/oNBGeX9QyfvLsby9QvrlD63YZyiMZxmw"
    "3rGhPlB9J1AlEor6BfpGi5eT0eJKSdnvtUnTELEjunqISDyFlaw24hiT7+0Njz9xSebl7/j873bu7X7cUZyNOgebnj5uri0Ugsks"
    "EopW+5gHSJ+4Qu3KZqRncvEARKBAlq10NgOgbY9M8vy/aqzXuZdGHX4Sdfjtf+en/vea5pRHZLUIjCHfSjLPf8BGnmHBshYT5f1a"
    "Krv5xPX+hPRL6v3DbOaZYMLz/mqMRwpwIHxA/HvVPEHHkboioWp9QNUQEdZiQl2sDBFhgSH2Iz4grgzEwYFpT6fwzx/69lVFP9gj"
    "4Awzwq+9PruuLWN1OElFQn08gJnXU0BLR5vqbW+xz1jrYHLwANEAENczpSXLnb0AvGc2BkdN5vy/eqzXzKWpXu2Lxwr2Cz/67Y9/"
    "fceDXTM7MlwqF7WRUHRQFCPasA2NNuWo9MxJ3q/jXa+1VO/mQ6VyZZ5/ZaQ3UFXvdxMh1yCVsvEV+wyFidyfbTgnMDD0SU5MzY7D"
    "VaRgKeYDqoaIRE1DWkKOVVihtlps/IVFrK3xQwlKBdPZkua71/yt5zPf/eVVDPiVcWKvSa83k3ecGDEMigE1P7Q56AQQzJultk6e"
    "ASFR/t/awbs7Z3KvMcjmu/RMSwaTkWJNSL++sV7iOilO/erOR274yGd/+NRxi+d6uUIpavIJdDSlOhnuITCJ2CcsFITYkco8f79H"
    "qrfxriH9uEdq836gX72/nvGPBAd8AYyXAxjLm65PCiapgFKyn3tqNhytGSpa1TRErIUSPkD3DRVlG7UPJ0NE8sVCeNzyud6nL79q"
    "3S/+cP8N1ePE/uW5zvZeX5Ez6fiA6o1DzQIAsmopb5o8G4dawCrMmcsbAZSiDUBpUm4Amij9Fqx2evvGenHmiQ077jr7bZ+748Tj"
    "lqZzhZwW0AiGezgShIWRDfcAMJny/mqM5xc0/nwA+oaKVviAOkNEgtCYyhCRfkNFq4eIGKulu7cQnnbKMdlX/7/P3PXw2q23J6Tg"
    "B16e2fKSldTVXXYmoROIULtxaDhZNg4lkMbiY5zNmMQbgBLDGp+odTb7r/nkjLVAPNarJ7/hJW/57C9WLp3lheWCCWAMmeKA4R7a"
    "WFN3uEe5ep7/EMM96m/lleCg5v3VOJhlwOrbg31QO1TTUN0hIvHW47VDRaWPD+g3RMTYULoLeb3ypKXpV777qzfv3d+7Lukc/MqF"
    "mQ1Hz0KxEE62GQLJxqFmgTFoXjib93e2Yeeh1wNE9X/H08UVx7k7ALi71/qTbwNQAqwBlAc598PT1qWalC8GntY6/+EvXXO1H/rG"
    "UUAQ+nF778DhHgi1rTvcg2t1/odyuMdYcLBCtJHwAVX3Dz1EhDhiWQcfKhrXZ6lo6w0RkdA3roQ2KBXMWz7+vz/yA91jBKm0x8Hl"
    "F6TXp5SVcBKNE7OwzNDoKVLnXU/pmQDKi+bwpkPPA0T5f1sH7Zw5l/cbg+buXXqBsMFkiv6jDj+mMy9q3zRvVbrHxHv4fefnf7rq"
    "u9f8fueCWR1OuVgOhxruUbOZxyQd7jEWTMS3dCB8QO2JGmSIyEiGihKFlow1gw0RKZUDPXNGM//u3jX7v/R/v/mxYlhfi7tyrpP7"
    "0CsmW+dgNQ8QLgAgK5by5kPPA0T5/+w5vBlAOcr/Many/0qH30vTe045r2WX1sLK4+yt9z7xy0s+/t3HTjluSTpfLMRin9rhHtE4"
    "76kz3GMsmKgvafz5gHEeImKsllyhrI9dPN/78Gd+9OStf33iVymHs74GX3h6aucFp6pd+WDydQ7W8gDBoeYBCBTapSudjZiE+X8y"
    "znv2Cid/9gemPy0icYdf1wNnv/1zt514/OJUvrcYGhtKveEeCLWdSsM9xoKDVQasd+yA+IDxGCJibCj53mJ44olL0//4jsv/tG7r"
    "nrtTDpq1Ef7kK7MbTzsKvblJ4wQSHkAW+CFaFs7m7vZW7Dl0PECU/ytX+8tWqN0A3N1rg8mT/8djvTJtFJ7/XzOfAiDMnM0VS1ve"
    "/OFv/XzezBaWsCwC33BweAz3GAsORZg2Bj4AEzNExBoj8E0QlmVWZwtf8L6vXt/dW3g6IQW//abs2vkd4pejzsFD6gSSDUN6S7b9"
    "ie26DYA/s4N3HjoegCysQlMz7ZuzwOkBkM7t07MmxQAQAmBhQbDnfmT62mybKks81uuT37jh6vsfWZtrbUlXxD4kh8dwj7Fgoh3A"
    "ePABdiKHiBgJJSwXdVurS09v2VV+7+U/u8qIyRmB15Jm/3Ovya4nAHJok20kG4cG4rnxxqHhiqXq6UO3cWiU/8cbgBYm0wagRNE4"
    "7+f8c9uWRaujsV6soK76zT3XfeHb1286Ztm8VL63EJLFYTXcYyw4GBHAaPiAQU7URA8RgeQKeb1s4Uz3+9f8cee3r7n9p4rBgYZz"
    "6hKn+/0vS20shIomwWw7K+Bk41DnEG8cSiCbbABqNq0JJsUGoMRRh9+KF6T2nnFh23Zjoln+9zz69O/f+O4v3PfsU4/Odvf2hkZZ"
    "MYfZcI+x4FCUAesdGypHGsgHAOM+RERApru3NzzluIXpSz7+zcfuefTpWzwHTYEWfvNzUztfdRLvyR3y7cZqNg7NRhuHyiHYODTe"
    "AFQFQbwBqNrxRGnxod4ANCH9Zi7nwrmXTnsaAJTipp37uh8/552f//1xq4/O9OR6Q4YxHJTN4TbcYyw4mBzAOJCCmLghIn4oDGPy"
    "hbw+7ril6Ze/5bO/27Rj7wOew80iwOdem336hHk2nw8PHSmYNAZ1FTHjwU16OoDivJlqs8XB3jAkqv83t+KZo4529gLI7t+uF1ky"
    "OGSLf1WH3ys/PmMdM4cQZIp+sPtNl373qqZ0GqyNkdAYc5gO9xgLJkOtdijH0M+LTuwQESOhSGgM68C0tWXpzR+68ue5YmkLMzIA"
    "zJcvzK5vz1odHLLOwYgHKBvPi3kAc8wStfHg8wA1+X9xMuT/1R1+8VgvT1j8z33/11fds+aJ3s4Wh4ulojmch3uMBQfbAQz3wQaL"
    "CAamAhM4RKRUDnRni8MPPLou98krf3m1iASVzsFXp9frQ9s5aAWU8ADqEPEABJIk/9eb1pQPaf5PCjYoVHf4GUc5SN38x4dv+sTn"
    "r1q/aumsVL7oh0aFcjgP9xgLDnUZsN6xoU5cfScwzkNEjNKSL/rhqmNmpb7wjV9svuG2NddXdw6++0Xult5DtudgDQ/QFPEAOIg8"
    "QJz/cxDG+b+7/YlgyaHK/0nBBjmmZWd4XVGHH9hLqcwTG3fc9er3fenuU05ZlunJFUKyoXBA5nAe7jEWHKoU4ED4gPj3iR0iQjaU"
    "nu5ccMrJyzKvvvh/7n4o6hzMaCP8jhemt52zmvb2Bgd/nFiiB9hfstPW7dRtAMrT2mn3wdMDkAUU0k3UPW+x0wMg1bsrnHMo6v8J"
    "6Vc11ssqhczenvz6l73lszcsnzfLLZVLfXn/YT7cYyyYDBxANYZzAgNDrAkcIiJiJZ8rhieeeHT6rDf/90079u7/m6O4KRonlnl6"
    "+UwUCwe9MhBtHFrWTuq+jWYWgHD5Qt548F7fxhuA0lbXRW7vNt1e7DYzD3r+H5N+jgc598PRWC8YpPxA97z149/7sVgxjkM2KPnG"
    "wBwRwz3GgkPpAMZycuqTghM2RMQYE5TFiC/T2jx606VXXlUs+btFOM3M4eUXpNe3pKGDg985aA1c+utGvRiHaOPQ2g1A3YO+AWhC"
    "+p11cdummctSOR2ICwX7pZ/8/se///OD+2e0Z1XJzx9Rwz3GgkMdAYw/H4DxHSIiMKbkl3RrJs133fdkz5d/fOvPmGEDA3flXKf3"
    "Y2enNoYHvXMw2jh0/TOyCEA62jjUHoSNQy36NgB1twLg7Y+XFx3sDUCjDj+mE16R3XXyOa07dRCJfW6994lff/gz//fUiqPme6Vi"
    "ITTWypE03GMsONQOABgXfcBEDxGxkisWwmOXzkp95EtXrfvVHQ/d4Cmky4G4553s7bnoec723EEkBRM9wJ6cnbNpj3S4LvKzp2Gr"
    "2InWA5AADjJNtuuYE5w9ANJ7N4VHHcz8P2nvnb/a7XnZe6ZtNNEGns1Pbdl1zz++54t/OvG4Jel8qTcUsXKkDfcYCyaDAxgMI+ED"
    "qu6f2CEiLKHkS4Vw9aqF6bPfefmdjz+9489pLyIFP/DyzJbTl6A3FzgHyQlEPEAxdLJ3rgvnAgiXL1QHgQdI8n/eqhTye7fpjnyX"
    "mXOw8n+KO/yyHRSe95FpEenncLqrJ7/xn977zetndbazCX2R0ER5/xE23GMsmCwO4ED4gNovZAKHiEhoTBiEesXiGd7LL/7i9Xt7"
    "8hsqnYNvzK6d3279kj5oewxYAwdrNptFOMg8QG3+7xyc/D9SOVgL4NyPTl/b3OmUYOBpY4ofuPzaqzbu3F1uzXpU0iV9pA73GAsm"
    "iwMAJlgfMF5DRIIwMGnXs4Eu6Uu/9LNrtDb5pHPw8n/KrEs5VvRBUQpGPMC6PWYxgEzEA8gE8gDV+b/aCoC3PV4+6mDl/9FYL6Kz"
    "LmrfuOiEdLcJxIGCuvrX9/7ie9ffunPZghlurpDTUd5/ZA73GAsmkwMAJpgPGK8hIrlCTs+f1e5c+Ys7dlxx3R0/TfYcPGmR0/PB"
    "lx+ccWIJD/BMTmbt6JJW10Wxs432WKsm7iWh4KVsftEyrwuA17VFLzgY+X9lrNeLM3tOfXXrzmSs190Pr7/lDe/52n0nrzwqk9/f"
    "FbKEciQP9xgLJpsDGAxj4AMwYUNEGGTyPXl9yqoF6Xd+4geP3frXJ36ZcjhbDkRdeHpq52tPdXZFpOBEXgBEDLGlUGXWbNHTAQSL"
    "56hNE7dxaLIBKG1vakEu12Nai91mhiUzofl/soffrBVO/uwPTn9aBHAcbt60Y++aV/zrF3+3+uTFmXyuGIolY2DMkTzcYyyYjA5g"
    "PPgAO7FDREoi1phcb0Efu2pu+h/f9aXb123ZdW/a46wxwp96ZWbzifNtvhDyBDsBa0N4/JcNZhEw0RuHWsBSsgFoedN9pdlBgdom"
    "NP9POvxaSJ936fT1AAwzMrliacubPvKd69pa0yw6MGJ9Q1Yf8cM9xoLJ6ACA0fEBg3whEz1ERItY37AOzMyOZn7te795fU++tFVF"
    "pKC58s1NT01rsqEfjRObIBAIkmwcmjpxhbcrm5LeiRkUSgQK7NIVzhYAtO2xid8ANBH7/MP7O9fHHX4pgQSf/PZN1zzw6MbcjNYM"
    "lfxQG9sY7jFWTFYHAIyeFKwTDUzsEBFjrRTLvmnLerRx6+7yp75948+MSEELvM5mLn/pwuxaIlixE7NLXt/GoTJvXw5tHW3omT4N"
    "28e/MSgaAJrK2N4Vx3u7AHh71vuLJ3ID0GQPv+e+sWXLstOz+0wgjnLgXH/rgzd84bs3bTp22Wyvu7c3bvJpDPcYKyazAwDGhRTE"
    "hA0R4cAYhjG5YiE8ZvEM94tXXL/5p7+65xcOQ/kazmlLnO5LXuhtyQWKeEKahogUjM371HrXOn82gGDJXLVx/HmAJP/H9pY29OT2"
    "m7beZ8y8iar/k4rGei073ev6u9e3bzMGrDzOPPTUljtec/Hn7j71+KOiyT5ipTHc48Aw2R3AYBjKMfTz1hM/RITFSk+uNzz1Wcdk"
    "3vC+r95/78Prb0k5yGoj/PYXpLefs5r29pQnqnPQ2hAe3b9RFmLCeAALWE7yf3/TA6XZYYFbJyL/T0i/qg4/KIXszr3dT5z1L5+9"
    "afUpy9OFUjE0oqUx3OPAMRUcwHAncLCIYGAqMIFDREygpZDPhatPWJL+h0u+csvOPd1POIqzUedg09PHzbWFQjARIqFotY95gPSJ"
    "K9SubEZ6xpcHIAIFsmylsxkAbXtkgvL/qrFe514adfiJQSoIzf53ffqqa9uaHEjoSxAaY2xjuMd4YCo4AGCCRULjMUREHGP8IBQJ"
    "tbQ1OXjDx6/8adEP9gg4w4zwa6/PrmvLWB2Os0iojwcw83oKaOloU73tLfYZax2MDw8QDQBxPVNastzZC8B7ZmNw1ETk/9VjvWYu"
    "TfVqXzxWsF/4v99c9du71nR1djRx0S/pxnCP8cNUcQDAgfEB8e8TO0SEYUzgl3Rna4bufeipns9+7zc/ZcCvjBN7TXq9Gf9xYsQw"
    "KAbU/NDmoBNAMG+W2jp+A0Ki/L+1g3d3zuReY5DNd+mZlgzGk9pMSL++sV7iOin2fnXHIzd+5MvXrF2xbLZXKuQ1ixXjN4Z7jBem"
    "kgMYDMM5gYGh3EQPEenJ61WL5qY++eVrNlx/64M3eipSCr5wpbfvX57rbO/1FTnjxgdUbxxqFgCQVUt50/htHGoBqzBnLm8EUIo2"
    "AKVx3QA0UfotWO30RmO9hL0UZx5/esfdZ7/j8rtOPnpBulQsaBNoSZp8GsM9xgdTzQGM5UuoTwpO5BAR1tKTy4WnnrI4+6p3/M/d"
    "Dz219c6Uw9mkc/AlK6mru+yMoxOIULtxaDheG4cSSGPxMc5mTMAGoMSwxidqnc3+az45Yy0AqxRn9vbkN7z87Z+/YcXyOV5oyjoI"
    "fSMwjeEe44yp5gCAieADMM5DRLQxYo3J50vhsccuSb/mfV//9d79+XVJ5+BXLsxsOHoWioVwvGYIJBuHmgXGoHnhbN7f2YadB64H"
    "iOr/jqeLK45zdwBwd6/1x28DUAKsAZQHOffD09almpQvBp4xkrv0Sz+/JihrnXbJBmXfVJp8GsM9xhVT0QEA46IPmOghIqFI6BuX"
    "xJbKRfOW//zBVWFouo0glfY4uPyC9PqUshKOwzgxC8sMjZ4idd71lJ4JoLxoDm86cB4gyv/bOmjnzLm83xg0d+/SC4QNxiP6jzr8"
    "mM68qH3TvFXpHhPv4feta2772fdvvGPn/LltTqmQ143hHhOHqeoABsNI+ICq+yd2iIhIKKVCSc9pb+Zb732063M//O1PFUN8DXfl"
    "XCf3oVeMV+dgNQ8QLgAgK5by5gPnAaL8f/Yc3gygHOX/GJf8v9Lh99L0nlPOa9kVd/hl/vCXJ25+13//8LGTjp6fzvUWtKAx3GMi"
    "MZUdwIHwAbVf/EQOEbHG5Ip5veqoWd5HL7/qyVvueeK3KQcZX4MvPD2184JT1a58MH6dg7U8QHCgPACBQrt0pbMR45j/J+O8Z69w"
    "8md/YPrTIhJ3+HU9eN67v/anE45ekM4XC1qsMSZoDPeYSExlBwBMsD5gvIaIiCWTLxb06lWL069831duX7dlz70pB83aCH/yldmN"
    "px2F3twBO4GEB5AFfoiWhbO5u70Ve8bOA0T5v3K1v2yF2g3A3b02OPD8Px7rlWmj8Pz/mvkUAGHmTE++tPVNH/7uL2ZOyyqrAyOh"
    "H4l9GsM9JhRT3QEAE8wHjNcQkSD0jYS+zGxv5vP/4+s3duUKGx3FaQD222/Krp3fIX456hwc0wWVbBjSW7LtT2zXbQD8mR28c+w8"
    "AFlYhaZm2jdngdMDIJ3bp2cd0AAQit4oCPbcj0xfm21TZTHwjEjxE1fc/LMHntyQ68x6FJQLRhrDPQ4KDgcHMBjGwAdgQoeIBOWC"
    "6cx6tG3XM6X3f/Han2pjCsk4sc+9JrueAMiYk/Zo49BAPDfeODRcsVQ9PfaNQ6P8P94AtDAeG4ASReO8n/PPbVsWrY7GerGC+smv"
    "773+S1dev3nV0llevlQIxWkM9zhYOFwcwHjwAXbCh4g4ZPKlQrhkzgz3hzf8ade3rv3TzxSDAw3n1CVO9/tfltpYCBUdwIw9K+Bk"
    "41DnADcOJZBNNgA1m9YEB7QBKHHU4bfiBam9Z1zYtt2YiPS7++H1t77p379+/+knHp3p6c6FJBAKGsM9DhYOFwcAjI4PGOSLn+Ah"
    "IoEWI5CeXC48eeX89Ls/8cNH7354/R88B9lAC7/5uamdrzqJ9+TGvN1Yzcah2WjjUBnDxqHxBqAqCOINQNWOJ0qLx7oBaEL6zVzO"
    "hXMvnfY0ACjF2R17u/92zru/dssJJyxO9+RzIUkovg0bwz0OIg4nBwCMnhSsEw1M9BCRUIyEks+XwhNWLUi/4pLLf79px94HPYeb"
    "RYDPvTb79AnzbD4fjp4UTBqDuoqY8eAmPR1Acd5MtdlitBuGRPX/5lY8c9TRzl4A2f3b9SJLBqNe/Ks6/F758RnrmDmEIFP0gz1v"
    "+Mj3rm5LOxCrRWKlX2O4x8HF4eYAgHEhBTHhQ0Qk9I1YLZ3ZDL3xI9/9RU++tJUZGQDmyxdm17dnrQ5G3TkY8QBl43kxD2COWaI2"
    "jp4HqMn/iweS/1d3+MVjvTxh+J/5399c/ZeHnuzt7MhQ6Je0NIZ7HBIcjg5gMAzlGPqtChM/RETESuiXdEd7mtc8sSH3qSt/eQ2q"
    "OwdfnV6vx9Y5aAWU8ABqjDwAgSTJ//WmNeUx5f+kYINCTYefoxykbrrtwV9++vKfbVi1ZJaX6y3oxnCPQ4fD1QEM90UNFhEMTAUm"
    "coiIaMnniuGqJbO8L37vps3X3vrATdWdg+9+kbuld9R7DtbwAE0RD4BR8ABx/s9BGOf/7vYngiWjzf9JwQY5pmVneF1Rhx/iDr9d"
    "f37Nf3zz3pOetSSTz5dCto3hHocSh6sDACZYJDQuQ0RgDMV8wKknLUu/9l+/knQOZrQRfscL09vOWU17e4ORjxNL9AD7S3baup26"
    "DUB5WjvtHrkegCygkG6i7nmLnR4Aqd5d4ZzR1P8T0q9qrJdVCpm9PYX1L3vH529csaDT1UVfS1AS0xjucUhxODsA4MD4gPj3iR0i"
    "IjEfkO8t6BNOWpg56y2f++XOvd1/6xsnlnl6+UwUCyOuDEQbh5a1k7pvo5kFIFy+kDeO6pSJg+kzaKvrIrd3m24vdpuZI87/Y9LP"
    "8SDnfjga6wWDlK91z1s+8f2ryGpxHLaB9o1YMo3hHocWh7sDGAzDOYGBIeMEDxER7RvWYjqaHX7zx39wdbEU7BHhNDOHl1+QXt+S"
    "hg5G3jloDVz660a9GAM2Dh0ZajcAdUe8AWhC+p11cdummctSOR2ICwX5wv/dctWtf358/4z2Zi4Vy1He3xjucchxJDiAsXzZ9UnB"
    "Ax0iYnwz2BARgTHFcsl0tmbp9gce7738qluvZYYEBu7KuU7vx85ObQxH3DkYbRy6/hlZBCAdbRxq441Dh/3beANQdysA3v54edFI"
    "NwCNOvyYTnhFdtfJ57Tu1IGw43Hmlr888duPfu4na1ctmeXle8tarDGiG8M9JgOOBAcATAQfgDEMEWElpEt1h4iYQItYY/K9eX3C"
    "klnex7523fqb73j0Jk8hVQ7EPe9kb89Fz3O250ZACiZ6gD05O2fTHulwXeRnT8NWsQpMGKKTTwA4yDTZrmNOcPYASO/dFB41kvw/"
    "ae+dv9rtedl7pm00WtjxuHntpl1/Of/fvn7HCauXpPK5giZb1eTjW9HGxqt+Y7jHocCR4gCAcdEHjMcQEadmiIixZKqHiFA8Seik"
    "o+ekznnX5X9+bP2Oe9JeRAp+4OWZLacvQW8ucIZxAhEPUAyd7J3rwrkAwuUL1cbBTkLlr5glyv95q1LI792mO/JdZs5w+T/FHX7Z"
    "DgrP+8i0iPRzON2VK2x83YevuGFGRwtJ6Edin6TJpzLcIzTEjeEehwpHkgMYDCPhA6ruH98hImR8qQwRscYIyEgQSqhDc+ziue7L"
    "L/nKDXt7ChuScWLffmN27fx265f0sHsMWAMHazabRajiAawdYqvC+Nlq839n6Pw/UhdYC+Dcj05f29zplGDgaWOK//GFn1+9advu"
    "clurS0G5aMSaviYfPxAtfmO4xyHGkeYADoQPqL3Axm2IiFSGiFClaciY0C9pxyEblIvmw1/++bXGSC7pHLz8nzLrUo4VPaRSMOIB"
    "1u0xiwFkIh5Auiycwe3fWhXl/2orAN72ePmo4fL/aKwX0VkXtW9cdELU4QcFddVv7rv++zfetnP5/Blurreg2ZJJxD7GRo0+FdKv"
    "MdzjkOFIcwDABOsDRj5ExFSGiBiBMaqvNJg0DZWKBb1obof6/vV37Prmz267RsV7Dp60yOn54MuHHieW8ADP5GTWji5pdV0UO9to"
    "j4Ua4iMq8lI2v2iZ1wXA69qiFwyV/1fGer04s+fUV7fujMd6Ze9+eP2tb3r/N+8//fij0l1xk08AYypin37DPdi4pjHc49DgSHQA"
    "wATzASMbImLiISJFi1Bb7cNETUMUGQr8SCSUK+iTVy5Ivfu/f/TYH/7y5M0pB9lyIOrC01M7X3uqsysiBet9HiKG2FKoMmu26OkA"
    "gsVz1CZrefCPbx10TKPtTS3I5XpMa7HbzLBk6ub/yR5+s1Y4+bM/OP1pEcRjvfY++IpLLv/9SccvzPT0FjSFvglgDPmhJGKfqM5f"
    "jriQqiafxnCPg48j1QEMhjHwATjgISJaAtM3RCSoRAJBIhLKFfQJx8xLnffvX7t97aZdf0l7nDVG+FOvzGw+cb7NF0IexAlYG8Lj"
    "v2wwi4Bo41BFvq3/tUdpfrwBaHnTfaXZQYHa6ub/SYdfC+nzLp2+HoBhRjTW62P/e11nS4asDo1o34hYIQlFS1GousnHSGV+QnXe"
    "3xjucXBxJDuA8eAD7AEPEUmahkoiWgJTmSwckiE/rCgFxWqZ057m137gmzf05EtbVUQKmivf3PTUtCYb+tE4sX4gECTZODR14gpv"
    "VyYlvVI3DWCAQlm6wtkCgLY9NvgGoInY5x/e37k+7vBLAfA//d2bf/bAYxtyHS1pLvmlPrFPoA0H0WwEI0japE1juMehx5HsAIDR"
    "8QGDXGAHOERE64gPUNaEWtuIGBPRHHXGGQlFrG9Cv6Tbshnatu2Z0qevuPkaI1IwAq+zmctfujC7lghWbO1ufX0bh8q8fTm0dbSh"
    "Z0YnbbPWAfX/PNZBKmN7Vxzv7QLg7VnvL663AWiyh99z39iyZdnp2X0mEEc5cK7744M3fuF7v9y8asmMVD5XDEkgkdgn7Cf2iev9"
    "Idu+4R5BVC5tDPc46DjSHQAwelKwTjQw1iEiQTREJCp/xUNEYpGQDY2Jy2UGZIxoyZd6wyVHzXC/8O0bNv30V3/9RUQKinPaEqf7"
    "khd6W3KBIq5pGiJSMDbvU+td6/zZAILFC2gTQKgYExCz/A46p9G2ljb05Pabtt5nzLz+9X9S0VivZad7XX/3+vZtxoCVx5mHntpy"
    "x2ve/j93n3rcwkxPTyGoJv2MXxRjtdHGr8xIiH72iX041NFMBfaletZCY7jHxKPhACKMAymIMQwR0VVDRIqSqOFYYLTxxViKWfMw"
    "Xk0hPd3RnoNveN+X7r/74fW3JHsOvv0F6e3nrKa9PeX+nYPWhvDo/o2yEIA9brmzmRECtva7t5Ywb6HaBMDf9EBpdljg1ur8PyH9"
    "qjr8oBSyO/d2P3HWv3z2ptUnLEnn86U+xj8m/SoTfZU1WmDYsWaw4R7FuHLSGO5x8NBwAENjKMfQb/UZyxCRKj5Aiwm1idVwESFI"
    "sRMgPxAyESnIsVJw9QlL0ude8qXf79i7/wlHcVPUOdj09HFzbaEQVIuEokphzAOkTzrW2ZVJBXltrMNxxGItmDjA0cc6mwDQtkf6"
    "5f9VY73OvTTq8BODlB/o7nd9+kfXtjU5kDAa6xXAmEjpp40RbUh80RyLfbgkFIS2usmnNu9vDPc42Gg4gD4Md0EMFhEMTAVGOESE"
    "/B5hJ5pyk5CCHIthEpFQRSkY6mhVtaGEOtSiA9OUdvDmj3zvJ0U/2C3gDDPCr70+u64tY3UYi4T6eAAzr6eAlrYm5NpaeLcIHObo"
    "fYsBgwqyZLnaC8B7ZmNwVHX+Xz3Wa+bSVK8J4LKC/cL//ebHv/rzg/s6W9Jc9Es6mW+gJRDyC/EUJBgtMKR80yf2ccQPcjJwqGdj"
    "uMfBRsMB1GK0fED18fpOYIghIiUii7JvoyEiviUuSKjEcNEIKd/ocmASpWDUPlwyEpSNsaGEfqg7W7N054N/6/nMd395FVePE3tN"
    "er2pGifGMCgG1PzQ5qATgD9vNm8FmKLmH1hjrNvarna2TVO9xiCb79Izo/q/pYT0qxrr5SoP6V/d+dANH/3ST588dvFsr1QshAxj"
    "jITCgTZstTE2nuOflPvC0PY1+eSEHdfUNvnU9vc3hnscHDQcwEAcCB8Q/z7cEBGndoiIH0aRACvpIwXZEpckGS8e7YgbyWg5KBvf"
    "hpIvFsJjj5qV+vTnrlp3w21rrvcUnGSc2L8819ne6ytyGFUbh5po49AlvInJGpEoSLACNXue2gigFG0ASp2ABikgLBItWO30RmO9"
    "hL0UZ57cuOPOs9/2P3eceMyCTL5YDJOBnhxoY4JE5usLS2C08U016Rc1+ThC5Nvq4R4R6ZdvDPc4yGg4gJFjOCcwMDStO0QkutBr"
    "hohQOWp5rSYFjRjSjiTjxY2ExlgY8q3oSkddKD25fHDKacuyr/zny+58dO3WPyWk4AdentnykpXU1V12yFFRs06yceiJK9WOTAq9"
    "fgAFgFhBL1qsNqN6A1AFY8pMrbPZf80nZ6wFYJXibFdPfv2L3/SpXxx91Bw39EtatG8MfFPZyEMFon2YZKxXxGkUhbSY/mKf6uEe"
    "SWTUGO5xcNFwAPUxlouqPilYnQpwjzD35bo1Q0Q4EgkFsSqOwmLsBOLSWTJT0IaxqKYUzdAPQsn3FsJjT1ycPudfP39TV09+bdI5"
    "+JULMxuOnoViIWDlUYgt+80CY9CyeB7vn95BOwplcQFwpol6lq1ydgBwd6/1F0dJP0h5kHM/PG1dqkn5YuAZI70f+uLPrvL9cphx"
    "yRZNqCsrf7yRh/YDQ7oskbrRxDV/JcxK6k70jc8FFxxpDPc4+Gg4gMExvnyA4whQZ4hITdNQT2WSELOOGPNYLpvMEEicQLzzsGFb"
    "NqEJNYhtoVzSF33kmz8IQtNtgFTa4+DyC9LrU8qKiKCnRJ1/XqdnACgvXECbQgMG4M6YpXYsWubsB9DSvUsvsKyhS8RnXtS+ad6q"
    "dLeO9/C74tpbf3zl/92wY9H8GU5vvqQ5MMmEY9Nn/CLaCSrjvBO1Y/VOPjUTfeNz0RjucWjQcABD40D4gFonMNgQkaqmoYGdgyVD"
    "YSEyJG2iHXKqnAAHcXXAalPyS3rejCZ18x/u2feVH/3m+woQX4u7cq6T++ArMhtDYxHalLpnQ7gQgKw+xtnUnOUAxjjLjlGblEJ5"
    "4wPlGX7edoYli2Nfmtlzynktu7QW5Xic/dNfH7/+Hf/xhYdXn7I8vb+3Jx7nXZXzJ8afjPViI6GOjD9wCmbwnXyi4R7MyjaGexx8"
    "NBzA2DASPqDq/npDRHKSkIIDmobizkFfhULsSBhqYWNNtEFGnxPQIlGJ0C8KBSWT7y0Gx61Y7H3gA1944rb7n7gx5XDW18IXnu7t"
    "uvDZ3o58oPDkTlkEwH328c7OhbM5D6XsSac7WwDIlodLC3QhpeasVL1nf2D60yICx+GWLTv33veS13/4lpWrV6VyvYWQrDYmLBny"
    "C2Kc0Ggfhjg2fmUNV7bvNlF7bxDl/MlOPgnpVyv26e4z/sZwj4OGhgMYHgfCB9ReyDVDRPpIQS7EIqFSWUrKiVbJxAlwLuoZCLVQ"
    "GFp2+pyAkdDouNYuVhstgeR68uHK01dmXvq699+6cdvuO1IOt2gtfNk/ZjadvsgvPLJdLwWQyaSglYren+cpAwBbHi4vS7Ua+9rP"
    "zHoKgGHmbL5U3vjm937hJzPnTGNjy8aEvpZARw1LFkaXfSFdFl3qM/5E408UWK5i/AdM9K0W+zTq/YcEDQcwMowvH5BMFk5EQlWk"
    "IIrFaJWsVAacKH9mI6EWQ4Uot9bGN1QpEYbRbMGgZExYMlaLnjWzg857+39e3ZMvrHOcaI+BK9+UebIzS6m71wWdAIwxkdJHubAA"
    "UvkumfXyD7ZuSDezLwYpI1L472/89Ad3/vmR3o7mFAW5gmYJxNhSXOf3o2jECQyZPuNPNvLwg1BQrjPWa7DJPo3hHgcdDQcwcowv"
    "HwCgrkioWinIUTMQh04USrORsLLvYNxVVw6MLgeG/EK8p542+d6C7mhuog1PPl384Ge/+11jTK8R9lozXLz07PTONZtlNgCtxZAx"
    "hgDotXcXp51yXmtx+WlNe3QgLis4v/j93T/6zKWXrz/2xIWpYr43ZIly/mi0eVWdvxjl/BXjpyAagea4hlXORGF/yfZX+jH31hp/"
    "Y7jHQcco93o+4jHY+aI6t6t/Ut/v8yOnOytkiBBEqNNaMqaFAUvSpNlKlq0Vsuk0Z8SwTXlsxWNxNaekha0otq7DrqPYOszWUexa"
    "h6xidhSzVcxWFLW3NjuP3vlA8Yrvf+bEi8//+38TQZkZ3u4e2TGrjf8EIAUDgkIx16VPaGrjE6FQZHDbmifWX3fKsX//85POfnHL"
    "M/u6NStHyPgSam0p3vE4cUSkjQQU2orxB5GwqbKRRynmOOKJvpHSz5Uu2t8v769p8qlHAKLq93q3hzrWQB00HMDoUe+c1XMA1beH"
    "dQIdIizSSjVOQAzbTIb6O4G0TZFIE1uHlecKiWTYOoZdh9mKQ9Zhdh2HrFXU3tLkPnLLH3JrHvvj+Scdu/R8I9KtmNMA7gewPn5P"
    "nQDOFBEwc9O+rp6HF57wyi/OXzHX0yVjIymyI0Takol1CRTaaMR5UShU8VZeoVS28BrC+CukX/3hHkMx/xji9lDHGhgEjRRg9BgN"
    "H1AnDQAGiISY7f6a8eKJXFjVTBeupAMqFOaCkC5FA0a5FPMC1mgHcTtxJBzqznWHK17w3MzzXvSq63bu2fdnxdxmjAQAThHBdETX"
    "wBnGiMPMqZIf7HzjOz727fa2DJkgNOWwpI2gIu6JpL3xaHNTNqTFEBvxg1yt8RPZxPj7ZL5VjP/Qxj8Y+dcw/nFGwwGMDaMlBQfn"
    "A6pIwb7x4kqSPQaixqGS7VMLBkI+2+oOwtBErcRsfEO6JNr4RpejqbvG17rkh6Zp5kx667s+/N1CqbxBKU4DEGacBOA0AM1KsYhI"
    "8O0f/Pwbv/7V77rapk+jcr6kWWB0OTDGhppiXT8bW5niy6zjSoUTv7dk/76+Wn9fua+qvRcYbLJP/3PWIP0mEA0HMHaMhRTsd/9g"
    "nYN9TgDJbkOxE+AgNBRo0zdWzBgKTV80ULKGjW9I+VFEIDDlfFG3Te/km2+4tefr3/nptwD48XtoA7AAAh9A011/efSH73376x9b"
    "dcaz0l3dXWFM9hlSfYYfmrIJWQtrMaxM1MqsXUNKG/KDASt/3XIfEDVJ7VRjra40ME5ocAAHhuFIwaH4gPj2fAYMYQ4AEYLWDGup"
    "w7aTiCFrDdvmZrKiK8Rg1gqJpNimXIa1ZFMepYxhaz2yrmJrLXmuS7AOWWvJukLwhVpnz3TW/vHq3tvvXvPi559x0rsAFABoAJ1b"
    "tu/81aL5K79zzPNf2tTTmzMgbREASa4fUGiJyCb1/bLvR6x+LO+tiHzieX5D1vprxnptq+70a5B+BxkNB3DgGD9ScI6JHIAIDeUE"
    "kM2SNZozNhMdS6fIGsM25VHaWrLWIyuKrWcJ8OCJYXiAtULtM6arv912Xc/Tm7ZdtHjRvNcC4Fw+/9clq1/8aTfbpjzXoVAbAQIE"
    "IVvEho8gtERBZYoRqWiTTpR922f8UXMPYnETURTqD5jlP7TYpxH6H0Q0HMD4YKROYJAoAAQsAhAwZkl0vG4kIGRt5Ahgs2QzElUI"
    "bJqQFrLisRWhGkdgheAJWetFz2tdmtbp0FNrHi7f+adfn9nR3jbtnDe89Vf5roK42TYV6JIAQJ/RswXKIFbic2DJT/oZfFsJ+ZUj"
    "KBZt0tyTEH7JNN+G8U9eNBzA+GHCnUClRGibCVYoSQlghTLWkrVpStICABCjOZ1KEQAkDiByCC6lkMK2J35fBCCty/6uqdVzyQ9C"
    "CwCRYCewAFCONui0lDQy+WHsIBJdf8kSq76e/jzbGsJveONHndvVP/vfxgiONzBCNBzA+GGsIiGgj4wlYH50LNEIAIAxXO0EbIuQ"
    "laqUII4GslbI2ky06qeFrE0RrCUrQsikYUUoDSBxEC0tney5Qvu6SqYMH2kiW07eSJXRA0C01bkjQBEljkL76pA/6elPOvtGYPxA"
    "I+8/5Gg4gPHFgfABVbf7OYEKJ2ApEQtZK5SkBEk0gGyWrCSOIIoIYIWQyUQrP1Ax/sE/QdV+AWU/Nu6yJSJbBBCF+2wToq+yI3Iu"
    "kfcOa/zA4LX+Ruh/kNFwAOOP0TqBQVKD+VRTHRChKBJInACQpARAK6xoBuIQP44IYIWyACrOIEHiDOq+e47z9yISo49KkWxRAEBR"
    "rp+w/OiNUgZmR4D92E9UW+cfaPz95/s18v5DiIYDmBiMlg9IbtfhBAxhVhilCDXRQFVKUIkGLAEtqEQEaIZN6z6tR2z4iVOoeXOJ"
    "sVcORA1LVCrFpF9k9NFj+3L9QVd9oG8m4vgZ/1DHGxgDGg5gYnAgfED9dACGashBAJ3Wkq3rCJorr2NFMxHbxCHA5ghoApoAG3MM"
    "ldW98s6KfWlAxfBzIKIBhl9Z9QcY/4hy/uqfQ90e6lgDB4CGA5g4DBcFVP8+TIUgjgSqnUA/bgDoQLUjAADbLAS0VuX/taF/cpyI"
    "+wyr+nZs9ABQbfhANMykRtk3IN8HGsY/+dFwABOLsZCCye06zqAOL4D4trXUCaA6IkiezFohtMa3RaqON8cOIF9jXMRsk9y+6mi8"
    "4keDTWs27Riw6gODlPrq/Rzq9lDHGhgHNBzAxGOslYHqY/2cADASRxAdMhXCcJRvu7LSAwBRd7RZR/RLnXAfGCTkH+rnULcxguMN"
    "HCAaDmDiMRo+YLDbNPB4P26g2gkkiIm+JEVI0OcUapEYe4Q4twdqSoM1q36N4Vc27Ryurt8w/kmEhgM4OBgvJ9Dv5/yqx1XxA0Bt"
    "ZJBgOA1A5RWp1uiqV3ug34oP1JndPxZxTyP0PwRoOICDhwlyAkANSQigkhoAGOAERKhizMl91b9XG3r1fZWZfcAIDR+D3Nf/dr3f"
    "BzvWwDij4QAOLkbrBAa7bxDCMHEECeo4hJGixuCBPqMHhjD86tsN458CaDiAg4+ROIH+vw/nBOocn1/ndern/vXRf1jHtqEMezCj"
    "Hs7YG3n/IUbDARx8DHXOR+sEhrpd5775w787AFXGnmAkBj7U34xmlW8Y/0FEwwEcGozVCQz3+2DRQXLMDvPaqHrMcEY71lV+KANv"
    "GP9BRsMBHDqMxgnUOzbSaGGkr1mN0TqB/rfr/T7YsZHc18AEoeEADi1G6wQGOz6exl+NkYTpIzX0hvFPQjQcwKHHcN/BSKKB0Rwb"
    "Cw7EyIcz7obxH0I0HMDkwFicQL37Dtb3OV5sfsP4DzEaDmDyYKTfxVjKiOOB8SbzGsY/CdBwAJMLB+IERvtd9n/8aA3yQAQ8DeOf"
    "JPj/HEab1CB440kAAAAASUVORK5CYII="
)


if __name__ == "__main__":
    try:
        if "--login" in sys.argv:
            login_window(sys.argv[sys.argv.index("--login") + 1])
        elif "--export-icon" in sys.argv:  # writes diamond.ico next to this file (for building an .exe)
            ensure_ico(os.path.join(os.getcwd(), "diamond.ico"), force=True)
        elif "--restore-links" in sys.argv:  # emergency: give the Roblox links back
            disable_protocol()
            d = load_data()
            d["takeover"] = False
            save_data(d)
            import tkinter as tk
            import tkinter.messagebox as mb
            _r = tk.Tk()
            _r.withdraw()
            mb.showinfo("Glint", "Roblox links were handed back to Roblox.")
        else:
            link = next((a for a in sys.argv[1:] if LINK_OK.match(a)), None)
            if link and gui_running():
                forward_link(link)  # Glint is already open: it launches this link
            else:
                run_gui(link)
    except Exception:
        import traceback
        os.makedirs(APP_DIR, exist_ok=True)
        with open(os.path.join(APP_DIR, "crash.log"), "a") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S\n") + traceback.format_exc() + "\n")
        try:
            import tkinter.messagebox as mb
            mb.showerror("Glint crashed", "Details saved to:\n" + os.path.join(APP_DIR, "crash.log") +
                           "\n\nPlease report it here (paste that file):\n" + GITHUB_ISSUES)
        except Exception:
            pass
